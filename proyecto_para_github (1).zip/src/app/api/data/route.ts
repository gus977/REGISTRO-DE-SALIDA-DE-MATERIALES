import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

interface DataItem {
  key: string;
  value: unknown;
}

function safeStringify(value: unknown): string {
  return JSON.stringify(value === undefined ? null : value);
}

// GET /api/data -> devuelve TODAS las claves guardadas en el servidor
export async function GET() {
  try {
    const rows = await db.dataStore.findMany();
    const data: Record<string, unknown> = {};
    for (const row of rows) {
      try {
        data[row.key] = JSON.parse(row.value);
      } catch {
        // valor ilegible: se expone tal cual para no perder datos
        data[row.key] = row.value;
      }
    }
    return NextResponse.json({ ok: true, data });
  } catch (error) {
    console.error("[api/data] GET error:", error);
    return NextResponse.json(
      { ok: false, error: "No se pudo leer la base de datos" },
      { status: 500 }
    );
  }
}

// PUT /api/data -> guarda una o varias claves (upsert)
// Body aceptado: { items: [{ key, value }, ...] } o { key, value }
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    let items: DataItem[] = [];
    if (Array.isArray(body?.items)) {
      items = body.items;
    } else if (body && typeof body.key === "string") {
      items = [{ key: body.key, value: body.value }];
    } else {
      return NextResponse.json(
        { ok: false, error: "Formato invalido: se espera { items: [{key, value}] }" },
        { status: 400 }
      );
    }

    const valid = items.filter(
      (it) => it && typeof it.key === "string" && it.key.length > 0 && it.key.length <= 200
    );
    if (!valid.length) {
      return NextResponse.json({ ok: false, error: "Sin claves validas" }, { status: 400 });
    }

    await db.$transaction(
      valid.map((it) =>
        db.dataStore.upsert({
          where: { key: it.key },
          update: { value: safeStringify(it.value) },
          create: { key: it.key, value: safeStringify(it.value) },
        })
      )
    );

    return NextResponse.json({ ok: true, saved: valid.length });
  } catch (error) {
    console.error("[api/data] PUT error:", error);
    return NextResponse.json(
      { ok: false, error: "No se pudo guardar en la base de datos" },
      { status: 500 }
    );
  }
}

// DELETE /api/data?key=nombre -> elimina una clave (uso administrativo)
export async function DELETE(request: NextRequest) {
  try {
    const key = request.nextUrl.searchParams.get("key");
    if (!key) {
      return NextResponse.json({ ok: false, error: "Falta el parametro key" }, { status: 400 });
    }
    await db.dataStore.deleteMany({ where: { key } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("[api/data] DELETE error:", error);
    return NextResponse.json({ ok: false, error: "No se pudo eliminar" }, { status: 500 });
  }
}
