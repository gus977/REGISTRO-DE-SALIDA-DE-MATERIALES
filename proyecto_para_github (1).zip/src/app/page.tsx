'use client'

export default function Home() {
  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        width: '100vw',
        height: '100vh',
        overflow: 'hidden',
        background: '#0f172a',
      }}
    >
      <iframe
        id="appFrame"
        src="/app.html"
        title="Sistema de Registro de Materiales"
        style={{
          width: '100%',
          height: '100%',
          border: 'none',
          display: 'block',
        }}
        allow="clipboard-write"
      />
    </div>
  )
}
