# Sistema de Registro de Materiales

Aplicación para registrar materiales, inventario, órdenes de trabajo (OT) y provisionales.

> ⚠️ Mantén este repositorio **PRIVADO**: la clave de acceso del sistema está dentro de `public/app.html` y `docs/index.html`.

## Dos formas de usarla

### A) Versión local (un solo archivo, sin servidor)
`docs/index.html` guarda los datos en el navegador de cada usuario.
Para publicarla: **Settings → Pages → Branch: main → Folder: /docs**.
Los datos NO se comparten entre equipos.

### B) Versión web completa (datos compartidos en servidor)
Next.js + Prisma + SQLite. Requiere un servidor con Node 20+ (Render, Railway, VPS).
GitHub NO puede ejecutarla; solo guarda el código.

```bash
cp .env.example .env        # y ajusta DATABASE_URL
npm install
npx prisma generate
npx prisma db push          # crea la base de datos vacía
npm run build
npm run start:node          # http://localhost:3000
```

En producción define `DATABASE_URL` con ruta absoluta en un disco persistente.
La app inicia vacía: crea los usuarios y carga el inventario con el importador de Excel o el respaldo JSON.

## Estructura
- `src/` código Next.js y API (`/api/data`)
- `public/app.html` interfaz completa
- `scripts/build_web/` fuentes para regenerar `app.html`
- `prisma/schema.prisma` esquema de la base de datos
- `docs/index.html` versión local (GitHub Pages)
