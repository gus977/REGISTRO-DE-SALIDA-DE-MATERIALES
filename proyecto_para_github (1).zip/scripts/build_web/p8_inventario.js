/* ============================================================
   TAB: INVENTARIO
   ============================================================ */
function invFiltrados(){
  var q = String(S.invSearch||"").toLowerCase().trim();
  var res = S.inventario.filter(function(m){
    if(S.invFiltro === "conStock" && !(Number(m.stock) > 0)) return false;
    if(S.invFiltro === "sinStock" && Number(m.stock) > 0) return false;
    if(S.invFiltro === "sinObs" && String(m.observacion||"").trim() !== "") return false;
    if(S.invFiltro && S.invFiltro.indexOf("obs:") === 0){
      var v = S.invFiltro.slice(4);
      var tags = String(m.observacion||"").toUpperCase().split(/[;,]/);
      if(tags.indexOf(v) < 0) return false;
    }
    if(!q) return true;
    return String(m.codigo).toLowerCase().indexOf(q) >= 0 ||
           String(m.textoBreve).toLowerCase().indexOf(q) >= 0 ||
           String(m.ubicacion).toLowerCase().indexOf(q) >= 0 ||
           String(m.tipoAlmacen||"").toLowerCase().indexOf(q) >= 0 ||
           String(m.almacen||"").toLowerCase().indexOf(q) >= 0 ||
           String(m.observacion||"").toLowerCase().indexOf(q) >= 0;
  });
  res.sort(function(a,b){ return String(a.codigo).localeCompare(String(b.codigo), undefined, {numeric:true}); });
  return res;
}
function tabInventario(){
  var tot = S.inventario.length;
  var html = '<div style="display:flex;justify-content:flex-start"><button class="btn btn-sm btn-outline" onclick="App.setTab(\'registro\')">'+ic("rotateCcw")+' Regresar a Registrar</button></div>';
  html += '<div class="card"><div class="card-header grad-emerald">'
    + '<div style="display:flex;align-items:center;justify-content:space-between;gap:.8rem;flex-wrap:wrap">'
    + '<div><div class="card-title xl">'+ic("package")+' Inventario de Materiales</div><div class="card-desc">Busca materiales por codigo, descripcion, ubicacion o palabra clave</div></div>'
    + '<span class="badge lg" style="background:rgba(255,255,255,.2);color:#fff;border-color:rgba(255,255,255,.3)">'+ic("package")+' '+fmtN(tot)+' materiales</span>'
    + '<button class="btn btn-sm btn-emerald" onclick="App.abrirInvUpload()">'+ic("refreshCw")+' Guardar Nueva Actualizacion</button>'
    + '<button class="btn btn-sm btn-amber" onclick="App.conteoFisico()">'+ic("fileText")+' Conteo Fisico (HTML)</button>'
    + '</div></div>'
    + '<div class="card-body" style="display:flex;flex-direction:column;gap:1rem">'
    + '<div style="display:flex;flex-direction:column;gap:.6rem" class="row">'
    + '<div class="input-wrap grow" style="flex:1"><span class="ic">'+ic("search")+'</span><input class="input lg has-ic" placeholder="Buscar por codigo, descripcion, palabra clave o ubicacion..." value="'+esc(S.invSearch)+'" oninput="App.invSearch(this.value)"></div>'
    + '<div class="filter-btns">'
    + '<button class="btn btn-sm '+(S.invFiltro==="todos"?"primary":"btn-outline")+'" onclick="App.invFiltroSet(\'todos\')">Todos</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="conStock"?"btn-emerald":"btn-outline emerald")+'" onclick="App.invFiltroSet(\'conStock\')">Con stock</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="sinStock"?"btn-red":"btn-outline red")+'" onclick="App.invFiltroSet(\'sinStock\')">Agotados</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="obs:NUEVO"?"primary":"btn-outline")+'" onclick="App.invFiltroSet(\'obs:NUEVO\')">NUEVO</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="obs:REPARADO"?"primary":"btn-outline")+'" onclick="App.invFiltroSet(\'obs:REPARADO\')">REPARADO</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="obs:RECUPERADO"?"primary":"btn-outline")+'" onclick="App.invFiltroSet(\'obs:RECUPERADO\')">RECUPERADO</button>'
    + '<button class="btn btn-sm '+(S.invFiltro==="sinObs"?"primary":"btn-outline")+'" onclick="App.invFiltroSet(\'sinObs\')">Sin observacion</button>'
    + '</div></div>'
    + '<div style="display:flex;align-items:center;justify-content:space-between;font-size:12.5px;color:var(--sl600)"><span>Mostrando <strong>'+Math.min((S.invPage+1)*100, invFiltrados().length)+'</strong> de <strong>'+fmtN(invFiltrados().length)+'</strong> materiales</span>'
    + (S.invSearch ? '<span>Resultados para: "<strong>'+esc(S.invSearch)+'</strong>"</span>' : '')
    + '</div>';
  var lista = invFiltrados();
  var visibles = lista.slice(0, (S.invPage+1)*100);
  if(!visibles.length){
    html += '<div class="empty-state" style="border:1px solid var(--sl300);border-radius:.5rem">'+ic("package")+'<p class="t">No se encontraron materiales</p><p class="s">Prueba con otra palabra clave'+(tot===0?' o carga tu Excel de inventario con "Guardar Nueva Actualizacion"':'')+'</p></div>';
  } else {
    html += '<div style="max-height:600px;overflow-y:auto;border:1px solid var(--sl400);border-radius:.6rem">';
    for(var i=0;i<visibles.length;i++){
      var m = visibles[i];
      var stockCls = Number(m.stock) > 5 ? "emerald" : (Number(m.stock) > 0 ? "amber" : "red");
      var obsTags = "";
      if(m.observacion){
        var parts = String(m.observacion).split(/[;,]/);
        var tags = [];
        for(var t=0;t<parts.length;t++){ var p = parts[t].trim(); if(p) tags.push('<span class="obs-tag '+(["NUEVO","REPARADO","RECUPERADO"].indexOf(p.toUpperCase())>=0?p.toUpperCase():"OTRO")+'">'+esc(p)+'</span>'); }
        if(tags.length) obsTags = '<div class="obs-tags">'+tags.join("")+'</div>';
      }
      html += '<div class="inv-item" onclick="App.abrirDetalleMaterial(\''+m.id+'\')"><div class="top"><div style="flex:1;min-width:0">'
        + '<div class="badges"><span class="badge blue lg" style="font-weight:800">'+esc(m.codigo)+'</span>'
        + '<span class="badge outline">'+esc(m.unidadMedida)+'</span>'
        + '<span class="badge '+stockCls+'">Stock: '+fmtC(m.stock)+'</span>'
        + (tamborTxt(m.stock, m.codigo) ? '<span class="badge indigo">'+tamborTxt(m.stock, m.codigo)+'</span>' : '')
        + '</div>'
        + '<div class="desc">'+esc(m.textoBreve)+'</div>'
        + '<div class="meta">'
        + (m.ubicacion ? '<span>'+ic("mapPin")+' '+esc(m.ubicacion)+'</span>' : '')
        + (m.tipoAlmacen ? '<span>'+ic("database")+' '+esc(m.tipoAlmacen)+'</span>' : '')
        + (m.almacen ? '<span>'+ic("store")+' '+esc(m.almacen)+'</span>' : '')
        + '</div>'+obsTags+'</div>'
        + '<button class="btn btn-sm btn-outline blue" onclick="event.stopPropagation();App.abrirDetalleMaterial(\''+m.id+'\')">'+ic("eye")+' Ver detalle</button>'
        + '</div></div>';
    }
    html += '</div>';
    if(visibles.length < lista.length){
      html += '<div style="text-align:center;padding-top:.4rem"><button class="btn btn-outline" onclick="App.invCargarMas()">'+ic("refreshCw")+' Cargar mas materiales</button></div>';
    }
  }
  html += '</div></div>';
  return html;
}
App.invSearch = function(v){ S.invSearch = v; S.invPage = 0; renderMain(); var inp = $(".input.lg.has-ic"); if(inp && S.view==="main" && S.tab==="inventario"){ inp.focus(); inp.setSelectionRange(v.length, v.length); } };
App.invFiltroSet = function(f){ S.invFiltro = f; S.invPage = 0; renderMain(); };
App.invCargarMas = function(){ S.invPage++; renderMain(); };

/* ---- Detalle material + EDITAR STOCK ---- */
App.abrirDetalleMaterial = function(id){
  var m = matById(id); if(!m) return;
  S.invDetail = m;
  S.invObs = obsDeMaterial(m.codigo);
  S.invAjOpen = false; S.invAjStock = ""; S.invAjVeh = ""; S.invAjOT = ""; S.invAjSup = ""; S.invAjObs = "";
  openModal('lg','grad-blue', ic("package")+' Detalle del Material', 'Codigo: '+esc(m.codigo), '');
  renderModalContent();
};
function invDetalleHTML(){
  var m = S.invDetail; if(!m) return "";
  var cls = Number(m.stock) > 5 ? "ok" : (Number(m.stock) > 0 ? "low" : "out");
  var icoBig = Number(m.stock) > 5 ? "checkCircle" : "alertTriangle";
  var icoCol = Number(m.stock) > 5 ? "var(--em600)" : (Number(m.stock) > 0 ? "var(--am600)" : "var(--red600)");
  var hist = obsHistAll().filter(function(o){ return o.codigo === String(m.codigo); }).slice(-8).reverse();
  var html = '<div class="modal-body" style="display:flex;flex-direction:column;gap:1rem">'
    + '<div class="info-blue"><p style="font-weight:800;font-size:10.5px;text-transform:uppercase;letter-spacing:.04em;margin-bottom:.2rem">Descripcion</p><p style="font-size:1.1rem;font-weight:700;color:var(--blue950)">'+esc(m.textoBreve)+'</p>'
    + '<div style="display:flex;gap:1rem;flex-wrap:wrap;margin-top:.5rem;font-size:12px">'
    + (m.ubicacion ? '<span>'+ic("mapPin")+' '+esc(m.ubicacion)+'</span>' : '')
    + (m.tipoAlmacen ? '<span>'+ic("database")+' '+esc(m.tipoAlmacen)+'</span>' : '')
    + (m.almacen ? '<span>'+ic("store")+' '+esc(m.almacen)+'</span>' : '')
    + '<span>'+ic("package")+' '+esc(m.unidadMedida)+'</span></div></div>'
    + '<div class="dstock" style="border-color:'+(cls==="ok"?"var(--em500)":cls==="low"?"var(--am500)":"var(--red500)")+';background:'+(cls==="ok"?"var(--em100)":cls==="low"?"var(--am100)":"var(--red100)")+'">'
    + '<div><p style="font-size:10.5px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;color:var(--blue900);margin-bottom:.2rem">Stock actual</p>'
    + '<p class="big" style="color:var(--blue950)">'+fmtC(m.stock)+' <span class="u">'+esc(m.unidadMedida)+'</span></p>'
    + (tamborTxt(m.stock, m.codigo) ? '<span class="badge indigo" style="margin-top:.4rem">'+tamborTxt(m.stock, m.codigo)+'</span>' : '')
    + '</div><div>'+ic(icoBig,"ic-44").replace('style="width:1em;height:1em','style="width:48px;height:48px;color:'+icoCol+';width:48px')+'</div></div>';
  if(!S.invAjOpen){
    html += '<button class="btn btn-primary" onclick="App.invAjAbrir()">'+ic("edit")+' EDITAR STOCK</button>';
  } else {
    var diff = parseFloat(String(S.invAjStock).replace(",",".")) - Number(m.stock);
    var asig = Number(m.stock) - parseFloat(String(S.invAjStock).replace(",","."));
    html += '<div class="aj-form">'
      + '<p style="font-size:11px;font-weight:800;color:var(--blue900);text-transform:uppercase">Nuevo stock</p>'
      + '<input id="aj-stock" type="number" step="0.01" min="0" class="input bold lg" value="'+esc(S.invAjStock)+'" placeholder="Ingresa el nuevo stock" oninput="App.invAjStock(this.value)" autofocus>'
      + (S.invAjStock && !isNaN(Number(S.invAjStock)) ? '<div class="diff-box">'
        + '<span class="'+(diff>0?"":diff<0?"":"")+'" style="color:'+(diff>0?"var(--em700)":diff<0?"var(--red700)":"var(--sl600)")+';font-weight:700">Stock: <strong>'+fmtC(m.stock)+'</strong> → <strong>'+fmtC(parseFloat(S.invAjStock))+'</strong> '+esc(m.unidadMedida)+' ('+(diff>0?"+":"")+fmtC(diff)+')</span>'
        + (asig > 0 ? '<span style="color:var(--am700);font-weight:700">📋 Cantidad asignada a la OT: '+fmtC(asig)+' '+esc(m.unidadMedida)+'</span>' : '')
        + (asig < 0 ? '<span style="color:var(--em700);font-weight:700">📥 Aumento de stock: '+fmtC(Math.abs(asig))+' '+esc(m.unidadMedida)+' (entrada)</span>' : '')
        + '</div>' : '')
      + '<div class="aj-grid">'
      + '<div><label class="label small">Vehiculo <span class="req">*</span></label><input class="input" value="'+esc(S.invAjVeh)+'" oninput="S.invAjVeh=this.value"></div>'
      + '<div><label class="label small">Numero de OT <span class="req">*</span></label><input class="input" value="'+esc(S.invAjOT)+'" oninput="S.invAjOT=this.value"></div>'
      + '</div>'
      + '<div><label class="label small">Supervisor <span class="req">*</span> (escribe el nombre o selecciona de la lista)</label>'
      + supComboHTML("invaj-sup", "invAjSup", "Escribe el nombre del supervisor o selecciona de la lista...")
      + '</div>';
    if(S.invObs.length){
      html += '<div><label class="label small">Observacion del inventario</label><div class="obs-grid">'+obsGridHTML(S.invObs, S.invAjObs, "ajuste", -1).replace('<div class="info-amber">','<div>').replace('<p style="font-style:italic;font-size:10px;margin-top:.35rem">Cantidad real en inventario de cada observacion. Haz clic en una con stock para usarla.</p>','')+'</div>'
        + '<div style="margin-top:.5rem;background:#fff;border:1px solid var(--blue300);border-radius:.5rem;padding:.5rem .65rem">'
        + '<p style="font-size:10.5px;font-weight:800;color:var(--blue900);text-transform:uppercase;margin-bottom:.2rem">Mensaje automatico</p>'
        + '<p style="font-size:12px;color:var(--sl600)">Este material se realizo salida directa por que es reservado instantaneamente</p></div></div>';
    }
    html += '<button class="btn btn-emerald" onclick="App.invAjGuardar()">'+ic("save")+' GUARDAR NUEVO STOCK</button></div>';
  }
  /* historial de observaciones del material */
  html += '<div><p style="font-size:11px;font-weight:800;color:var(--sl600);text-transform:uppercase;margin-bottom:.4rem">Observaciones del material en inventario</p>';
  if(!hist.length){
    html += '<p style="font-size:12px;color:var(--sl500)">Sin observaciones registradas en inventario</p>';
  } else {
    for(var i=0;i<hist.length;i++){
      var o = hist[i];
      html += '<div class="obs-hist-item"><span><span class="badge '+(o.tipo==="salida"?"red":"emerald")+'" style="font-size:9.5px">'+(o.tipo==="salida"?"SALIDA":"ENTRADA")+'</span> <b>'+esc(o.valor)+'</b> · '+fmtC(o.cantidad)+' '+esc(m.unidadMedida)+'</span>'
        + '<span style="display:flex;align-items:center;gap:.5rem"><span style="font-size:10.5px;color:var(--sl500)">'+fmtF(o.fecha)+'</span>'
        + '<button class="copy-btn" onclick="App.copiarCodigo(\''+esc(m.codigo)+'\')">'+ic("copy")+' Copiar</button></span></div>';
    }
  }
  html += '</div></div><div class="modal-foot"><button class="btn btn-outline" onclick="App.cerrarDetalle()">Cerrar</button></div>';
  return html;
}
App.invAjAbrir = function(){
  S.invAjOpen = true;
  S.invAjStock = String(S.invDetail.stock);
  renderModalContent();
  setTimeout(function(){ var el = byId("aj-stock"); if(el){ el.focus(); el.select(); } }, 60);
};
App.invAjStock = function(v){ S.invAjStock = v; var el = byId("aj-stock"); if(el){ renderModalContent(); var e2 = byId("aj-stock"); if(e2){ e2.focus(); e2.setSelectionRange(v.length, v.length); } } };
App.invAjObs = function(v){ S.invAjObs = v; };
App.copiarCodigo = function(codigo){
  try{ navigator.clipboard.writeText(String(codigo)); }catch(e){}
  toast("Codigo copiado", String(codigo));
};
App.cerrarDetalle = function(){ S.invDetail = null; closeModal(); renderMain(); };
App.invAjGuardar = function(){
  var m = S.invDetail; if(!m) return;
  var nuevo = parseFloat(String(S.invAjStock).replace(",","."));
  if(isNaN(nuevo) || nuevo < 0){ toast("Cantidad invalida","Ingresa un numero valido mayor o igual a cero","destructive"); return; }
  if(nuevo === Number(m.stock)){ toast("Sin cambios","El nuevo stock es igual al actual"); S.invAjOpen = false; renderModalContent(); return; }
  if(!String(S.invAjVeh||"").trim()){ toast("⚠ Vehiculo obligatorio","Debes indicar a que VEHICULO se le asigna la diferencia. Sin esto no se puede hacer el ajuste.","destructive"); return; }
  if(!String(S.invAjOT||"").trim()){ toast("⚠ Numero de OT obligatorio","Debes indicar el NUMERO DE ORDEN (OT) para este ajuste. Sin esto no se puede hacer el ajuste.","destructive"); return; }
  if(!String(S.invAjSup||"").trim()){ toast("⚠ Supervisor obligatorio","Debes seleccionar el SUPERVISOR. Sin esto no se puede hacer el ajuste.","destructive"); return; }
  var tieneObs = S.invObs.length > 0 && S.invObs.some(function(o){ return o.valor && String(o.valor).trim() !== ""; });
  if(tieneObs && !String(S.invAjObs||"").trim()){
    toast("⚠ Observacion obligatoria","Este material tiene observaciones registradas en inventario. Debes seleccionar una observacion (NUEVO, REPARADO, RECUPERADO).","destructive");
    return;
  }
  var stockAnterior = Number(m.stock)||0;
  var cantidadAsignada = Math.round((stockAnterior - nuevo)*100)/100;
  m.stock = nuevo; saveInventario();
  var esEntrada = nuevo > stockAnterior;
  var reg = {
    id: uid(), fecha: new Date().toISOString(),
    vehiculo: String(S.invAjVeh).trim(), ot: String(S.invAjOT).trim(),
    codigo: m.codigo, descripcion: m.textoBreve,
    cantidad: Math.abs(cantidadAsignada), unidad: m.unidadMedida,
    supervisor: String(S.invAjSup).trim(), usuario: S.usuario.username,
    observacion: String(S.invAjObs||"").trim() || "Se ha reservado en SAP instantaneamente",
    turno: turnoNow(),
    tipoAjuste: esEntrada ? "AJUSTE-ENTRADA" : "AJUSTE-STOCK"
  };
  if(reg.observacion && !esEntrada && S.invObs.some(function(o){return o.valor===reg.observacion;})) obsRegistrar(m.codigo, reg.observacion, reg.cantidad, "salida");
  S.registros.unshift(reg); saveRegistros();
  S.invObs = obsDeMaterial(m.codigo);
  S.invAjOpen = false; S.invAjStock = S.invAjVeh = S.invAjOT = S.invAjSup = S.invAjObs = "";
  addSupervisor(reg.supervisor);
  renderModalContent(); renderMain();
  toast("✅ Salida directa registrada en historial",
    m.codigo+" | Stock: "+fmtC(stockAnterior)+" → "+fmtC(nuevo)+" | Cantidad asignada a OT "+reg.ot+": "+fmtC(Math.abs(cantidadAsignada))+" "+m.unidadMedida+" | Vehiculo: "+reg.vehiculo+" | Supervisor: "+reg.supervisor+" | Observacion: "+reg.observacion+(esEntrada ? " (ENTRADA de stock)" : " | Este material se realizo salida directa por que es reservado instantaneamente"),
    esEntrada ? "success" : "default");
};

/* ============================================================
   CARGA DE INVENTARIO (Excel/CSV)
   ============================================================ */
var COLS_MAP = {
  codigo: ["codigo","code","cod"],
  tipoAlmacen: ["tipo de almacen","tipo almacen","tipo_almacen","tipoalmacen","tipo"],
  almacen: ["almacen","store"],
  textoBreve: ["texto breve de material","texto breve","texto_breve","textobreve","descripcion","descripcion del material"],
  ubicacion: ["ubicacion","location","loc"],
  unidadMedida: ["unidad medida base","unidad medida","unidad_medida","unidadmedida","unidad","unit"],
  stock: ["stock total","stock","cantidad","existencia","stocktotal"],
  observacion: ["observacion","observaciones","obs","notas"]
};
function normCol(s){ return String(s||"").toLowerCase().trim().normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[\s_\-\.]/g,""); }
function mapearFila(headers, row){
  function findIdx(names){
    for(var i=0;i<names.length;i++){
      var target = normCol(names[i]);
      for(var j=0;j<headers.length;j++){
        if(normCol(headers[j]) === target) return j;
      }
    }
    return -1;
  }
  var c = findIdx(COLS_MAP.codigo);
  if(c < 0) return null;
  function val(idx, def){ return idx >= 0 ? String(row[idx] == null ? "" : row[idx]).trim() : (def || ""); }
  return {
    codigo: val(c),
    tipoAlmacen: val(findIdx(COLS_MAP.tipoAlmacen)),
    almacen: val(findIdx(COLS_MAP.almacen)),
    textoBreve: val(findIdx(COLS_MAP.textoBreve)),
    ubicacion: val(findIdx(COLS_MAP.ubicacion)),
    unidadMedida: val(findIdx(COLS_MAP.unidadMedida), "UN"),
    stock: val(findIdx(COLS_MAP.stock), "0"),
    observacion: val(findIdx(COLS_MAP.observacion))
  };
}
function parseArchivoInventario(file, cb){
  var name = file.name.toLowerCase();
  var reader = new FileReader();
  reader.onload = function(e){
    var mats = [];
    try{
      if(name.endsWith(".csv") || name.endsWith(".txt")){
        var text = new TextDecoder().decode(new Uint8Array(e.target.result));
        var sep = (text.split(/\r?\n/)[0] || "").indexOf(";") >= 0 ? ";" : ",";
        var lines = text.split(/\r?\n/).filter(function(l){ return l.trim(); });
        if(lines.length){
          var headers = parseCSVLine(lines[0], sep);
          for(var i=1;i<lines.length;i++){
            var row = parseCSVLine(lines[i], sep);
            var m = mapearFila(headers, row);
            if(m && m.codigo) mats.push(m);
          }
        }
      } else if(name.endsWith(".xlsx") || name.endsWith(".xls")){
        var wb = XLSX.read(new Uint8Array(e.target.result), {type: "array"});
        var ws = wb.Sheets[wb.SheetNames[0]];
        var rows = XLSX.utils.sheet_to_json(ws, {header: 1});
        if(rows.length){
          var heads = rows[0].map(function(x){ return String(x||"").trim(); });
          for(var j=1;j<rows.length;j++){
            var m2 = mapearFila(heads, rows[j].map(function(x){ return String(x==null?"":x).trim(); }));
            if(m2 && m2.codigo) mats.push(m2);
          }
        }
      } else { cb(null, "Formato no soportado. Usa .xlsx, .xls o .csv"); return; }
    }catch(err){ cb(null, "Error al leer archivo: " + err.message); return; }
    if(!mats.length){ cb(null, "No se encontraron materiales validos en el archivo"); return; }
    cb(mats, null);
  };
  reader.onerror = function(){ cb(null, "Error al leer el archivo"); };
  reader.readAsArrayBuffer(file);
}
function parseCSVLine(line, sep){
  var out = [], cur = "", inQ = false;
  for(var i=0;i<line.length;i++){
    var ch = line[i];
    if(inQ){
      if(ch === '"'){ if(line[i+1] === '"'){ cur += '"'; i++; } else inQ = false; }
      else cur += ch;
    } else {
      if(ch === '"') inQ = true;
      else if(ch === sep){ out.push(cur); cur = ""; }
      else cur += ch;
    }
  }
  out.push(cur);
  return out.map(function(x){ return x.trim(); });
}
function descontarPendientesInventario(){
  /* descuenta consumo de OTs pendientes (no legalizadas, no ocultas, no ajustes) sobre el stock recien cargado */
  var pendientes = S.registros.filter(function(r){
    return !r.tipoAjuste && !S.ocultas.has(String(r.ot)) && !S.legalizadas.has(String(r.ot));
  });
  var porMat = {}, totalUnid = 0;
  pendientes.forEach(function(r){
    if(!porMat[r.codigo]) porMat[r.codigo] = 0;
    porMat[r.codigo] += Number(r.cantidad)||0;
    totalUnid += Number(r.cantidad)||0;
  });
  var descontados = [];
  Object.keys(porMat).forEach(function(cod){
    var m = matByCodigo(cod);
    if(m && porMat[cod] > 0){
      m.stock = Math.round(((Number(m.stock)||0) - porMat[cod])*100)/100;
      descontados.push({codigo: cod, desc: m.textoBreve, unidades: porMat[cod]});
    }
  });
  return {totalDescuentos: descontados.length, unidades: totalUnid, descontados: descontados};
}
/* ============================================================
   IMPORTACION DE INVENTARIO (nucleo compartido Admin + Inventario)
   Estructura del Excel: Codigo | Tipo almacen | Almacen | Texto breve de material
   | Ubicacion | Unidad medida base | Stock total | Observacion (NUEVO/REPARADO/RECUPERADO o vacia)
   - El mismo codigo puede venir en VARIAS filas (una por observacion): se suman los stocks.
   - Siembra el stock por observacion (obsHist) para que el grid de registro quede listo.
   - Re-aplica el consumo pendiente (OTs no legalizadas) sobre stock y observaciones. */
function aplicarMaterialesImportados(mats, modo){
  var grupos = {}, orden = [];
  (mats||[]).forEach(function(row){
    var cod = String(row.codigo||"").trim();
    if(!cod) return;
    if(!grupos[cod]){ grupos[cod] = []; orden.push(cod); }
    grupos[cod].push(row);
  });
  if(modo === "reemplazar"){ S.inventario = []; DB.set("obsHist", []); }
  var nuevos = 0, actualizados = 0, filasDup = 0, obsFilas = 0;
  var codigosEnArchivo = {};
  orden.forEach(function(cod){
    var g = grupos[cod];
    if(g.length > 1) filasDup += g.length - 1;
    codigosEnArchivo[cod] = true;
    var total = 0, obsVals = [], f = {};
    g.forEach(function(r){
      total += Number(String(r.stock).replace(",",".")) || 0;
      var ov = String(r.observacion||"").trim().toUpperCase();
      if(ov && obsVals.indexOf(ov) < 0) obsVals.push(ov);
      ["tipoAlmacen","almacen","textoBreve","ubicacion","unidadMedida"].forEach(function(k){
        if(!f[k] && r[k]) f[k] = String(r[k]).trim();
      });
    });
    var m = matByCodigo(cod);
    if(m){
      if(f.textoBreve) m.textoBreve = f.textoBreve;
      if(f.ubicacion) m.ubicacion = f.ubicacion;
      if(f.unidadMedida) m.unidadMedida = f.unidadMedida;
      if(f.tipoAlmacen) m.tipoAlmacen = f.tipoAlmacen;
      if(f.almacen) m.almacen = f.almacen;
      m.stock = Math.round(total*100)/100;
      m.observacion = obsVals.join(";");
      actualizados++;
    } else {
      S.inventario.push({id: uid(), codigo: cod, tipoAlmacen: f.tipoAlmacen||"", almacen: f.almacen||"",
        textoBreve: f.textoBreve || cod, ubicacion: f.ubicacion||"", unidadMedida: f.unidadMedida || "UN",
        stock: Math.round(total*100)/100, observacion: obsVals.join(";"), createdAt: new Date().toISOString()});
      nuevos++;
    }
    if(obsVals.length) obsFilas++;
    /* Siembra el stock por observacion (obsHist) tal como viene en el archivo */
    var hist = obsHistAll().filter(function(o){ return String(o.codigo) !== cod; });
    g.forEach(function(r){
      var ov = String(r.observacion||"").trim().toUpperCase();
      var q = Number(String(r.stock).replace(",",".")) || 0;
      if(ov && q > 0) hist.push({id: uid(), codigo: cod, valor: ov, cantidad: q, tipo: "entrada", fecha: new Date().toISOString()});
    });
    DB.set("obsHist", hist);
  });
  /* Re-aplica salidas de observaciones para consumos pendientes de los codigos del archivo */
  var pendientes = S.registros.filter(function(r){
    return !r.tipoAjuste && !S.ocultas.has(String(r.ot)) && !S.legalizadas.has(String(r.ot)) && codigosEnArchivo[String(r.codigo)];
  });
  pendientes.forEach(function(r){
    if(r.observacion) obsRegistrar(r.codigo, r.observacion, r.cantidad, "salida");
  });
  /* Descuenta el consumo pendiente sobre el stock recien cargado */
  var desc = descontarPendientesInventario();
  return {nuevos: nuevos, actualizados: actualizados, filasDup: filasDup, obsFilas: obsFilas,
          totalMateriales: orden.length, totalDescuentos: desc.totalDescuentos, unidades: desc.unidades, descontados: desc.descontados};
}
App.abrirInvUpload = function(){
  S.invUpOpen = true; S.invUpFile = null; S.invUpName = ""; S.invUpResult = null;
  openModal('lg','grad-emerald', ic("refreshCw")+' Actualizar Inventario', 'Carga la nueva base de materiales desde Excel o CSV','');
  renderModalContent();
};
function invUploadHTML(){
  var html = '<div class="modal-body" style="display:flex;flex-direction:column;gap:1rem">';
  if(!S.invUpResult){
    html += '<div class="info-blue">'+ic("info")+' Sube tu archivo de inventario (Excel o CSV) con las siguientes columnas:</div>'
      + '<div><p style="font-size:11px;font-weight:800;color:var(--sl600);text-transform:uppercase;margin-bottom:.4rem">Columnas del archivo:</p>'
      + '<div style="display:flex;gap:.4rem;flex-wrap:wrap">'
      + ["Codigo","Tipo de almacen","Almacen","Texto breve de material","Ubicacion","Unidad medida base","Stock total","Observacion"].map(function(c){ return '<span class="badge slate">'+c+'</span>'; }).join("")
      + '</div><p style="font-size:12px;color:var(--sl600);margin-top:.5rem">Al guardar, el sistema <b>descontara automaticamente</b> el consumo de las OTs pendientes de legalizar sobre el nuevo stock.</p></div>'
      + '<div class="file-drop" onclick="byId(\'inv-file\').click()">'+ic("upload")
      + '<div class="t">'+(S.invUpName ? esc(S.invUpName) : "Seleccionar archivo")+'</div>'
      + '<div class="s">Formatos: .xlsx, .xls o .csv</div></div>'
      + '<input type="file" id="inv-file" accept=".xlsx,.xls,.csv,.txt" style="display:none" onchange="App.invFileSel(this)">'
      + '<div style="display:flex;justify-content:flex-end;gap:.5rem">'
      + '<button class="btn btn-outline" onclick="App.cerrarModal()">Cerrar</button>'
      + '<button class="btn btn-emerald" onclick="App.invUploadProcesar()"'+(!S.invUpFile?" disabled":"")+'>'+ic("upload")+' '+(S.invUpBusy?"Procesando...":"Guardar Nueva Actualizacion")+'</button></div>';
  } else {
    var r = S.invUpResult;
    html += '<h4 style="font-weight:800;color:var(--sl900)">Reporte de Actualizacion de Inventario</h4>'
      + '<p style="font-size:12.5px;color:var(--sl600)">Resumen de la carga y descuentos por OTs pendientes</p>'
      + '<div class="report-stats">'
      + '<div class="c" style="background:var(--em50);border-color:var(--em500)"><div class="k" style="color:var(--em800)">Actualizados</div><div class="v" style="color:var(--em800)">'+r.actualizados+'</div></div>'
      + '<div class="c" style="background:var(--pur50);border-color:var(--pur500)"><div class="k" style="color:var(--pur700)">Nuevos agregados</div><div class="v" style="color:var(--pur700)">'+r.noEncontrados+'</div></div>'
      + '<div class="c" style="background:var(--am50);border-color:var(--am500)"><div class="k" style="color:var(--am700)">Descuentos</div><div class="v" style="color:var(--am700)">'+r.totalDescuentos+'</div></div>'
      + '<div class="c" style="background:var(--blue50);border-color:var(--blue400)"><div class="k" style="color:var(--blue900)">Unidades descontadas</div><div class="v" style="color:var(--blue900)">'+fmtC(r.unidades)+'</div></div>'
      + '</div>'
      + (r.filasDup ? '<div class="info-blue">El archivo tenia codigos repetidos con distinta observacion (NUEVO / REPARADO / RECUPERADO): se sumaron los stocks en un solo material y se guardo el stock por cada observacion.</div>' : '');
    if(r.descontados.length){
      html += '<p style="font-size:12px;font-weight:800;color:var(--sl700)">Materiales descontados por OTs pendientes:</p><div style="max-height:220px;overflow-y:auto">';
      r.descontados.forEach(function(d){
        html += '<div class="rep-item"><div class="l1">'+esc(d.codigo)+' — '+esc(d.desc)+'</div><div class="l2">-'+fmtC(d.unidades)+' unidades descontadas</div></div>';
      });
      html += '</div>';
    } else {
      html += '<div class="info-blue">No habia materiales pendientes por descontar</div>';
    }
    html += '<div style="display:flex;justify-content:flex-end"><button class="btn btn-primary" onclick="App.cerrarInvUpload()">Cerrar reporte</button></div>';
  }
  html += '</div>';
  return html;
}
App.invFileSel = function(input){
  var f = input.files && input.files[0];
  if(!f) return;
  S.invUpFile = f; S.invUpName = f.name;
  renderModalContent();
};
App.invUploadProcesar = function(){
  if(!S.invUpFile){ toast("Selecciona un archivo", null, "destructive"); return; }
  S.invUpBusy = true; renderModalContent();
  parseArchivoInventario(S.invUpFile, function(mats, err){
    S.invUpBusy = false;
    if(err){ toast("Error", err, "destructive"); renderModalContent(); return; }
    var r = aplicarMaterialesImportados(mats, "agregar");
    saveInventario();
    DB.set("lastUpload", new Date().toISOString());
    S.invUpResult = {actualizados: r.actualizados, noEncontrados: r.nuevos, filasDup: r.filasDup, obsFilas: r.obsFilas, totalDescuentos: r.totalDescuentos, unidades: r.unidades, descontados: r.descontados};
    toast("Inventario actualizado", r.actualizados+" materiales actualizados. "+r.nuevos+" nuevos. "+r.totalDescuentos+" descuentos por OTs pendientes.");
    renderModalContent(); renderMain();
  });
};
App.cerrarInvUpload = function(){ S.invUpOpen = false; S.invUpResult = null; S.invUpFile = null; S.invUpName = ""; closeModal(); renderMain(); };
