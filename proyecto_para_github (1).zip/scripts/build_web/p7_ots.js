/* ============================================================
   TAB: ORDENES (OT)
   ============================================================ */
function otsAgrupadas(){
  var map = {}, orden = [];
  S.registros.forEach(function(r){
    if(S.ocultas.has(String(r.ot)) || r.tipoAjuste || r.ot === "AJUSTE-STOCK" || r.vehiculo === "AJUSTE-MANUAL") return;
    var k = String(r.ot);
    if(!map[k]){ map[k] = {ot: k, cantidad: 0, total: 0, fecha: r.fecha}; orden.push(k); }
    map[k].cantidad += 1;
    map[k].total += Number(r.cantidad)||0;
    if(r.fecha > map[k].fecha) map[k].fecha = r.fecha;
  });
  return orden.map(function(k){ return map[k]; }).sort(function(a,b){ return String(b.fecha).localeCompare(String(a.fecha)); });
}
function tabOTs(){
  var ots = otsAgrupadas();
  var nLeg = 0;
  for(var l=0;l<ots.length;l++){ if(S.legalizadas.has(ots[l].ot)) nLeg++; }
  var nPend = ots.length - nLeg;
  var html = '<div class="card"><div class="card-header grad-slate">'
    + '<div class="card-title xl">'+ic("fileText")+' Ordenes de Trabajo (OTs)</div>'
    + '<div class="card-desc">Visualiza, edita e imprime OTs completas. '+ots.length+' OT(s) registrada(s): <b style="color:var(--em700)">'+nLeg+' legalizada(s)</b> · <b style="color:var(--am700)">'+nPend+' pendiente(s) por legalizar</b>.</div></div>';
  if(!ots.length){
    html += '<div class="empty-state">'+ic("fileText")+'<p class="t">No hay OTs registradas</p><p class="s">Empieza a registrar materiales en la pestana Registrar</p></div>';
  } else {
    html += '<div style="max-height:600px;overflow-y:auto">';
    for(var i=0;i<ots.length;i++){
      var o = ots[i];
      var legal = S.legalizadas.has(o.ot);
      html += '<div class="ot-item'+(legal?" legalizada":"")+'"><div class="top"><div style="flex:1;min-width:0">'
        + '<div class="badges">'
        + '<span class="badge blue-solid lg">OT: '+esc(o.ot)+'</span>'
        + (legal ? '<span class="badge emerald-solid">'+ic("checkCircle")+' LEGALIZADA</span>' : '<span class="badge amber">'+ic("clock")+' PENDIENTE POR LEGALIZAR</span>')
        + '<span class="badge outline">'+o.cantidad+' materiales</span>'
        + '<span class="badge amber">Total: '+fmtC(o.total)+'</span>'
        + '</div>'
        + '<p class="meta">Ultimo registro: '+fmtF(o.fecha)+'</p></div>'
        + '<div class="acts">'
        + '<button class="btn btn-sm btn-outline blue" onclick="App.descargarOrdenHTML(\''+esc(o.ot)+'\')" title="Genera y descarga el archivo HTML de esta orden con todos sus detalles">'+ic("download")+' HTML</button>'
        + '<button class="btn btn-sm btn-indigo" onclick="App.abrirOTModal(\''+esc(o.ot)+'\')"'+(S.isMobile?" disabled":"")+' title="Editar OT">'+ic("edit")+' Editar</button>'
        + '<button class="btn btn-sm btn-primary" onclick="App.verDocOT(\''+esc(o.ot)+'\')">'+ic("eye")+' Ver HTML</button>'
        + '<button class="btn btn-sm btn-purple" onclick="App.verDocOT(\''+esc(o.ot)+'\')" title="Abrir documento para imprimir o guardar como PDF">'+ic("printer")+' Guardar PDF</button>'
        + '<button class="btn btn-sm btn-outline emerald" onclick="App.abrirAgregarOT(\''+esc(o.ot)+'\')"'+(S.isMobile?" disabled":"")+' title="Agregar materiales a OT">'+ic("plus")+' Agregar</button>'
        + '<button class="btn btn-sm btn-outline red" onclick="App.eliminarOT(\''+esc(o.ot)+'\')"'+(S.isMobile?" disabled":"")+' title="Eliminar OT">'+ic("x")+' Eliminar</button>'
        + '</div></div>'
        + (S.isMobile ? '<p class="mob-warn">⚠ Las opciones de Editar, Agregar y Eliminar solo estan disponibles desde la PC</p>' : '')
        + '</div>';
    }
    html += '</div>';
  }
  html += '</div>';
  return html;
}

/* ---- Modal de OT (detalle, correcciones, editar datos, agregar) ---- */
App.abrirOTModal = function(ot){
  var regs = S.registros.filter(function(r){ return String(r.ot) === ot; });
  if(!regs.length){ toast("Error","No se pudo cargar la OT","destructive"); return; }
  S.otModal = ot; S.otModalRegs = regs.slice();
  S.otEditando = false; S.otNew = ot; S.otNewVeh = regs[0].vehiculo; S.otNewSup = regs[0].supervisor;
  S.otAddOpen = false; S.otAddRows = []; S.editCell = null;
  openModal('xl','grad-slate', ic("fileText")+' OT: '+esc(ot), 'Detalle completo de la Orden de Trabajo','');
  renderModalContent();
};
function otModalHTML(){
  var regs = S.otModalRegs, ot = S.otModal;
  if(!regs.length) return '<div class="modal-body"><div class="empty-state">'+ic("package")+'<p class="t">No hay materiales en esta OT</p></div></div>';
  var primer = regs[0];
  var html = '<div class="modal-body" style="padding:0;display:flex;flex-direction:column">';
  /* barra acciones */
  html += '<div style="padding:.7rem 1rem;display:flex;justify-content:space-between;gap:.5rem;flex-wrap:wrap;background:var(--sl50);border-bottom:1px solid var(--sl300)">'
    + '<span style="font-size:12.5px;color:var(--sl600);align-self:center">'+regs.length+' registro(s) · Vehiculo: <b>'+esc(primer.vehiculo)+'</b> · Supervisor: <b>'+esc(primer.supervisor)+'</b></span>'
    + '<span style="display:flex;gap:.4rem;flex-wrap:wrap">'
    + (!S.otEditando ? '<button class="btn btn-sm btn-outline blue" onclick="App.otToggleEdit(true)">'+ic("edit")+' Editar datos (OT/Vehiculo/Supervisor)</button>' : '<button class="btn btn-sm btn-outline" onclick="App.otToggleEdit(false)">Cancelar edicion</button>')
    + (!S.otAddOpen ? '<button class="btn btn-sm btn-outline emerald" onclick="App.otAddAbrir()"'+(S.isMobile?" disabled":"")+' title="Agregar mas materiales a esta orden">'+ic("plus")+' Agregar materiales</button>' : '')
    + '<button class="btn btn-sm btn-primary" onclick="App.verDocOT(\''+esc(ot)+'\')">'+ic("eye")+' Ver HTML</button>'
    + '<button class="btn btn-sm btn-outline blue" onclick="App.descargarOrdenHTML(\''+esc(ot)+'\')" title="Descarga el archivo HTML de esta orden">'+ic("download")+' Archivo HTML</button>'
    + '</span></div>';
  /* editar datos */
  if(S.otEditando){
    html += '<div style="padding:.9rem 1rem;background:var(--blue50);border-bottom:1px solid var(--blue300);display:flex;flex-direction:column;gap:.6rem">'
      + '<div style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap"><b style="color:var(--blue900);display:flex;gap:.4rem;align-items:center">'+ic("edit")+' Editar datos de la OT</b>'
      + '<button class="btn btn-sm btn-primary" onclick="App.guardarEditOT()">'+ic("save")+' GUARDAR CAMBIOS</button></div>'
      + '<div class="info-blue">'+ic("info")+' Estos cambios se aplicaran a TODOS los materiales de esta OT ('+regs.length+' registro(s)).</div>'
      + '<div class="grid3">'
      + '<div><label class="label small">Numero de OT</label><input class="input bold" value="'+esc(S.otNew)+'" oninput="S.otNew=this.value"></div>'
      + '<div><label class="label small">Vehiculo</label><input class="input bold" value="'+esc(S.otNewVeh)+'" oninput="S.otNewVeh=this.value"></div>'
      + '<div><label class="label small">Supervisor (Recibe)</label>'+supComboHTML("ot-sup","otNewSup","Escribe el nombre o selecciona de la lista...")+'</div>'
      + '</div></div>';
  }
  /* agregar materiales */
  if(S.otAddOpen){
    html += otAddHTML();
  }
  /* tabla de registros */
  html += '<div style="max-height:52vh;overflow:auto"><table class="tbl"><thead><tr>'
    + '<th>#</th><th>Codigo</th><th>Descripcion</th><th class="r">Cant.</th><th class="c">Unidad</th><th class="c">Turno</th><th>Observacion</th><th class="c">Acciones</th>'
    + '</tr></thead><tbody>';
  for(var i=0;i<regs.length;i++){
    var r = regs[i];
    var esEditCell = S.editCell === r.id && S.editTipo === "cant";
    html += '<tr>'
      + '<td class="b">'+(i+1)+'</td>'
      + '<td><span class="badge blue">'+esc(r.codigo)+'</span></td>'
      + '<td style="max-width:230px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="'+esc(r.descripcion)+'">'+esc(r.descripcion)+'</div></td>'
      + '<td class="r">'+(esEditCell
          ? '<input type="number" step="0.01" min="0" class="mini-input" id="edit-cant" value="'+esc(S.editVal)+'">'
          : fmtC(r.cantidad))+'</td>'
      + '<td class="c">'+esc(r.unidad)+'</td>'
      + '<td class="c">'+(r.turno==="DIA"?"☀ DIA":"🌙 T/N")+'</td>'
      + '<td style="font-size:11.5px">'+esc(r.observacion||"-")+'</td>'
      + '<td class="c" style="white-space:nowrap">'
      + (esEditCell
        ? '<button class="mini-btn save" onclick="App.confirmEditCant(\''+r.id+'\')">'+ic("save")+' Guardar</button> <button class="mini-btn cancel" onclick="App.cancelEdit()">Cancelar</button>'
        : '<button class="mini-btn fix" onclick="App.editCant(\''+r.id+'\')" title="Corregir cantidad">'+ic("edit")+' Corregir cantidad</button>')
      + '</td></tr>';
  }
  html += '</tbody></table></div></div>';
  html += '<div class="modal-foot"><button class="btn btn-outline" onclick="App.cerrarModal()">Cerrar</button></div>';
  return html;
}
App.otToggleEdit = function(on){
  S.otEditando = on;
  if(on){ var r = S.otModalRegs[0]; S.otNew = S.otModal; S.otNewVeh = r.vehiculo; S.otNewSup = r.supervisor; }
  renderModalContent();
};
App.guardarEditOT = function(){
  var nuevaOT = String(S.otNew||"").trim(), nuevoVeh = String(S.otNewVeh||"").trim(), nuevoSup = String(S.otNewSup||"").trim();
  if(!nuevaOT || !nuevoVeh || !nuevoSup){ toast("Faltan datos","Completa todos los campos","destructive"); return; }
  var vieja = S.otModal;
  var count = 0;
  S.registros.forEach(function(r){
    if(String(r.ot) === vieja){ r.ot = nuevaOT; r.vehiculo = nuevoVeh; r.supervisor = nuevoSup; count++; }
  });
  saveRegistros();
  if(nuevaOT !== vieja){
    if(S.legalizadas.has(vieja)){ S.legalizadas.delete(vieja); S.legalizadas.add(nuevaOT); }
    if(S.ocultas.has(vieja)){ S.ocultas.delete(vieja); S.ocultas.add(nuevaOT); }
    saveSets();
    S.otModal = nuevaOT;
  }
  S.otModalRegs = S.registros.filter(function(r){ return String(r.ot) === S.otModal; });
  renderModalContent(); renderMain();
  toast("✅ Datos actualizados","OT: "+nuevaOT+" | Vehiculo: "+nuevoVeh+" | Supervisor: "+nuevoSup+" | "+count+" registro(s) actualizado(s)");
};
App.editCant = function(regId){
  var r = null;
  S.otModalRegs.forEach(function(x){ if(x.id === regId) r = x; });
  if(!r) return;
  S.editCell = regId; S.editTipo = "cant"; S.editVal = r.cantidad;
  renderModalContent();
  setTimeout(function(){ var el = byId("edit-cant"); if(el){ el.focus(); el.select(); } }, 50);
};
App.cancelEdit = function(){ S.editCell = null; S.editTipo = null; S.editVal = ""; renderModalContent(); };
App.confirmEditCant = function(regId){
  var nueva = parseFloat(String(S.editVal).replace(",","."));
  if(isNaN(nueva) || nueva < 0){ toast("Cantidad invalida","Ingresa un numero valido","destructive"); return; }
  var r = null;
  S.otModalRegs.forEach(function(x){ if(x.id === regId) r = x; });
  if(!r) return;
  if(nueva === Number(r.cantidad)){ App.cancelEdit(); return; }
  if(!confirm("¿Corregir la cantidad del material "+r.codigo+"?\n\nCantidad actual: "+fmtC(r.cantidad)+" "+r.unidad+"\nNueva cantidad: "+fmtC(nueva)+" "+r.unidad+"\n\nEl stock se ajustara automaticamente.")) return;
  var m = matByCodigo(r.codigo);
  var stockAntes = m ? Number(m.stock)||0 : 0;
  var diff = nueva - Number(r.cantidad);
  var stockDespues = stockAntes;
  if(m){
    stockDespues = Math.round((stockAntes - diff)*100)/100;
    m.stock = stockDespues; saveInventario();
  }
  r.cantidad = nueva;
  saveRegistros();
  S.otModalRegs = S.registros.filter(function(x){ return String(x.ot) === S.otModal; });
  App.cancelEdit();
  mostrarExitosa(r, stockAntes, stockDespues);
  toast("✅ Cantidad corregida", r.codigo+": "+fmtC(r.cantidad - diff)+" → "+fmtC(nueva)+(m ? " | Quedan: "+fmtC(stockDespues) : "")+". Archivo HTML de la orden actualizado.");
  /* Regenera el archivo HTML de la orden con la cantidad corregida */
  if(typeof App.descargarOrdenHTML === "function") App.descargarOrdenHTML(S.otModal, true);
  renderMain();
};
/* agregar materiales a OT */
function otAddHTML(){
  var rows = "";
  for(var i=0;i<S.otAddRows.length;i++){
    var r = S.otAddRows[i];
    rows += '<div class="row-card"><div class="row-head"><span class="n">Fila '+(i+1)+'</span>'
      + '<button class="btn-ghost btn-sm" style="color:var(--red600)" onclick="App.otAddQuitar('+i+')">'+ic("trash")+'</button></div>'
      + '<div><label class="label" style="font-size:11px">Material (codigo o descripcion)</label>'
      + codInputHTML("otadd", i, "Digite el codigo del material...")
      + '<div id="codmsg-otadd-'+i+'"></div>'
      + '<div id="otadd-matcell-'+i+'">'+ matButtonHTML(r.material, "O busca por descripcion en la lista...", "otadd", i)
      + (r._open ? ddOpenHTML("otadd", i) : '')
      + '</div></div>'
      + '<div class="grid2i"><div><label class="label" style="font-size:11px">Cantidad <span class="req">*</span></label><input type="number" step="0.01" min="0" class="input" value="'+esc(r.cantidad||"")+'" oninput="App.otAddField('+i+',this.value)"></div>'
      + '<div><label class="label" style="font-size:11px">Queda en stock</label><div id="otadd-stockcell-'+i+'">'+(r.material?stockPillHTML(r.material, r.cantidad, "otadd-stock-"+i):'<div style="height:34px;display:flex;align-items:center;color:var(--sl400);font-size:12px">—</div>')+'</div></div></div>'
      + '<div><label class="label" style="font-size:11px">Observacion (opcional)</label>'
      + '<div id="otadd-obszone-'+i+'">'+obsGridHTML(r._obs, r.observacion, "otadd", i)+'</div>'
      + '<textarea id="obs-otadd-'+i+'" class="input" style="min-height:44px;margin-top:.35rem" placeholder="Observaciones (opcional)" oninput="S.otAddRows['+i+'].observacion=this.value">'+esc(r.observacion||"")+'</textarea></div>'
      + '</div>';
  }
  return '<div style="padding:.9rem 1rem;background:rgba(16,185,129,.08);border-bottom:1px solid var(--em500);display:flex;flex-direction:column;gap:.6rem">'
    + '<div style="display:flex;align-items:center;justify-content:space-between;gap:.5rem;flex-wrap:wrap"><b style="color:var(--em800);display:flex;gap:.4rem;align-items:center">'+ic("layers")+' Agregar mas materiales a la OT '+esc(S.otModal)+'</b>'
    + '<span style="display:flex;gap:.4rem"><button class="btn btn-sm btn-outline" onclick="App.otAddFila()">'+ic("plus")+' Agregar fila</button>'
    + '<button class="btn btn-sm btn-emerald" onclick="App.otAddGuardar()">'+ic("save")+' GUARDAR MATERIALES</button>'
    + '<button class="btn btn-sm btn-outline" onclick="App.otAddCancel()">Cancelar agregado</button></span></div>'
    + '<div class="info-amber">Se usara el vehiculo y supervisor de la OT: <b>'+esc((S.otModalRegs[0]||{}).vehiculo||"")+'</b> / <b>'+esc((S.otModalRegs[0]||{}).supervisor||"")+'</b></div>'
    + rows + '</div>';
}
App.abrirAgregarOT = function(ot){
  S.otModal = ot;
  S.otModalRegs = S.registros.filter(function(r){ return String(r.ot) === ot; });
  if(!S.otModalRegs.length){ toast("Error","No se pudo cargar la OT","destructive"); return; }
  S.otAddOpen = true; S.otEditando = false;
  S.otAddRows = [{id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  openModal('xl','grad-slate', ic("fileText")+' OT: '+esc(ot), 'Agregar materiales a esta orden','');
  renderModalContent();
};
/* Agregar materiales desde el mismo modal de edicion de la OT */
App.otAddAbrir = function(){
  if(!S.otModal) return;
  S.otAddOpen = true; S.otEditando = false;
  if(!S.otAddRows || !S.otAddRows.length){
    S.otAddRows = [{id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  }
  renderModalContent();
};
App.otAddFila = function(){ S.otAddRows.push({id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}); renderModalContent(); };
App.otAddQuitar = function(i){ S.otAddRows.splice(i,1); renderModalContent(); };
/* Al digitar la cantidad se actualiza el "Queda en stock" de la fila (sin re-render) */
App.otAddField = function(i, val){
  if(!S.otAddRows[i]) return;
  S.otAddRows[i].cantidad = val;
  if(S.otAddRows[i].material){
    var el = byId("otadd-stock-"+i);
    if(el) el.innerHTML = stockPillInner(S.otAddRows[i].material, val);
  }
};
App.otAddCancel = function(){ S.otAddOpen = false; S.otAddRows = []; renderModalContent(); };
App.otAddGuardar = function(){
  var validas = S.otAddRows.filter(function(r){ return r.material && r.cantidad && Number(r.cantidad) > 0; });
  if(!validas.length){ toast("Sin materiales","Agrega al menos un material con cantidad","destructive"); return; }
  var primer = S.otModalRegs[0];
  var veh = primer.vehiculo || S.rgVeh, sup = primer.supervisor || S.rgSup;
  if(!veh || !sup){ toast("Error","No se pudo determinar vehiculo o supervisor","destructive"); return; }
  if(!confirm("Vas a agregar "+validas.length+" materiales a la OT "+S.otModal+". ¿Continuar?")) return;
  var ok = 0, fail = 0;
  for(var i=0;i<validas.length;i++){
    var r = validas[i], m = matById(r.material.id);
    if(!m){ fail++; continue; }
    m.stock = Math.round(((Number(m.stock)||0) - Number(r.cantidad))*100)/100;
    var reg = {id: uid(), fecha: new Date().toISOString(), vehiculo: veh, ot: S.otModal,
      codigo: m.codigo, descripcion: m.textoBreve, cantidad: Number(r.cantidad), unidad: m.unidadMedida,
      supervisor: sup, usuario: S.usuario.username, observacion: String(r.observacion||"").trim(), turno: turnoNow()};
    if(reg.observacion) obsRegistrar(m.codigo, reg.observacion, reg.cantidad, "salida");
    S.registros.unshift(reg);
    S.otModalRegs.push(reg);
    ok++;
  }
  saveRegistros(); saveInventario();
  if(ok > 0){
    toast("✅ "+ok+" materiales agregados a OT "+S.otModal, fail>0 ? "("+fail+" fallidos)" : "Todos se guardaron correctamente. Archivo HTML de la orden actualizado");
    S.otAddOpen = false; S.otAddRows = [];
  } else toast("Error","No se pudo agregar ningun material","destructive");
  if(ok > 0 && typeof App.descargarOrdenHTML === "function") App.descargarOrdenHTML(S.otModal, true);
  renderModalContent(); renderMain();
};
/* eliminar OT */
App.eliminarOT = function(ot){
  if(!confirm("¿Eliminar DEFINITIVAMENTE la OT "+ot+" de esta lista?\n\nNO se podra restaurar.\nEl historial de movimientos permanecera permanentemente.\nEl stock de los materiales sera devuelto al inventario.")) return;
  S.registros.forEach(function(r){
    if(String(r.ot) === ot && !r.tipoAjuste){
      var m = matByCodigo(r.codigo);
      if(m) m.stock = Math.round(((Number(m.stock)||0) + Number(r.cantidad))*100)/100;
    }
  });
  saveInventario();
  S.ocultas.add(String(ot));
  saveSets();
  toast("✓ OT eliminada","La OT "+ot+" fue eliminada de la lista. NO se puede restaurar. El historial permanece.");
  renderMain();
};
App.verDocOT = function(ot){ abrirDocOT(ot); };
