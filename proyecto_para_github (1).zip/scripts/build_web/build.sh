#!/bin/bash
# Ensambla el archivo HTML final de la aplicacion local
set -e
BUILD=/home/z/my-project/scripts/build
OUT=/home/z/my-project/download/Registro_Materiales_LOCAL.html
XLSX=/home/z/my-project/app_analysis/xlsx.full.min.js

mkdir -p /home/z/my-project/download

{
  cat "$BUILD/p1_head.html"
  echo '<script>'
  cat "$XLSX"
  echo '</script>'
  echo '<script>'
  cat "$BUILD/p4_core.js"
  cat "$BUILD/p5_shell.js"
  cat "$BUILD/p6_registrar.js"
  cat "$BUILD/p7_ots.js"
  cat "$BUILD/p8_inventario.js"
  cat "$BUILD/p9_historial.js"
  cat "$BUILD/p10_provisional.js"
  cat "$BUILD/p11_pages.js"
  cat "$BUILD/p12_docs_backup.js"
  cat "$BUILD/p13_autosave.js"
  echo '</script>'
  echo '</body>'
  echo '</html>'
} > "$OUT"

echo "OK: $OUT ($(wc -c < "$OUT") bytes)"
