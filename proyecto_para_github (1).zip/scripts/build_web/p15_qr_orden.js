/* ============================================================
   CODIGO QR EN EL LOGIN - abrir el programa desde el celular
   - Genera un QR (libreria vendor_qrcode.js, sin internet)
     con la direccion actual del programa.
   - El usuario lo escanea con la camara del celular y entra
     al mismo sistema desde alli (misma base de datos).
   ============================================================ */

/* Direccion real del programa (si esta dentro de un iframe usa la del padre) */
function urlPrograma(){
  var u = "";
  try{
    if(window.parent && window.parent !== window){ u = String(window.parent.location.href || ""); }
  }catch(e){ u = ""; }
  if(!u) u = String(window.location.href || "");
  u = u.split("#")[0];
  return u;
}

/* Pinta el QR dentro de la ventana de login */
function generarQRLogin(){
  var box = byId("lg-qr-box");
  if(!box) return;
  var url = urlPrograma();
  try{
    var qr = qrcode(0, "M");          /* 0 = version automatica segun el largo */
    qr.addData(url);
    qr.make();
    box.innerHTML = qr.createSvgTag(4, 0);
  }catch(e){
    box.innerHTML = '<span style="font-size:11px;color:var(--red600);line-height:1.4;padding:.5rem">No se pudo generar el codigo QR. Recarga la pagina (F5) e intenta de nuevo.</span>';
  }
}
