/* ============================================================
   TAB: HISTORIAL
   ============================================================ */
function histFiltrados(){
  var cod = String(S.hCod||"").toLowerCase().trim();
  var ot = String(S.hOT||"").toLowerCase().trim();
  var usu = String(S.hUsu||"").toLowerCase().trim();
  return S.registros.filter(function(r){
    if(cod && String(r.codigo).toLowerCase().indexOf(cod) < 0 && String(r.descripcion).toLowerCase().indexOf(cod) < 0) return false;
    if(ot && String(r.ot).toLowerCase().indexOf(ot) < 0) return false;
    if(usu && String(r.usuario).toLowerCase().indexOf(usu) < 0 && String(r.supervisor).toLowerCase().indexOf(usu) < 0) return false;
    return true;
  });
}
function tabHistorial(){
  var regs = histFiltrados();
  var totalU = 0, ots = new Set(), cods = new Set();
  regs.forEach(function(r){ totalU += Number(r.cantidad)||0; ots.add(r.ot); cods.add(r.codigo); });
  var html = '<div class="card"><div class="card-header grad-hist">'
    + '<div class="card-title xl">'+ic("history")+' Historial de Movimientos</div>'
    + '<div class="card-desc">'+S.registros.length+' registro(s) consolidado(s) · HISTORIAL PERMANENTE: aqui quedan TODAS las ordenes para siempre, aunque las elimines de Ordenes (OT) o de Pendientes</div>'
    + '<div class="row" style="margin-top:.8rem;align-items:flex-end">'
    + '<div><label class="label" style="font-size:9.5px;color:#bfdbfe;text-transform:uppercase">Filtrar por codigo</label><input class="input" style="height:32px;width:150px;background:rgba(30,58,138,.5);border-color:var(--blue500);color:#fff;placeholder-color:#93c5fd" value="'+esc(S.hCod)+'" oninput="App.hFiltro(\'cod\',this.value)"></div>'
    + '<div><label class="label" style="font-size:9.5px;color:#bfdbfe;text-transform:uppercase">Filtrar por OT</label><input class="input" style="height:32px;width:120px;background:rgba(30,58,138,.5);border-color:var(--blue500);color:#fff" value="'+esc(S.hOT)+'" oninput="App.hFiltro(\'ot\',this.value)"></div>'
    + '<div><label class="label" style="font-size:9.5px;color:#bfdbfe;text-transform:uppercase">Usuario</label><input class="input" style="height:32px;width:120px;background:rgba(30,58,138,.5);border-color:var(--blue500);color:#fff" value="'+esc(S.hUsu)+'" oninput="App.hFiltro(\'usu\',this.value)"></div>'
    + ((S.hCod||S.hOT||S.hUsu) ? '<button class="btn btn-sm btn-outline" style="height:32px;border-color:var(--blue400);color:#dbeafe" onclick="App.hLimpiar()">Limpiar</button>' : '')
    + '</div></div>';
  if(!regs.length){
    html += '<div class="empty-state">'+ic("fileText")+'<p class="t" style="color:var(--blue950)">'+(S.registros.length===0?"No hay registros aun":"No se encontraron resultados")+'</p><p class="s">'+(S.registros.length===0?"Empieza a registrar materiales en la pestana Registrar":"Prueba con otros filtros")+'</p></div>';
  } else {
    html += '<div style="display:flex;gap:.5rem;flex-wrap:wrap;padding:.7rem .9rem;background:var(--sl100);border-bottom:1px solid var(--sl300)">'
      + '<span class="badge blue" style="font-weight:800">'+regs.length+' registro(s)</span>'
      + '<span class="badge emerald" style="font-weight:800">Total: '+fmtC(totalU)+' unidades</span>'
      + '<span class="badge amber" style="font-weight:800">'+ots.size+' OT(s) distintas</span>'
      + '<span class="badge purple" style="font-weight:800">'+cods.size+' codigo(s) distintos</span>'
      + '</div><div class="table-scroll"><table class="tbl"><thead><tr>'
      + '<th>#</th><th>Fecha/Hora</th><th>Codigo</th><th>Descripcion</th><th class="r">Cant.</th><th class="c">Unidad</th><th class="c">OT</th><th class="c" style="background:var(--blue700);border:2px solid #172554">📄 Ver Documento</th><th>Vehiculo</th><th>Supervisor</th><th class="c">Entregado por</th><th class="c">Turno</th><th>Observacion</th>'
      + '</tr></thead><tbody>';
    for(var i=0;i<regs.length;i++){
      var r = regs[i];
      var legal = S.legalizadas.has(String(r.ot));
      html += '<tr'+(legal?' class="legalizada"':'')+'>'
        + '<td class="b">'+(i+1)+'</td>'
        + '<td style="font-size:11.5px;font-weight:600;white-space:nowrap;color:var(--blue900)">'+fmtF(r.fecha)+'</td>'
        + '<td><span class="badge blue">'+esc(r.codigo)+'</span></td>'
        + '<td style="max-width:250px"><div style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="'+esc(r.descripcion)+'">'+esc(r.descripcion)+'</div></td>'
        + '<td class="r">'+fmtC(r.cantidad)+'</td>'
        + '<td class="c">'+esc(r.unidad)+'</td>'
        + '<td class="c"><span class="badge blue-solid">'+esc(r.ot)+'</span>'+(S.ocultas.has(String(r.ot))?' <span class="badge red-solid" style="font-size:8.5px;padding:1px 5px">ELIMINADA</span>':'')+'</td>'
        + '<td class="c"><button class="mini-btn fix" onclick="App.verDocOT(\''+esc(String(r.ot).replace(/'/g,""))+'\')" title="Ver documento de la OT">'+ic("eye")+' Doc</button></td>'
        + '<td style="font-size:12px">'+esc(r.vehiculo)+'</td>'
        + '<td style="font-size:12px">'+esc(r.supervisor)+'</td>'
        + '<td class="c" style="font-size:12px">'+esc(r.usuario)+'</td>'
        + '<td class="c" style="font-size:11.5px;white-space:nowrap">'+(r.turno==="DIA"?"☀ DIA":"🌙 T/N")+'</td>'
        + '<td style="font-size:11.5px;max-width:180px">'+esc(r.observacion||"-")+'</td>'
        + '</tr>';
    }
    html += '</tbody></table></div>';
  }
  html += '</div>';
  return html;
}
var hTimer = null;
App.hFiltro = function(campo, val){
  S[campo === "cod" ? "hCod" : campo === "ot" ? "hOT" : "hUsu"] = val;
  if(hTimer) clearTimeout(hTimer);
  hTimer = setTimeout(function(){
    var cont = $("#tab-content"); if(cont){ cont.innerHTML = tabHistorial(); }
  }, 200);
};
App.hLimpiar = function(){ S.hCod = S.hOT = S.hUsu = ""; renderMain(); };
