/* ============================================================
   PAGINA: ADMIN - BASE DE MATERIALES
   ============================================================ */
function pageShell(titulo, sub, contenido){
  return headerHTML()
    + '<div class="page-top"><button class="btn btn-sm btn-outline" onclick="App.setView(\'main\')">'+ic("arrowLeft")+' Regresar</button></div>'
    + '<main class="main"><div class="space-y">'
    + '<div class="card"><div class="card-header grad-slate"><div class="card-title xl">'+ic("database")+' '+titulo+'</div><div class="card-desc">'+sub+'</div></div>'
    + contenido + '</div>'
    + '</div></main>'
    + '<footer class="footer"><div class="footer-in">Sistema de Registro de Materiales - '+new Date().getFullYear()+' · Sistema web · Datos en el servidor</div></footer>';
}
function renderAdmin(){
  var total = S.inventario.length, con = 0;
  S.inventario.forEach(function(m){ if(Number(m.stock) > 0) con++; });
  var last = DB.get("lastUpload", null);
  var c = '<div class="card-body" style="display:flex;flex-direction:column;gap:1.1rem">'
    + '<div class="stats-grid">'
    + statCard("blue","package","Total materiales", fmtN(total))
    + statCard("emerald","checkCircle","Con stock (> 0)", fmtN(con))
    + statCard("red","alertTriangle","Sin stock (agotados)", fmtN(total - con))
    + statCard("purple","upload","Ultima carga exitosa", last ? fmtF(last) : "Sin cargas")
    + '</div>'
    + '<div class="info-blue">'+ic("info")+' Sube un archivo Excel (.xlsx) o CSV con los materiales. El archivo debe tener encabezados en la primera fila.</div>'
    + '<div><label class="label" style="font-size:12px;text-transform:uppercase">Modo de carga</label>'
    + '<div class="modo-btns">'
    + '<button class="'+(S.adModo==="agregar"?"on":"")+'" onclick="S.adModo=\'agregar\';render()"><span class="t">'+ic("plus")+' Agregar / Actualizar</span><span class="d">Agrega materiales nuevos y actualiza los existentes (por codigo). Mantiene los que no esten en el archivo.</span></button>'
    + '<button class="'+(S.adModo==="reemplazar"?"on":"")+'" onclick="S.adModo=\'reemplazar\';render()"><span class="t">'+ic("trash")+' Reemplazar TODO</span><span class="d">Borra TODOS los materiales actuales y carga los del archivo. Cuidado: los stocks actuales se perderan.</span></button>'
    + '</div></div>'
    + '<div><label class="label" style="font-size:12px;text-transform:uppercase">Archivo Excel o CSV</label>'
    + '<div class="file-drop" onclick="byId(\'ad-file\').click()">'+ic("upload")
    + '<div class="t">'+(S.adName ? esc(S.adName) : "Seleccionar archivo")+'</div><div class="s">Formatos: .xlsx, .xls o .csv</div></div>'
    + '<input type="file" id="ad-file" accept=".xlsx,.xls,.csv,.txt" style="display:none" onchange="App.adFileSel(this)">'
    + '</div>'
    + (S.adPreview ? adPreviewHTML() : '')
    + '<div style="display:flex;gap:.6rem;justify-content:flex-end;flex-wrap:wrap">'
    + '<button class="btn btn-outline" onclick="App.descargarPlantilla()">'+ic("download")+' Descargar plantilla CSV</button>'
    + '<button class="btn btn-primary" onclick="App.adProcesar()"'+(!S.adFile?" disabled":"")+'>'+ic("upload")+' '+(S.adBusy?"Procesando...":"Agregar / Actualizar")+'</button>'
    + '</div>'
    + '<div class="card" style="box-shadow:none"><div class="card-header" style="background:var(--sl50)"><div class="card-title" style="font-size:.95rem">'+ic("info")+' Estructura del archivo (igual al reporte de inventario)</div></div>'
    + '<div class="card-body tight"><p style="font-size:12.5px;color:var(--sl600);margin-bottom:.5rem">El sistema reconoce tu Excel con estas columnas (con o sin acentos, tambien en CSV):</p>'
    + '<ul class="estructura">'
    + '<li><code>Código</code> - obligatoria</li>'
    + '<li><code>Tipo almacén</code></li>'
    + '<li><code>Almacén</code></li>'
    + '<li><code>Texto breve de material</code> - tambien: descripcion</li>'
    + '<li><code>Ubicación</code></li>'
    + '<li><code>Unidad medida base</code> - por defecto: UN</li>'
    + '<li><code>Stock total</code> - por defecto: 0</li>'
    + '<li><code>Observación</code> - NUEVO, REPARADO, RECUPERADO o vacia. Un mismo codigo puede venir en varias filas (se suman los stocks por observacion)</li>'
    + '</ul></div></div>'
    + '</div>';
  $("#app").innerHTML = pageShell("Administracion - Base de Materiales", "Carga y administra la base de materiales guardada en esta PC", c);
}
App.adFileSel = function(input){
  var f = input.files && input.files[0];
  if(!f) return;
  S.adFile = f; S.adName = f.name;
  parseArchivoInventario(f, function(mats, err){
    if(err){ toast("Error", err, "destructive"); return; }
    S.adPreview = mats;
    render();
  });
};
function adPreviewHTML(){
  var mats = S.adPreview.slice(0, 8);
  var html = '<div><p style="font-size:12px;font-weight:800;color:var(--sl700);margin-bottom:.4rem">Archivo cargado: '+esc(S.adName)+' — '+S.adPreview.length+' fila(s) detectada(s)'+(S.adPreview.length>8?" (mostrando las primeras 8)":"")+'</p>'
    + '<div style="overflow-x:auto;border:1px solid var(--sl300);border-radius:.5rem"><table class="tbl"><thead style="position:static"><tr><th>#</th><th>Codigo</th><th>Descripcion</th><th>Unidad</th><th>Ubicacion</th><th>Observacion</th><th class="r">Stock</th></tr></thead><tbody>';
  mats.forEach(function(m, i){
    var ov = String(m.observacion||"").toUpperCase();
    var obsCls = ov === "NUEVO" ? "emerald" : ov === "REPARADO" ? "amber" : ov === "RECUPERADO" ? "blue" : "slate";
    var obsBadge = ov ? '<span class="badge '+obsCls+'" style="font-size:9.5px">'+esc(m.observacion)+'</span>' : '<span style="color:var(--sl400)">—</span>';
    html += '<tr><td>'+(i+1)+'</td><td class="b">'+esc(m.codigo)+'</td><td>'+esc(m.textoBreve)+'</td><td>'+esc(m.unidadMedida)+'</td><td>'+esc(m.ubicacion)+'</td><td>'+obsBadge+'</td><td class="r">'+fmtC(Number(String(m.stock).replace(",","."))||0)+'</td></tr>';
  });
  html += '</tbody></table></div>'
    + '<p style="font-size:11.5px;color:var(--sl600);margin-top:.4rem">Si un codigo aparece en varias filas (ej: NUEVO y REPARADO), el sistema suma el stock y guarda la cantidad de cada observacion.</p></div>';
  return html;
}
App.adProcesar = function(){
  if(!S.adFile){ toast("Selecciona un archivo", null, "destructive"); return; }
  var modo = S.adModo;
  if(modo === "reemplazar" && !confirm("¿Reemplazar TODO el inventario actual?\n\nSe borraran los "+S.inventario.length+" materiales actuales y se cargaran los del archivo.\nLos stocks actuales se perderan.")) return;
  S.adBusy = true; render();
  parseArchivoInventario(S.adFile, function(mats, err){
    S.adBusy = false;
    if(err){ toast("Error", err, "destructive"); render(); return; }
    var r = aplicarMaterialesImportados(mats, modo);
    saveInventario();
    DB.set("lastUpload", new Date().toISOString());
    toast("Base de materiales actualizada",
      (modo==="reemplazar"?"Reemplazado completo. ":"")+
      "Total en archivo: "+r.totalMateriales+" · Insertados: "+r.nuevos+" · Actualizados: "+r.actualizados+
      (r.filasDup?" · Codigos con varias observaciones: "+r.filasDup+" filas sumadas":"")+
      (r.totalDescuentos?" · Descuentos por OTs pendientes: "+r.totalDescuentos:""));
    S.adFile = null; S.adName = ""; S.adPreview = null;
    render();
  });
};
App.descargarPlantilla = function(){
  var csv = "codigo,tipo_almacen,almacen,texto_breve,ubicacion,unidad_medida,stock,observacion\n";
  csv += "1000383,P03,1040.0,TORNILLO ACERO 5/8 X 2,E1M6P10D5,UN,50,\n";
  csv += "1021957,P01,1040.0,ACEITE HIDRAULICO AW68 (TAMBOR 220L),BODEGA-1,UN,440,\n";
  descargarArchivo("plantilla_materiales.csv", csv, "text/csv");
};
function descargarArchivo(nombre, contenido, tipo){
  var blob = new Blob([contenido], {type: tipo || "application/octet-stream"});
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url; a.download = nombre;
  document.body.appendChild(a); a.click();
  document.body.removeChild(a);
  setTimeout(function(){ URL.revokeObjectURL(url); }, 2000);
}

/* ============================================================
   PAGINA: ENTRADA POR PEDIDO
   ============================================================ */
function renderEntrada(){
  var found = S.eFound;
  var obs = found ? obsDeMaterial(found.codigo) : [];
  var obsBtns = "";
  if(found && obs.length){
    obsBtns = '<div class="info-amber" style="margin-top:.4rem"><p style="font-weight:800;font-size:10.5px;text-transform:uppercase;margin-bottom:.3rem">Indica cuantas unidades hay actualmente de cada observacion. Haz clic para asignar.</p><div class="obs-grid">'+obsGridHTML(obs, S.eObs, "entrada", -1).replace('<div class="info-amber">','<div>')+'</div></div>';
  }
  var c = '<div class="card-body" style="display:flex;flex-direction:column;gap:1.1rem">'
    + '<div class="info-blue">'+ic("info")+' Ingresa el codigo del material. Si existe, los campos se llenaran automaticamente.</div>'
    + '<div><label class="label">'+ic("search")+' Codigo del Material <span class="req">*</span></label>'
    + '<div class="row"><input id="e-cod" class="input dark grow" autocomplete="off" value="'+esc(S.eCod)+'" oninput="S.eCod=this.value;App.eAuto()" onkeydown="if(event.key===\'Enter\')App.eBuscar()">'
    + '<button class="btn btn-primary" onclick="App.eBuscar()">'+ic("search")+' '+(S.eBuscando?"Buscando...":"Buscar")+'</button></div>'
    + (found === true ? '<div class="exitosa-card" style="margin-top:.5rem;padding:.6rem .8rem"><h4 style="margin:0">'+ic("checkCircle")+' Material encontrado en el sistema</h4></div>'+obsBtns : '')
    + (found === false ? '<div class="info-red" style="margin-top:.5rem">'+ic("alertTriangle")+' <b>Material no encontrado</b> — El codigo no existe. Llena los campos manualmente para crear un material nuevo.</div>' : '')
    + '</div>'
    + '<div class="grid3">'
    + '<div><label class="label" style="font-size:11px">Tipo de almacen</label><input class="input" value="'+esc(S.eTA)+'" oninput="S.eTA=this.value"></div>'
    + '<div><label class="label" style="font-size:11px">Almacen</label><input class="input" value="'+esc(S.eAlm)+'" oninput="S.eAlm=this.value"></div>'
    + '<div><label class="label" style="font-size:11px">Ubicacion (opcional)</label><input class="input" value="'+esc(S.eUbic)+'" oninput="S.eUbic=this.value"></div>'
    + '</div>'
    + '<div><label class="label">Descripcion del Material <span class="req">*</span></label><input class="input dark" value="'+esc(S.eDesc)+'" oninput="S.eDesc=this.value"></div>'
    + '<div class="grid2i">'
    + '<div><label class="label">Cantidad a Ingresar <span class="req">*</span></label><input type="number" step="0.01" min="0" class="input dark" value="'+esc(S.eCant)+'" oninput="S.eCant=this.value"></div>'
    + '<div><label class="label">Unidad de Medida</label><input class="input dark" placeholder="UN" value="'+esc(S.eUni)+'" oninput="S.eUni=this.value"></div>'
    + '</div>'
    + '<div><label class="label">Observacion (opcional)</label>'
    + '<div class="tipo-btns">'+["NUEVO","REPARADO","RECUPERADO"].map(function(o){ return '<button type="button" class="'+(S.eObs===o?"on":"")+'" onclick="App.eObsSet(\''+o+'\')" style="'+(S.eObs===o?"background:var(--pur600);border-color:var(--pur700);color:#fff":"")+'">'+o+'</button>'; }).join("")
    + '<button class="btn-ghost btn-sm" onclick="App.eObsSet(\'\')">LIMPIAR</button></div>'
    + '<input class="input" style="margin-top:.4rem" placeholder="Escribe una observacion o selecciona una opcion arriba" value="'+esc(S.eObs)+'" oninput="S.eObs=this.value"></div>'
    + (S.eCant && Number(S.eCant) > 0 ? '<div class="info-blue">'+ic("info")+' '+(found===true ? 'La cantidad <b>sumara al stock actual</b> del material ('+fmtC(found2Stock())+' → '+fmtC(found2Stock()+Number(S.eCant))+')' : 'Se creara como <b>nuevo material</b> en la base de datos')+'</div>' : '')
    + '<div style="display:flex;justify-content:flex-end;gap:.6rem">'
    + '<button class="btn btn-outline red" onclick="App.eLimpiar()">LIMPIAR</button>'
    + '<button class="btn btn-emerald" onclick="App.eGuardar()">'+ic("plus")+' REGISTRAR ENTRADA</button></div>'
    + '<div><div class="card-title" style="font-size:.95rem;color:var(--sl800)">'+ic("trendingUp")+' Materiales ingresados en esta sesion</div>'
    + '<div class="sesion-card" style="margin-top:.5rem">'
    + (!S.eSesion.length ? '<div class="empty-state" style="height:120px"><div class="t" style="font-size:13px;color:var(--sl500)">No hay entradas registradas aun</div></div>'
      : S.eSesion.slice(0,20).map(function(e2){
        return '<div class="sesion-item"><div class="cd"><span>'+esc(e2.codigo)+'</span><span class="badge '+(e2.esNuevo?"purple":"emerald")+'">'+(e2.esNuevo?"NUEVO":"EXISTENTE")+' +'+fmtC(e2.cantidad)+' '+esc(e2.unidad)+'</span></div>'
          + '<div class="ds">'+esc(e2.descripcion)+'</div>'
          + '<div class="mt"><span>'+fmtF(e2.fecha)+'</span>'+(e2.observacion?'<span>Obs: '+esc(e2.observacion)+'</span>':'')+'</div></div>';
      }).join(""))
    + '</div></div>'
    + '</div>';
  $("#app").innerHTML = pageShell("Entrada por Orden de Pedido", "Ingresa materiales al inventario (guardado en esta PC)", c);
}
function found2Stock(){ return S.eFound && S.eFound.stock != null ? Number(S.eFound.stock) : 0; }
/* Mientras se digita el codigo en Entrada: si es EXACTO, llena descripcion/unidad/ubicacion solo,
   sin Enter. Restaura el cursor en el mismo lugar (no interrumpe la escritura). */
App.eAuto = function(){
  if(S._eAutoT) clearTimeout(S._eAutoT);
  S._eAutoT = setTimeout(function(){
    S._eAutoT = null;
    var cod = String(S.eCod||"").trim();
    if(!cod) return;
    var m = matByCodigo(cod);
    if(m && S.eFound !== true){
      S.eFound = true; S.eDesc = m.textoBreve; S.eUni = m.unidadMedida; S.eUbic = m.ubicacion || ""; S.eTA = m.tipoAlmacen || ""; S.eAlm = m.almacen || "";
      render();
      var inp = byId("e-cod");
      if(inp){ try{ inp.focus(); var L = String(S.eCod||"").length; inp.setSelectionRange(L, L); }catch(e){} }
    }
  }, 400);
};
App.eObsSet = function(v){ S.eObs = v; render(); };
App.eBuscar = function(){
  var cod = String(S.eCod||"").trim();
  if(!cod){ toast("Falta codigo","Ingresa el codigo del material","destructive"); return; }
  var m = matByCodigo(cod);
  if(m){
    S.eFound = true; S.eDesc = m.textoBreve; S.eUni = m.unidadMedida; S.eUbic = m.ubicacion || ""; S.eTA = m.tipoAlmacen || ""; S.eAlm = m.almacen || "";
    toast("Material encontrado", m.codigo + " — " + m.textoBreve);
  } else {
    S.eFound = false;
    toast("Material no encontrado","El codigo no existe. Llena los campos manualmente para crear un material nuevo.","destructive");
  }
  render();
};
App.eLimpiar = function(){
  S.eCod = ""; S.eFound = null; S.eTA = ""; S.eAlm = ""; S.eDesc = ""; S.eCant = ""; S.eUni = "UN"; S.eUbic = ""; S.eObs = "";
  render();
};
App.eGuardar = function(){
  var cod = String(S.eCod||"").trim(), desc = String(S.eDesc||"").trim(), cant = String(S.eCant||"").trim();
  if(!cod){ toast("Falta codigo","Ingresa el codigo del material","destructive"); return; }
  if(!desc){ toast("Falta descripcion","Ingresa la descripcion del material","destructive"); return; }
  if(!cant || isNaN(Number(cant)) || Number(cant) <= 0){ toast("Cantidad invalida","La cantidad debe ser mayor a cero","destructive"); return; }
  var m = matByCodigo(cod);
  var esNuevo = !m;
  if(m){
    m.stock = Math.round((Number(m.stock||0) + Number(cant))*100)/100;
    m.textoBreve = desc; m.unidadMedida = String(S.eUni||"UN") || "UN";
    if(S.eUbic) m.ubicacion = S.eUbic;
    if(S.eTA) m.tipoAlmacen = S.eTA;
    if(S.eAlm) m.almacen = S.eAlm;
  } else {
    m = {id: uid(), codigo: cod, tipoAlmacen: S.eTA, almacen: S.eAlm, textoBreve: desc, ubicacion: S.eUbic,
      unidadMedida: String(S.eUni||"UN") || "UN", stock: Number(cant), observacion: "", createdAt: new Date().toISOString()};
    S.inventario.push(m);
  }
  saveInventario();
  if(S.eObs && ["NUEVO","REPARADO","RECUPERADO"].indexOf(String(S.eObs).toUpperCase()) >= 0){
    obsRegistrar(cod, S.eObs, Number(cant), "entrada");
    /* Actualiza las etiquetas de observacion visibles del material */
    var ovN = String(S.eObs).toUpperCase().trim();
    var tags = String(m.observacion||"").split(/[;,]/).map(function(s){ return s.trim(); }).filter(Boolean);
    if(tags.indexOf(ovN) < 0){ tags.push(ovN); m.observacion = tags.join(";"); saveInventario(); }
  }
  var entrada = {id: uid(), fecha: new Date().toISOString(), codigo: cod, descripcion: desc, cantidad: Number(cant), unidad: String(S.eUni||"UN"), observacion: S.eObs, usuario: S.usuario.username, esNuevo: esNuevo};
  S.entradas.unshift(entrada);
  saveEntradas();
  S.eSesion.unshift(entrada);
  toast(esNuevo ? "✅ Nuevo material creado" : "✅ Entrada registrada", cod+" | +" + fmtC(Number(cant)) + " " + String(S.eUni||"UN") + (esNuevo ? "" : " | Stock: " + fmtC(m.stock)));
  S.eCod = ""; S.eFound = null; S.eTA = ""; S.eAlm = ""; S.eDesc = ""; S.eCant = ""; S.eUni = "UN"; S.eUbic = ""; S.eObs = "";
  render();
};

/* ============================================================
   PAGINA: PENDIENTES POR LEGALIZAR
   ============================================================ */
function otsPendientes(){
  return otsAgrupadas().filter(function(o){ return !S.legalizadas.has(o.ot); });
}
function registrosDeOT(ot){
  return S.registros.filter(function(r){ return String(r.ot) === String(ot); });
}
function renderPendientes(){
  var pend = otsPendientes();
  var usuF = String(S.pUsu||"").toLowerCase();
  var matF = String(S.pMat||"").toLowerCase();
  var otF = String(S.pOT||"").toLowerCase();
  var usuarios = new Set(); S.registros.forEach(function(r){ usuarios.add(r.usuario); });
  var filtradas = pend.filter(function(o){
    if(otF && o.ot.toLowerCase().indexOf(otF) < 0) return false;
    var regs = registrosDeOT(o.ot);
    if(usuF && !regs.some(function(r){ return String(r.usuario).toLowerCase().indexOf(usuF) >= 0; })) return false;
    if(matF && !regs.some(function(r){ return String(r.codigo).toLowerCase().indexOf(matF) >= 0 || String(r.descripcion).toLowerCase().indexOf(matF) >= 0; })) return false;
    return true;
  });
  var totalU = 0; pend.forEach(function(o){ registrosDeOT(o.ot).forEach(function(r){ totalU += Number(r.cantidad)||0; }); });
  var c = '<div class="card-body" style="display:flex;flex-direction:column;gap:1rem">'
    + '<div class="stats-grid" style="grid-template-columns:repeat(2,1fr)">'
    + statCard("amber","clock","Materiales pendientes", fmtN(pend.length))
    + statCard("purple","package","Total unidades", fmtC(totalU))
    + '</div>'
    + '<div class="row">'
    + '<div class="grow" style="max-width:220px"><label class="label" style="font-size:10.5px;text-transform:uppercase">Usuario</label>'
    + '<select class="input" onchange="S.pUsu=this.value;render()"><option value="">Todos los usuarios</option>'
    + Array.from(usuarios).map(function(u){ return '<option value="'+esc(u)+'"'+(S.pUsu===u?" selected":"")+'>'+esc(u)+'</option>'; }).join("")
    + '</select></div>'
    + '<div class="grow"><label class="label" style="font-size:10.5px;text-transform:uppercase">Filtrar material</label><input class="input" value="'+esc(S.pMat)+'" oninput="App.pFiltro(\'mat\',this.value)"></div>'
    + '<div class="grow" style="max-width:180px"><label class="label" style="font-size:10.5px;text-transform:uppercase">Filtrar OT</label><input class="input" value="'+esc(S.pOT)+'" oninput="App.pFiltro(\'ot\',this.value)"></div>'
    + ((S.pUsu||S.pMat||S.pOT) ? '<button class="btn btn-outline" onclick="App.pLimpiar()">Limpiar filtros</button>' : '')
    + '<div style="flex:1"></div>'
    + '<button class="btn btn-emerald" onclick="App.abrirSync()">'+ic("upload")+' Sincronizar Legalizadas</button>'
    + '</div>';
  if(!filtradas.length){
    c += '<div class="empty-state" style="border:1px solid var(--sl300);border-radius:.6rem">'+ic("checkCircle")+'<p class="t">No hay materiales pendientes</p><p class="s">'+(pend.length===0?"Todas las OTs estan legalizadas":"Prueba con otros filtros")+'</p></div>';
  } else {
    filtradas.forEach(function(o){
      var regs = registrosDeOT(o.ot);
      var primera = regs.reduce(function(a,r){ return !a || r.fecha < a ? r.fecha : a; }, null);
      var ultima = o.fecha;
      var totalOT = regs.reduce(function(a,r){ return a + (Number(r.cantidad)||0); }, 0);
      c += '<div class="pending-ot"><div class="head"><div class="badges">'
        + '<span class="badge blue-solid lg">OT: '+esc(o.ot)+'</span>'
        + '<span class="badge amber">'+regs.length+' materiales</span>'
        + '<span class="badge purple">Total: '+fmtC(totalOT)+'</span>'
        + '</div><span style="font-size:11px;color:var(--sl500)">Primer registro: '+fmtF(primera)+' · Ultimo: '+fmtF(ultima)+'</span>'
        + '<button class="btn btn-sm btn-outline amber" onclick="App.abrirSacar(\''+esc(o.ot)+'\')"'+(S.isMobile?" disabled":"")+'>Sacar de pendientes</button></div>'
        + resumenOTHTML(regs)
        + '</div>';
    });
  }
  c += '</div>';
  $("#app").innerHTML = pageShell("Materiales Pendientes por Legalizar", "OTs que aun no han sido legalizadas", c);
}
function resumenOTHTML(regs){
  var html = '<div class="resumen-box"><h5>Resumen de la OT:</h5><div style="overflow-x:auto"><table class="tbl"><thead style="position:static"><tr>'
    + '<th>#</th><th>Codigo</th><th>Descripcion</th><th class="r">Cant.</th><th>Unidad</th><th class="c">Turno</th><th class="c">Entregado por</th><th>Fecha</th><th>Observacion</th></tr></thead><tbody>';
  regs.forEach(function(r, i){
    html += '<tr><td>'+(i+1)+'</td><td class="b">'+esc(r.codigo)+'</td><td>'+esc(r.descripcion)+'</td><td class="r">'+fmtC(r.cantidad)+'</td><td>'+esc(r.unidad)+'</td><td class="c" style="font-size:11.5px">'+(r.turno==="DIA"?"☀ DIA":"🌙 T/N")+'</td><td class="c" style="font-size:11.5px">'+esc(r.usuario)+'</td><td style="font-size:11px">'+fmtF(r.fecha)+'</td><td style="font-size:11.5px">'+esc(r.observacion||"-")+'</td></tr>';
  });
  html += '</tbody></table></div></div>';
  return html;
}
var pTimer = null;
App.pFiltro = function(campo, val){
  S[campo === "mat" ? "pMat" : "pOT"] = val;
  if(pTimer) clearTimeout(pTimer);
  pTimer = setTimeout(render, 250);
};
App.pLimpiar = function(){ S.pUsu = S.pMat = S.pOT = ""; render(); };
App.abrirSacar = function(ot){
  S.pSacar = ot;
  var regs = registrosDeOT(ot);
  openModal('lg','grad-slate', ic("checkCircle")+' Sacar OT '+esc(ot)+' de pendientes', 'Se marcara como LEGALIZADA','',
    '<div class="modal-body" style="padding:0">'+resumenOTHTML(regs)+'</div>'
    + '<div class="modal-foot"><button class="btn btn-outline" onclick="App.cerrarModal()">Cancelar</button><button class="btn btn-emerald" onclick="App.confirmarSacar()">'+ic("check")+' Si, sacar de pendientes</button></div>');
};
App.confirmarSacar = function(){
  S.legalizadas.add(String(S.pSacar));
  saveSets();
  S.pSacar = null;
  App.cerrarModal(); render();
  toast("✅ OT legalizada","La OT salio de la lista de pendientes");
};
App.abrirSync = function(){
  S.pSyncOpen = true; S.pSyncFile = null; S.pSyncResult = null;
  openModal('lg','grad-emerald', ic("upload")+' Sincronizar Legalizadas', 'Sube el archivo de OTs legalizadas','');
  renderModalContent();
};
function syncHTML(){
  var html = '<div class="modal-body" style="display:flex;flex-direction:column;gap:1rem">';
  if(!S.pSyncResult){
    html += '<div class="info-blue">'+ic("info")+' Sube el Excel de salida de materiales de SAP (legalizados). El sistema lo analiza, busca tus OTs pendientes por <b>Documento Sap</b>, por <b>nombre del operador</b> o por <b>codigo de material</b>, y te muestra las coincidencias ANTES de legalizar.</div>'
      + '<div><p style="font-size:11px;font-weight:800;color:var(--sl600);text-transform:uppercase;margin-bottom:.4rem">Estructura del archivo (como OCASTILO.XLSX):</p>'
      + '<div style="display:flex;gap:.35rem;flex-wrap:wrap">'+["Codigo","Texto breve de material","Documento Sap","Fe.contabilizacion","Cantidad","Usuario","Orden","Vehiculo","Reserva","Observacion"].map(function(c){ return '<span class="badge slate">'+c+'</span>'; }).join("")+'</div>'
      + '<p style="font-size:11.5px;color:var(--sl600);margin-top:.45rem">\u2022 Las <b>Cantidades negativas</b> se cuentan como salida. \u2022 El nombre del operador puede venir repartido en Orden + Vehiculo + Reserva (el sistema lo une automaticamente). \u2022 Las filas sin codigo se ignoran.</p></div>'
      + '<div class="file-drop" onclick="byId(\'sync-file\').click()">'+ic("upload")+'<div class="t">'+(S.pSyncFile?esc(S.pSyncFile.name):"Seleccionar archivo")+'</div><div class="s">Formatos: .xlsx, .xls o .csv</div></div>'
      + '<input type="file" id="sync-file" accept=".xlsx,.xls,.csv,.txt" style="display:none" onchange="App.syncFileSel(this)">'
      + '<div style="display:flex;justify-content:flex-end;gap:.5rem"><button class="btn btn-outline" onclick="App.cerrarModal()">Cerrar</button>'
      + '<button class="btn btn-emerald" onclick="App.syncProcesar()"'+(!S.pSyncFile?" disabled":"")+'>'+ic("upload")+' Analizar archivo</button></div>';
  } else {
    var r = S.pSyncResult;
    if(!r.aplicado){
      html += '<h4 style="font-weight:800">Reporte del archivo</h4><p style="font-size:12.5px;color:var(--sl600)">Revisa las coincidencias y confirma para legalizar</p>'
        + '<div class="report-stats">'
        + '<div class="c" style="background:var(--blue50);border-color:var(--blue400)"><div class="k" style="color:var(--blue900)">Filas leidas</div><div class="v" style="color:var(--blue900)">'+r.stats.filas+'</div></div>'
        + '<div class="c" style="background:var(--pur50);border-color:var(--pur500)"><div class="k" style="color:var(--pur700)">Documentos Sap</div><div class="v" style="color:var(--pur700)">'+r.stats.documentos+'</div></div>'
        + '<div class="c" style="background:var(--am50);border-color:var(--am500)"><div class="k" style="color:var(--am700)">Codigos de material</div><div class="v" style="color:var(--am700)">'+r.stats.codigos+'</div></div>'
        + '<div class="c" style="background:var(--em50);border-color:var(--em500)"><div class="k" style="color:var(--em800)">Unidades consumidas</div><div class="v" style="color:var(--em800)">'+fmtC(r.stats.unidades)+'</div></div>'
        + '</div>'
        + (r.stats.sinCodigo ? '<p style="font-size:11.5px;color:var(--sl500)">'+r.stats.sinCodigo+' fila(s) sin codigo de material fueron ignoradas.</p>' : '');
      if(r.detalle.length){
        html += '<p style="font-size:12px;font-weight:800;color:var(--sl700)">OTs pendientes que coinciden con el archivo ('+r.detalle.length+'):</p>'
          + '<div style="max-height:250px;overflow-y:auto;border:1px solid var(--sl200);border-radius:.5rem">';
        r.detalle.forEach(function(d){
          var cls = d.razon.indexOf("codigo") >= 0 ? "amber" : d.razon.indexOf("Documento") >= 0 ? "purple" : "blue";
          html += '<div class="rep-item" style="border-bottom:1px solid var(--sl100)"><div class="l1" style="display:flex;gap:.4rem;align-items:center;flex-wrap:wrap">OT: <b>'+esc(d.ot)+'</b> <span class="badge '+cls+'" style="font-size:9px">'+esc(d.razon)+'</span>'+(d.clave?'<span class="badge outline" style="font-size:9px">'+esc(d.clave)+'</span>':'')+'</div>'
            + '<div class="l2">Vehiculo: '+esc(d.vehiculo)+' \u00b7 Supervisor: '+esc(d.supervisor)+' \u00b7 '+d.materiales+' material(es)</div></div>';
        });
        html += '</div>';
      } else {
        html += '<div class="info-red">'+ic("alertTriangle")+' <b>No se encontraron coincidencias</b> \u2014 Ninguna OT pendiente coincide con este archivo (ni por Documento Sap, ni por nombre, ni por codigos)</div>';
      }
      html += '<div style="display:flex;justify-content:flex-end;gap:.5rem"><button class="btn btn-outline" onclick="App.cerrarSync()">Cancelar</button>'
        + (r.detalle.length ? '<button class="btn btn-emerald" onclick="App.syncConfirmar()">'+ic("check")+' Confirmar legalizar ('+r.detalle.length+')</button>' : '<button class="btn btn-primary" onclick="App.cerrarSync()">Cerrar</button>')
        + '</div>';
    } else {
      html += '<div class="info-blue" style="background:var(--em50);border-color:var(--em500)">'+ic("checkCircle")+' <b style="color:var(--em800)">'+r.detalle.length+' OT(s) legalizada(s) correctamente</b><p style="font-size:12px;color:var(--em800);margin-top:.3rem">Las OTs coincidentes salieron de la lista de pendientes. El historial de movimientos se conserva intacto.</p></div>'
        + '<div style="display:flex;justify-content:flex-end"><button class="btn btn-primary" onclick="App.cerrarSync()">Cerrar</button></div>';
    }
  }
  html += '</div>';
  return html;
}
App.syncFileSel = function(input){
  var f = input.files && input.files[0];
  if(!f) return;
  S.pSyncFile = f;
  renderModalContent();
};
App.syncProcesar = function(){
  if(!S.pSyncFile){ toast("Selecciona un archivo", null, "destructive"); return; }
  var reader = new FileReader();
  reader.onload = function(e){
    var heads = [], data = [];
    var name = S.pSyncFile.name.toLowerCase();
    try{
      if(name.endsWith(".csv") || name.endsWith(".txt")){
        var text = new TextDecoder().decode(new Uint8Array(e.target.result));
        var sep = (text.split(/\r?\n/)[0]||"").indexOf(";")>=0 ? ";" : ",";
        var lines = text.split(/\r?\n/).filter(function(l){ return l.trim(); });
        if(lines.length){
          heads = parseCSVLine(lines[0], sep);
          for(var i=1;i<lines.length;i++) data.push(parseCSVLine(lines[i], sep));
        }
      } else {
        var wb = XLSX.read(new Uint8Array(e.target.result), {type:"array"});
        var ws = wb.Sheets[wb.SheetNames[0]];
        var rows = XLSX.utils.sheet_to_json(ws, {header:1});
        if(rows.length){
          heads = rows[0].map(function(x){ return String(x||"").trim(); });
          data = rows.slice(1).map(function(r){ return r.map(function(x){ return String(x==null?"":x).trim(); }); });
        }
      }
    }catch(err2){ toast("Error","No se pudo leer el archivo: "+err2.message,"destructive"); return; }
    if(!data.length){ toast("Error","El archivo no tiene filas de datos","destructive"); return; }
    /* Extrae las llaves del reporte SAP (estructura OCASTILO.XLSX) */
    var K = {docs:new Set(), docsMat:{}, ordenes:new Set(), nombres:new Set(), codigos:new Set(), filas:0, filasConCod:0, unidades:0};
    extractSyncKeys(heads, data, K);
    K.nombresArr = Array.from(K.nombres);
    if(!K.docs.size && !K.ordenes.size && !K.nombres.size && !K.codigos.size){
      toast("Error","No se encontraron documentos, nombres ni codigos de material en el archivo","destructive"); return;
    }
    /* Busca coincidencias de cada OT pendiente y GUARDA la razon (no legaliza todavia) */
    var pend = otsPendientes();
    var detalle = [];
    pend.forEach(function(o){
      var regs = registrosDeOT(o.ot);
      var hit = syncBuscarMatch(o, regs, K);
      if(hit){
        detalle.push({ot: String(o.ot), vehiculo: regs.length ? regs[0].vehiculo : "-", supervisor: regs.length ? regs[0].supervisor : "-", materiales: regs.length, razon: hit.razon, clave: hit.clave});
      }
    });
    S.pSyncResult = {
      aplicado: false,
      stats: {filas: K.filas, sinCodigo: K.filas - K.filasConCod, documentos: K.docs.size, nombres: K.nombres.size, codigos: K.codigos.size, unidades: Math.round(K.unidades*100)/100},
      detalle: detalle
    };
    toast(detalle.length ? "Archivo analizado: "+detalle.length+" OT(s) coinciden" : "Sin coincidencias", detalle.length ? "Revisa la lista y confirma para legalizar" : "Ninguna OT pendiente coincide con el archivo", detalle.length ? "success" : "destructive");
    renderModalContent();
  };
  reader.readAsArrayBuffer(S.pSyncFile);
};
/* Busca por que coincide una OT pendiente con las llaves del archivo */
function syncBuscarMatch(o, regs, K){
  var otN = normNombre(o.ot);
  var vehN = normNombre(regs.length ? regs[0].vehiculo : "");
  if(K.docs.has(String(o.ot).trim())) return {razon: "Documento Sap", clave: String(o.ot)};
  if(otN && K.ordenes.has(otN)) return {razon: "Orden del archivo", clave: String(o.ot)};
  if(otN && K.nombres.has(otN)) return {razon: "Nombre del operador", clave: String(o.ot)};
  if(otN && otN.length >= 4){
    var hit = null;
    for(var i=0;i<K.nombresArr.length;i++){ if(K.nombresArr[i].indexOf(otN) >= 0){ hit = K.nombresArr[i]; break; } }
    if(hit) return {razon: "Nombre del operador (parcial)", clave: hit};
  }
  if(vehN && vehN.length >= 4){
    if(K.nombres.has(vehN)) return {razon: "Vehiculo = operador", clave: vehN};
    var hit2 = null;
    for(var j=0;j<K.nombresArr.length;j++){ if(vehN.indexOf(K.nombresArr[j]) >= 0){ hit2 = K.nombresArr[j]; break; } }
    if(hit2) return {razon: "Vehiculo = operador", clave: hit2};
  }
  var mcs = [];
  regs.forEach(function(r){ var c = String(r.codigo); if(K.codigos.has(c) && mcs.indexOf(c) < 0) mcs.push(c); });
  if(mcs.length) return {razon: "Por codigo(s) de material", clave: mcs.slice(0,4).join(", ") + (mcs.length > 4 ? " +"+(mcs.length-4) : "")};
  return null;
}
/* Confirma la legalizacion de las OTs coincidentes */
App.syncConfirmar = function(){
  if(!S.pSyncResult || S.pSyncResult.aplicado) return;
  S.pSyncResult.detalle.forEach(function(d){ S.legalizadas.add(String(d.ot)); });
  saveSets();
  S.pSyncResult.aplicado = true;
  toast("\u2705 "+S.pSyncResult.detalle.length+" OT(s) legalizada(s)", "Las OTs coincidentes salieron de pendientes. El historial se conserva.", "success");
  renderModalContent(); render();
};
function normNombre(s){ return String(s||"").toLowerCase().trim().replace(/\s+/g," ").normalize("NFD").replace(/[\u0300-\u036f]/g,""); }
/* Extrae las llaves de sincronizacion del reporte SAP:
   Codigo | Texto breve | Documento Sap | Fe.contabilizacion | Cantidad | Usuario | Orden | Vehiculo | Reserva | Observacion */
function extractSyncKeys(heads, rows, K){
  var idx = {codigo:-1, docsap:-1, orden:-1, vehiculo:-1, reserva:-1, cantidad:-1};
  heads.forEach(function(h, i){
    var n = normCol(h);
    if((n === "codigo" || n === "cod" || n === "code") && idx.codigo < 0) idx.codigo = i;
    else if((n === "documentosap" || n === "documento" || n === "docsap" || n === "documentomaterial" || n === "documentsap") && idx.docsap < 0) idx.docsap = i;
    else if((n === "orden" || n === "ot" || n === "ordendetrabajo" || n === "norden" || n === "numerodeorden" || n === "ordenot") && idx.orden < 0) idx.orden = i;
    else if(n === "vehiculo" && idx.vehiculo < 0) idx.vehiculo = i;
    else if(n === "reserva" && idx.reserva < 0) idx.reserva = i;
    else if((n === "cantidad" || n === "cant") && idx.cantidad < 0) idx.cantidad = i;
  });
  rows.forEach(function(r){
    var val = function(i){ return i >= 0 ? String(r[i] == null ? "" : r[i]).trim() : ""; };
    var cod = val(idx.codigo);
    var doc = val(idx.docsap);
    var p1 = val(idx.orden), p2 = val(idx.vehiculo), p3 = val(idx.reserva);
    K.filas++;
    if(cod){ K.codigos.add(cod); K.filasConCod++; }
    if(doc){ K.docs.add(doc); if(cod){ if(!K.docsMat[doc]) K.docsMat[doc] = 0; K.docsMat[doc]++; } }
    if(p1) K.ordenes.add(normNombre(p1));
    var full = normNombre([p1, p2, p3].filter(function(x){ return x; }).join(" "));
    if(full) K.nombres.add(full);
    var cant = idx.cantidad >= 0 ? Number(String(r[idx.cantidad]).replace(",",".")) : 0;
    if(!isNaN(cant) && cant) K.unidades += Math.abs(cant);
  });
}
App.cerrarSync = function(){ S.pSyncOpen = false; S.pSyncResult = null; closeModal(); render(); };
