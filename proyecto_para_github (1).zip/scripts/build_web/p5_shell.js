/* ============ APP: objeto principal con acciones ============ */
var App = {};

/* ---- Login acciones (una sola ventana: usuario + contrasena) ---- */
App.renderLogin = function(){ renderLogin(); };
App.iniciarSesion = function(){
  var u = String(LOGIN.usuario||"").trim(), p = String(LOGIN.pass||"").trim();
  if(!u || !p){ toast("Acceso denegado","Debes ingresar usuario y contrasena completos","destructive"); return; }
  LOGIN.cargando = true; renderLogin();
  setTimeout(function(){
    LOGIN.cargando = false;
    var usuarios = DB.get("usuarios", []);
    var found = null;
    for(var i=0;i<usuarios.length;i++){
      if(usuarios[i].username.toLowerCase() === u.toLowerCase() && usuarios[i].password === p){ found = usuarios[i]; break; }
    }
    if(!found){
      LOGIN.intentos++;
      LOGIN.pass = "";
      toast("⛔ Acceso denegado", LOGIN.intentos >= 2 ? "Usuario o contrasena incorrectos. Contacta al administrador si no tienes acceso." : "Usuario o contrasena incorrectos. Intenta nuevamente.","destructive");
      renderLogin();
      return;
    }
    S.usuario = {username: found.username, nombre: found.nombre, nombreCompleto: found.nombreCompleto};
    DB.set("session", S.usuario);
    /* El usuario en sesion NO se agrega a la lista de supervisores (el supervisor es quien RECIBE, no quien entrega) */
    LOGIN.usuario = LOGIN.pass = ""; LOGIN.intentos = 0;
    entrarPrincipal(true);
  }, 300);
};
App.cerrarSesion = function(){
  if(!confirm("¿Cerrar sesion del sistema?")) return;
  DB.set("session", null);
  S.usuario = null; S.view = "login";
  render();
};

/* ---- Navegacion ---- */
App.setView = function(v){ S.view = v; window.scrollTo(0,0); render(); };
App.setTab = function(t){ S.tab = t; window.scrollTo(0,0); render(); };
/* El usuario con sesion abierta NUNCA aparece como supervisor:
   si una version anterior lo guardo en la lista (p.ej. al iniciar sesion), se elimina sola. */
function purgarSesionDeSupervisores(){
  if(!S.usuario) return;
  var propios = [S.usuario.nombreCompleto, S.usuario.nombre]
    .map(function(x){ return String(x||"").trim().toLowerCase(); })
    .filter(function(x){ return !!x; });
  if(!propios.length || !S.supervisores || !S.supervisores.length) return;
  var limpios = [], cambio = false;
  for(var i=0;i<S.supervisores.length;i++){
    if(propios.indexOf(String(S.supervisores[i]||"").trim().toLowerCase()) >= 0){ cambio = true; continue; }
    limpios.push(S.supervisores[i]);
  }
  if(cambio){ S.supervisores = limpios; saveSupervisores(); }
}

function entrarPrincipal(desdeLogin){
  S.view = "main"; S.tab = "registro";
  loadData();
  purgarSesionDeSupervisores();
  S.turno = turnoNow();
  S.welcome = !!desdeLogin;
  render();
  if(desdeLogin) setTimeout(mostrarWelcome, 350);
}

/* ---- Pantalla de bienvenida ---- */
var welcomeTimer = null;
var welcomeWipeTimer = null;
function mostrarWelcome(){
  /* Limpia timers de una bienvenida anterior (evita cierres inmediatos al reentrar) */
  if(welcomeTimer){ clearInterval(welcomeTimer); welcomeTimer = null; }
  if(welcomeWipeTimer){ clearTimeout(welcomeWipeTimer); welcomeWipeTimer = null; }
  var w = $("#welcome");
  var turnoD = S.turno === "DIA";
  var hora = new Date().getHours(), saludo = "Buenos dias";
  if(hora >= 12 && hora < 19) saludo = "Buenas tardes";
  else if(hora >= 19 || hora < 5) saludo = "Buenas noches";
  var nombre = nombreUsuario();
  var part = "";
  for(var i=0;i<34;i++){
    var sz = (4 + Math.random()*12).toFixed(0);
    part += '<div class="wc-particle" style="width:'+sz+'px;height:'+sz+'px;left:'+(Math.random()*100).toFixed(1)+'%;top:'+(Math.random()*100).toFixed(1)+'%;animation-duration:'+(3+Math.random()*4).toFixed(1)+'s;animation-delay:'+(Math.random()*3).toFixed(1)+'s;'+(Math.random()>.6?'background:rgba(251,191,36,.4)':'')+'"></div>';
  }
  var spark = "";
  for(var j=0;j<10;j++){
    spark += '<div class="wc-sparkle" style="left:'+(160+230*Math.cos(j/10*Math.PI*2)).toFixed(0)+'px;top:'+(120+170*Math.sin(j/10*Math.PI*2)).toFixed(0)+'px;font-size:'+(8+Math.random()*10).toFixed(0)+'px;animation-delay:'+(j/10*2).toFixed(1)+'s">✦</div>';
  }
  var grad = turnoD
    ? "radial-gradient(circle at 30% 20%, rgba(245,158,11,0.4) 0%, rgba(15,23,42,0.96) 60%), radial-gradient(circle at 80% 80%, rgba(236,72,153,0.3) 0%, transparent 50%)"
    : "radial-gradient(circle at 30% 20%, rgba(30,58,138,0.6) 0%, rgba(15,23,42,0.97) 60%), radial-gradient(circle at 80% 80%, rgba(124,58,237,0.4) 0%, transparent 50%)";
  w.innerHTML = '<div style="position:absolute;inset:0;background:'+grad+';overflow:hidden">'+part+'</div>'
    + '<div style="position:relative" class="wc-box">'
    + '<div class="wc-top"></div>'
    + '<div class="wc-inner">'+spark
    + '<span class="wc-emoji" id="wc1">📦</span>'
    + '<div class="wc-h1" id="wc2">¡'+saludo+'!</div>'
    + '<p class="wc-sub" id="wc3">Bienvenido al sistema de registro</p>'
    + '<div class="wc-avatar" id="wc4" style="background:linear-gradient(135deg,'+(turnoD?'#f59e0b,#ef4444':'#3b82f6,#7e22ce')+')">'+esc(iniciales(nombre))+'<div class="wc-prog" style="position:absolute;bottom:-18px;width:120%"></div></div>'
    + '<div class="wc-name" id="wc5">'+esc(nombre)+'</div>'
    + '<div class="wc-turno" id="wc6" style="background:'+(turnoD?'linear-gradient(90deg,#f59e0b,#ef4444)':'linear-gradient(90deg,#6366f1,#a855f7)')+';color:#fff"><div class="tt">'+(turnoD?'☀ TURNO DIA':'🌙 TURNO TARDE NOCHE')+'</div><div class="ts">'+(turnoD?'05:00 - 14:00':'14:01 - 22:00')+'</div></div>'
    + '<div class="wc-frase" id="wc7">Que tengas un excelente turno 🚀</div>'
    + '<div class="wc-line" id="wc8">'+ic("clock")+' '+new Date().toLocaleDateString("es-CO",{weekday:"long",day:"numeric",month:"long",year:"numeric"})+'</div>'
    + '<button class="wc-btn" id="wc9" onclick="App.cerrarWelcome()">COMENZAR A REGISTRAR →</button>'
    + '<div class="wc-prog"><i id="wc-prog" style="width:100%"></i></div>'
    + '<p class="wc-close">Cerrando automaticamente...</p>'
    + '</div></div>';
  w.classList.remove("hidden");
  requestAnimationFrame(function(){ w.classList.add("show"); });
  ["wc1","wc2","wc3","wc4","wc5","wc6","wc7","wc8","wc9"].forEach(function(id,i){
    setTimeout(function(){ var el = byId(id); if(el) el.classList.add("show"); }, 250 + i*330);
  });
  var prog = 100;
  welcomeTimer = setInterval(function(){
    prog -= 1.6;
    var p = byId("wc-prog"); if(p) p.style.width = Math.max(0,prog) + "%";
    if(prog <= 0) App.cerrarWelcome();
  }, 90);
}
App.cerrarWelcome = function(){
  var w = $("#welcome");
  if(welcomeTimer){ clearInterval(welcomeTimer); welcomeTimer = null; }
  if(w.classList.contains("hidden")) return;
  w.classList.remove("show");
  if(welcomeWipeTimer) clearTimeout(welcomeWipeTimer);
  welcomeWipeTimer = setTimeout(function(){ w.classList.add("hidden"); w.innerHTML = ""; }, 450);
};

/* ============ SHELL PRINCIPAL ============ */
function render(){
  if(S.view === "login"){ renderLogin(); return; }
  if(S.view === "admin"){ renderAdmin(); return; }
  if(S.view === "entrada"){ renderEntrada(); return; }
  if(S.view === "pendientes"){ renderPendientes(); return; }
  renderMain();
}
function renderMain(){
  /* Reloj y calendario: acoplados al panel lateral o flotantes en la posicion guardada */
  var docked = "", flotantes = "";
  WG_KEYS.forEach(function(pair){
    if(wgFloat(pair[0])) flotantes += '<div id="'+pair[1]+'" class="wg-float"></div>';
    else docked += '<div id="'+pair[1]+'"></div>';
  });
  var html = headerHTML()
    + '<div class="main-flow">'
    + '<main class="main">'
    + statsHTML()
    + '<div class="space-y" style="margin-top:1.2rem">'
    + tabsHTML()
    + (S.tab === "registro" ? tabRegistro() : S.tab === "ots" ? tabOTs() : S.tab === "inventario" ? tabInventario() : tabHistorial())
    + '</div></main>'
    + (docked ? '<aside class="side-col">'+docked+'</aside>' : '')
    + '</div>'
    + flotantes
    + '<footer class="footer"><div class="footer-in">Sistema de Registro de Materiales - '+new Date().getFullYear()+' · Sistema web · Datos guardados automaticamente en el servidor</div></footer>';
  $("#app").innerHTML = html;
  renderClock(); renderCalendar(); wgApply();
}
function headerHTML(){
  var provCount = S.provisionales.length;
  return '<header class="hdr"><div class="hdr-in">'
    + '<div class="hdr-brand"><div class="hdr-logo">'+ic("boxes","ic-28")+'</div><div><h1 class="hdr-title">Registro de Materiales</h1><p class="hdr-sub">Sistema de control de consumo por vehiculo y OT · WEB</p></div></div>'
    + '<div class="hdr-actions">'
    + '<span class="hdr-user">'+ic("shieldCheck")+' '+esc(nombreUsuario())+'</span>'
    + '<button class="btn btn-sm btn-outline amber" onclick="App.setView(\'admin\')">'+ic("database")+' Base de datos</button>'
    + '<button class="btn btn-sm btn-outline emerald" onclick="App.setView(\'entrada\')">'+ic("trendingUp")+' Entrada por Pedido</button>'
    + '<button class="btn btn-sm btn-outline amber" onclick="App.setView(\'pendientes\')">'+ic("clock")+' Pendientes</button>'
    + '<span class="prov-wrap"><button class="btn btn-sm btn-purple" onclick="App.abrirProvisional()">'+ic("layers")+' Provisional de Despacho</button>'
    + (provCount > 0 ? '<button class="prov-badge" onclick="App.abrirProvGuardadas()" title="'+provCount+' provisional(es) guardado(s) - Click para VER o ELIMINAR">'+ic("trash")+' Guardados: '+provCount+'</button>' : '')
    + '</span>'
    + '<button class="btn btn-sm btn-outline blue" onclick="App.abrirRespaldo()" title="Exportar o importar respaldo de datos">'+ic("save")+' Respaldo</button>'
    + '<button class="btn btn-sm btn-outline red" onclick="App.cerrarSesion()">'+ic("logOut")+' Cerrar sesion</button>'
    + '</div></div></header>'
    + '<div id="save-bar" class="save-bar"></div>';
}
function statsHTML(){
  var hoy = new Date().toDateString();
  var regsHoy = S.registros.filter(function(r){ try{ return new Date(r.fecha).toDateString() === hoy; }catch(e){ return false; } }).length;
  var sups = new Set(S.registros.map(function(r){ return r.supervisor; }));
  return '<div class="stats-grid">'
    + statCard("blue","package","Materiales", fmtN(S.inventario.length))
    + statCard("emerald","clipboard","Total registros", fmtN(S.registros.length))
    + statCard("amber","calendar","Hoy", fmtN(regsHoy))
    + statCard("purple","users","Supervisores", fmtN(sups.size))
    + '</div>';
}
function statCard(color, icon, label, value){
  return '<div class="stat-card"><div class="stat-ic '+color+'">'+ic(icon,"ic-22")+'</div><div style="min-width:0"><div class="stat-label">'+label+'</div><div class="stat-value">'+value+'</div></div></div>';
}
function tabsHTML(){
  function tb(val, icon, label){
    return '<button class="tab-btn'+(S.tab===val?" active":"")+'" onclick="App.setTab(\''+val+'\')">'+ic(icon)+'<span>'+label+'</span></button>';
  }
  return '<div class="tabs-list">'
    + tb("registro","package","Registrar")
    + tb("ots","fileText","Ordenes (OT)")
    + tb("inventario","database","Inventario")
    + tb("historial","history","Historial")
    + '</div>';
}

/* ============ RELOJ ANALOGO ============
   El tick actualiza SOLO agujas/hora digital (sin reconstruir la tarjeta)
   para no interrumpir el arrastre ni perder el foco. */
var clockTimer = null;
function renderClock(){
  var cont = $("#side-clock"); if(!cont) return;
  var tics = "", nums = "", mins = "";
  for(var i=0;i<12;i++){
    var a = Math.PI/180*(30*i-90);
    var x1 = 100+78*Math.cos(a), y1 = 100+78*Math.sin(a), x2 = 100+88*Math.cos(a), y2 = 100+88*Math.sin(a);
    tics += '<line x1="'+x1+'" y1="'+y1+'" x2="'+x2+'" y2="'+y2+'" stroke="#1e293b" stroke-width="'+(i%3===0?4:2)+'" stroke-linecap="round"/>';
  }
  for(var j=0;j<12;j++){
    var n = j===0?12:j, a2 = Math.PI/180*(30*j-60);
    nums += '<text x="'+(100+65*Math.cos(a2))+'" y="'+(100+65*Math.sin(a2))+'" text-anchor="middle" dominant-baseline="central" font-size="16" font-weight="bold" fill="#1e293b">'+n+'</text>';
  }
  for(var k=0;k<60;k++){
    if(k%5===0) continue;
    var a3 = Math.PI/180*(6*k-90);
    mins += '<line x1="'+(100+84*Math.cos(a3))+'" y1="'+(100+84*Math.sin(a3))+'" x2="'+(100+88*Math.cos(a3))+'" y2="'+(100+88*Math.sin(a3))+'" stroke="#64748b" stroke-width="1"/>';
  }
  cont.innerHTML = '<div class="clock-card">'
    + wgGripHTML("reloj","reloj")
    + '<svg width="170" height="170" viewBox="0 0 200 200">'
    + '<circle cx="100" cy="100" r="95" fill="#f8fafc" stroke="#1e293b" stroke-width="3"/>'
    + '<circle cx="100" cy="100" r="90" fill="none" stroke="#cbd5e1" stroke-width="1"/>'
    + tics + nums + mins
    + '<g id="clk-h" transform="rotate(0 100 100)"><rect x="96" y="50" width="8" height="55" rx="4" fill="#1e3a8a" stroke="#1e293b" stroke-width="1"/></g>'
    + '<g id="clk-m" transform="rotate(0 100 100)"><rect x="97" y="30" width="6" height="75" rx="3" fill="#3b82f6" stroke="#1e293b" stroke-width="1"/></g>'
    + '<g id="clk-s" transform="rotate(0 100 100)"><line x1="100" y1="115" x2="100" y2="25" stroke="#ef4444" stroke-width="2" stroke-linecap="round"/></g>'
    + '<circle cx="100" cy="100" r="7" fill="#1e293b"/><circle cx="100" cy="100" r="3" fill="#ef4444"/>'
    + '</svg>'
    + '<div class="clock-digital"><span class="t" id="clk-dig">--:--:--</span><span class="ap" id="clk-ap"></span></div>'
    + '<div class="clock-date" id="clk-date"></div>'
    + '</div>';
  clockTick();
  if(clockTimer) clearInterval(clockTimer);
  clockTimer = setInterval(clockTick, 1000);
}
function clockTick(){
  var gh = byId("clk-h"); if(!gh) return;
  var d = new Date(), h = d.getHours(), m = d.getMinutes(), s = d.getSeconds();
  var hh = h % 12 || 12;
  gh.setAttribute("transform", "rotate(" + (30*hh + .5*m) + " 100 100)");
  byId("clk-m").setAttribute("transform", "rotate(" + (6*m + .1*s) + " 100 100)");
  byId("clk-s").setAttribute("transform", "rotate(" + (6*s) + " 100 100)");
  byId("clk-dig").textContent = String(hh).padStart(2,"0")+":"+String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
  byId("clk-ap").textContent = h >= 12 ? "PM" : "AM";
  byId("clk-date").textContent = d.toLocaleDateString("es-CO",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
}

/* ============ CALENDARIO CON FESTIVOS ============ */
var CAL = { mes: new Date().getMonth(), anio: new Date().getFullYear() };
function renderCalendar(){
  var cont = $("#side-cal"); if(!cont) return;
  var fest = festivos(CAL.anio);
  var festMap = {};
  fest.forEach(function(f){ festMap[f.fecha] = f.nombre; });
  var primerDia = new Date(CAL.anio, CAL.mes, 1);
  var diasMes = new Date(CAL.anio, CAL.mes+1, 0).getDate();
  var startDow = primerDia.getDay();
  var hoy = new Date();
  var celdas = "";
  for(var i=0;i<startDow;i++) celdas += '<div class="cal-day cal-other"></div>';
  var festivosMes = [];
  for(var d=1; d<=diasMes; d++){
    var iso = CAL.anio+"-"+String(CAL.mes+1).padStart(2,"0")+"-"+String(d).padStart(2,"0");
    var dow = new Date(CAL.anio, CAL.mes, d).getDay();
    var cls = "cal-day";
    if(dow === 0) cls += " dom";
    if(festMap[iso]) cls += " fest";
    if(hoy.getFullYear()===CAL.anio && hoy.getMonth()===CAL.mes && hoy.getDate()===d) cls += " today";
    celdas += '<div class="'+cls+'" title="'+(festMap[iso]||"")+'">'+d+'</div>';
    if(festMap[iso]) festivosMes.push({dia: d, nombre: festMap[iso]});
  }
  var festBanner = "";
  if(festivosMes.length){
    festBanner = '<div class="cal-festivos"><p>'+festivosMes.length+' festivo'+(festivosMes.length!==1?"s":"")+' en '+MESES[CAL.mes]+'</p><p style="font-weight:500;font-size:9px;color:#fcd34dcc">'+festivosMes.map(function(f){ return f.dia+": "+f.nombre; }).join(" · ")+'</p></div>';
  }
  cont.innerHTML = '<div class="cal-card">'
    + wgGripHTML("cal","calendario")
    + '<div class="cal-head"><button class="cal-nav" onclick="App.calNav(-1)">'+ic("chevronLeft")+'</button><span class="m">'+MESES[CAL.mes]+' '+CAL.anio+'</span><button class="cal-nav" onclick="App.calNav(1)">'+ic("chevronRight")+'</button></div>'
    + '<div class="cal-grid">'
    + ["D","L","M","M","J","V","S"].map(function(x){ return '<div class="cal-dow">'+x+'</div>'; }).join("")
    + celdas
    + '</div>'
    + '<div class="cal-legend"><span class="li"><span class="dot" style="background:rgba(239,68,68,.25);border:1px solid rgba(239,68,68,.5)"></span>Dom</span><span class="li"><span class="dot" style="background:rgba(139,92,246,.25);border:1px solid rgba(139,92,246,.5)"></span>Festivo</span></div>'
    + festBanner
    + '</div>';
}
App.calNav = function(dir){
  CAL.mes += dir;
  if(CAL.mes < 0){ CAL.mes = 11; CAL.anio--; }
  if(CAL.mes > 11){ CAL.mes = 0; CAL.anio++; }
  renderCalendar();
};

/* ============ WIDGETS ARRASTRABLES (reloj y calendario) ============
   Barra "☰ MOVER": mantén clic y arrastra -> el widget se despega del panel
   y queda flotante donde lo sueltes. Posicion persistida en la clave widgetPos.
   Boton "✕ Devolver": regresa el widget al panel lateral. */
var WG_KEYS = [["reloj","side-clock"],["cal","side-cal"]];
var WG_DRAG = null, wgTipShown = false;
function wgPos(){
  if(!S.widgetPos || typeof S.widgetPos !== "object" || Array.isArray(S.widgetPos)) S.widgetPos = {};
  return S.widgetPos;
}
function wgFloat(k){
  var p = wgPos()[k];
  return !!(p && p.float && isFinite(p.x) && isFinite(p.y));
}
function wgWrapId(k){ return k === "reloj" ? "side-clock" : "side-cal"; }
function wgClamp(k, p){
  var el = byId(wgWrapId(k));
  var w = (el && el.offsetWidth) || 212;
  var h = (el && el.offsetHeight) || 330;
  var maxX = Math.max(6, window.innerWidth - w - 6), maxY = Math.max(6, window.innerHeight - h - 6);
  if(!isFinite(p.x)) p.x = maxX;
  if(!isFinite(p.y)) p.y = 90;
  if(p.x < 6) p.x = 6;
  if(p.x > maxX) p.x = maxX;
  if(p.y < 6) p.y = 6;
  if(p.y > maxY) p.y = maxY;
}
function wgApply(){
  WG_KEYS.forEach(function(pair){
    var k = pair[0], el = byId(pair[1]);
    if(!el) return;
    var p = wgPos()[k];
    if(p && p.float){
      wgClamp(k, p);
      el.classList.add("wg-float");
      el.style.left = p.x + "px";
      el.style.top = p.y + "px";
    } else {
      el.classList.remove("wg-float");
      el.style.left = ""; el.style.top = "";
    }
  });
}
function wgGripHTML(k, titulo){
  return '<div class="wg-grip" onpointerdown="App.wgDown(event, \''+k+'\')" title="Mantén clic y arrastra para ubicarlo donde quieras">'
    + '<span class="wg-grip-ic">☰</span><span>Mover '+titulo+'</span>'
    + (wgFloat(k) ? '<button class="wg-reset" onclick="App.wgReset(\''+k+'\')" title="Volver al panel lateral del programa">✕ Devolver</button>' : '')
    + '</div>';
}
App.wgDown = function(ev, k){
  if(ev.button !== undefined && ev.button !== 0) return;
  if(ev.target && ev.target.closest && ev.target.closest(".wg-reset")) return;
  var el = byId(wgWrapId(k));
  if(!el) return;
  var r = el.getBoundingClientRect();
  WG_DRAG = { k: k, dx: ev.clientX - r.left, dy: ev.clientY - r.top, ox: ev.clientX, oy: ev.clientY, moved: false };
  document.body.classList.add("wg-dragging");
  try{ ev.preventDefault(); }catch(e){}
};
document.addEventListener("pointermove", function(ev){
  if(!WG_DRAG) return;
  var d = WG_DRAG;
  if(!d.moved){
    if(Math.abs(ev.clientX - d.ox) < 5 && Math.abs(ev.clientY - d.oy) < 5) return;
    d.moved = true;
    /* Desacoplar: fija el widget en su posicion actual y re-renderiza flotante */
    var el = byId(wgWrapId(d.k));
    if(!el){ WG_DRAG = null; return; }
    var r = el.getBoundingClientRect();
    wgPos()[d.k] = { float: true, x: Math.round(r.left), y: Math.round(r.top) };
    saveWidgetPos();
    render();
  }
  var p = wgPos()[d.k];
  if(!p){ WG_DRAG = null; return; }
  p.x = Math.round(ev.clientX - d.dx);
  p.y = Math.round(ev.clientY - d.dy);
  wgClamp(d.k, p);
  var el2 = byId(wgWrapId(d.k));
  if(el2){ el2.style.left = p.x + "px"; el2.style.top = p.y + "px"; }
});
function wgDragEnd(){
  if(!WG_DRAG) return;
  var d = WG_DRAG;
  WG_DRAG = null;
  document.body.classList.remove("wg-dragging");
  if(d.moved){
    saveWidgetPos();
    if(!wgTipShown){
      wgTipShown = true;
      toast("🧲 " + (d.k === "reloj" ? "Reloj" : "Calendario") + " movido","Quedo guardado en esta posicion. Usa el boton ✕ Devolver para regresarlo al panel.","success");
    }
  }
}
document.addEventListener("pointerup", wgDragEnd);
document.addEventListener("pointercancel", wgDragEnd);
window.addEventListener("blur", wgDragEnd);
App.wgReset = function(k){
  wgPos()[k] = null;
  saveWidgetPos();
  render();
};
