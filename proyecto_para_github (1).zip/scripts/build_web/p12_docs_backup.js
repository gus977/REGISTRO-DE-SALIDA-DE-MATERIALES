/* ============================================================
   DOCUMENTOS HTML IMPRIMIBLES (OT / Provisional / Conteo Fisico)
   ============================================================ */
function docStyles(){
  return '<style>'
    + '*{box-sizing:border-box;margin:0;padding:0}'
    + 'body{font-family:-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#0f172a;padding:24px;background:#f1f5f9}'
    + '.doc{max-width:820px;margin:0 auto;background:#fff;border:1px solid #cbd5e1;border-radius:10px;overflow:hidden;box-shadow:0 10px 30px rgba(2,6,23,.15)}'
    + '.doc-head{padding:18px 24px;color:#fff;display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}'
    + '.doc-head h1{font-size:20px;font-weight:900;letter-spacing:-.02em}'
    + '.doc-head p{font-size:12px;opacity:.9}'
    + '.doc-body{padding:22px 24px}'
    + '.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:18px}'
    + '.cbox{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px}'
    + '.cbox .k{font-size:9.5px;font-weight:800;text-transform:uppercase;color:#64748b;letter-spacing:.04em}'
    + '.cbox .v{font-size:14px;font-weight:800;color:#0f172a;margin-top:2px;word-break:break-word}'
    + 'table{width:100%;border-collapse:collapse;font-size:12px}'
    + 'th{background:#1e3a8a;color:#fff;text-align:left;padding:7px 8px;font-size:10px;text-transform:uppercase;letter-spacing:.03em;border:1px solid #172554}'
    + 'td{padding:6px 8px;border:1px solid #e2e8f0;vertical-align:top}'
    + 'tr:nth-child(even) td{background:#f8fafc}'
    + '.tot{text-align:right;font-weight:900;background:#dbeafe!important}'
    + '.firmas{display:grid;grid-template-columns:repeat(3,1fr);gap:24px;margin-top:44px;text-align:center}'
    + '.firmas .firma{border-top:2px solid #0f172a;padding-top:6px;font-size:11.5px;font-weight:700}'
    + '.firmas .rol{font-size:10px;color:#64748b;text-transform:uppercase;margin-top:2px}'
    + '.doc-foot{padding:12px 24px;background:#f1f5f9;border-top:1px solid #e2e8f0;font-size:10.5px;color:#64748b;display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px}'
    + '.print-btn{position:fixed;top:14px;right:14px;background:#2563eb;color:#fff;border:none;border-radius:8px;padding:10px 18px;font-weight:800;font-size:13px;cursor:pointer;box-shadow:0 6px 20px rgba(37,99,235,.45)}'
    + '@media print{.print-btn{display:none}body{background:#fff;padding:0}.doc{border:none;box-shadow:none;max-width:none}}'
    + '</style>';
}
/* Nombre identificador del documento de una OT: "OT 60012 - CP1152"
   Se usa como <title> del documento (asi sugiere el navegador el nombre
   del PDF al imprimir/guardar) y como nombre del archivo HTML descargado. */
function nombreDocOT(ot, regs){
  var veh = "";
  for(var i=0;i<regs.length;i++){
    var v = String((regs[i]&&regs[i].vehiculo)||"").trim();
    if(v){ veh = v; break; }
  }
  var nombre = "OT " + String(ot==null?"":ot).trim();
  if(veh) nombre += " - " + veh;
  return nombre.replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim();
}
/* Limpia un texto para usarlo como nombre de archivo (mantiene espacios y guiones) */
function nombreArchivoDoc(s){
  return String(s==null?"":s).replace(/[\\/:*?"<>|]+/g, "-").replace(/\s+/g, " ").trim();
}
function abrirDocumento(html, titulo){
  var w = window.open("", "_blank");
  if(w){
    w.document.write('<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>'+titulo+'</title>'+docStyles()+'</head><body>'
      + '<button class="print-btn" onclick="window.print()">🖨 Imprimir / Guardar PDF</button>' + html + '</body></html>');
    w.document.close();
  } else {
    /* popup bloqueado: descargar archivo */
    var blob = new Blob(['<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>'+titulo+'</title>'+docStyles()+'</head><body>'+html+'</body></html>'], {type: "text/html"});
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = nombreArchivoDoc(titulo) + ".html";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast("Documento descargado", "El navegador bloqueo la ventana emergente. Se descargo el documento como archivo HTML.");
  }
}
/* ---- Documento de OT (contenido interno, compartido) ---- */
function docOrdenInner(ot, regs){
  regs.sort(function(a,b){ return String(a.fecha).localeCompare(String(b.fecha)); });
  var primero = regs[0], total = 0;
  var filas = "";
  regs.forEach(function(r, i){
    total += Number(r.cantidad)||0;
    filas += '<tr><td>'+(i+1)+'</td><td>'+fmtF(r.fecha)+'</td><td><b>'+esc(r.codigo)+'</b></td><td>'+esc(r.descripcion)+'</td>'
      + '<td style="text-align:right;font-weight:800">'+fmtC(r.cantidad)+'</td><td style="text-align:center">'+esc(r.unidad)+'</td>'
      + '<td style="text-align:center">'+(r.turno==="DIA"?"☀ DIA":"🌙 T/N")+'</td><td>'+esc(r.usuario)+'</td><td>'+esc(r.observacion||"-")+'</td></tr>';
  });
  var legal = S.legalizadas.has(String(ot));
  var eliminada = S.ocultas.has(String(ot));
  var estado = eliminada ? "🗑 ELIMINADA DE LA LISTA (historial permanente)" : legal ? "✅ LEGALIZADA" : "⏳ PENDIENTE POR LEGALIZAR";
  var html = '<div class="doc">'
    + '<div class="doc-head" style="background:linear-gradient(90deg,#1e293b,#0f172a)"><div><h1>📄 Reporte de Consumo por OT</h1><p>Sistema de Registro de Materiales - Consumo por vehiculo y OT</p></div>'
    + '<span style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);border-radius:999px;padding:6px 16px;font-weight:900;font-size:15px">OT: '+esc(ot)+'</span></div>'
    + '<div class="doc-body">'
    + '<div class="grid">'
    + cbox("Numero de OT", ot) + cbox("Vehiculo", primero.vehiculo)
    + cbox("Entrega (Usuario en sesion)", nombreUsuario()) + cbox("Recibe (Supervisor)", primero.supervisor)
    + cbox("Estado", estado)
    + cbox("Fecha inicial", fmtF(regs[0].fecha)) + cbox("Fecha ultimo registro", fmtF(regs[regs.length-1].fecha))
    + '</div>'
    + '<table><thead><tr><th>#</th><th>Fecha/Hora</th><th>Codigo</th><th>Descripcion</th><th style="text-align:right">Cant.</th><th style="text-align:center">Unidad</th><th style="text-align:center">Turno</th><th>Entrega</th><th>Observacion</th></tr></thead>'
    + '<tbody>'+filas+'</tbody>'
    + '<tfoot><tr><td colspan="4" class="tot">TOTAL: '+regs.length+' material(es)</td><td class="tot" style="text-align:right">'+fmtC(total)+'</td><td colspan="4" class="tot">unidades registradas</td></tr></tfoot>'
    + '</table>'
    + '<div class="firmas">'
    + '<div><div class="firma">'+esc(nombreUsuario())+'</div><div class="rol">Entrega (Usuario en sesion)</div></div>'
    + '<div><div class="firma">'+esc(primero.supervisor)+'</div><div class="rol">Recibe (Supervisor)</div></div>'
    + '<div><div class="firma">&nbsp;</div><div class="rol">Visto bueno</div></div>'
    + '</div>'
    + '</div>'
    + '<div class="doc-foot"><span>Generado por: <b>'+esc(nombreUsuario())+'</b> el '+fmtF(new Date().toISOString())+'</span><span>Sistema de Registro de Materiales</span></div>'
    + '</div>';
  return html;
}
function abrirDocOT(ot){
  var regs = S.registros.filter(function(r){ return String(r.ot) === String(ot); });
  if(!regs.length){ toast("OT sin registros","No hay materiales para la OT "+ot,"destructive"); return; }
  abrirDocumento(docOrdenInner(ot, regs.slice()), nombreDocOT(ot, regs));
}
/* ---- Archivo HTML de la orden: se genera solo con cada registro ---- */
function fechaHoraArchivo(){
  var d = new Date();
  function p2(n){ return (n < 10 ? "0" : "") + n; }
  return d.getFullYear()+"-"+p2(d.getMonth()+1)+"-"+p2(d.getDate())+"_"+p2(d.getHours())+p2(d.getMinutes())+p2(d.getSeconds());
}
function descargarHTMLFile(nombre, contenido){
  try{
    var blob = new Blob([contenido], {type:"text/html;charset=utf-8"});
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = nombre;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){ URL.revokeObjectURL(url); }, 4000);
    return true;
  }catch(e){ return false; }
}
App.descargarOrdenHTML = function(ot, silencioso){
  ot = String(ot == null ? "" : ot);
  var regs = S.registros.filter(function(r){ return String(r.ot) === ot; });
  if(!regs.length){
    if(!silencioso) toast("OT sin registros","No hay materiales para la OT "+ot,"destructive");
    return;
  }
  var inner = docOrdenInner(ot, regs.slice());
  var base = nombreDocOT(ot, regs);
  var nombre = base + ".html";
  var full = '<!DOCTYPE html><html lang="es"><head><meta charset="utf-8"><title>'+esc(base)+'</title>'+docStyles()+'</head><body>'
    + '<button class="print-btn" onclick="window.print()">🖨 Imprimir / Guardar PDF</button>' + inner + '</body></html>';
  descargarHTMLFile(nombre, full);
  /* Si la carpeta de respaldo de la PC esta conectada, el archivo tambien queda alli */
  if(typeof CarpetaLocal !== "undefined" && CarpetaLocal.dir && typeof CarpetaLocal.archivo === "function"){
    CarpetaLocal.archivo(nombre, full);
  }
  if(!silencioso) toast("✅ Archivo HTML de la orden generado", nombre + " — abrelo y pulsa el boton para imprimir", "success");
};
function cbox(k, v){ return '<div class="cbox"><div class="k">'+esc(k)+'</div><div class="v">'+esc(v==null?"-":v)+'</div></div>'; }

/* ---- Documento Provisional de Despacho ---- */
function abrirDocProvisional(p, nuevo){
  var filas = "";
  p.materiales.forEach(function(m, i){
    filas += '<tr><td>'+(i+1)+'</td><td><b>'+esc(m.codigo)+'</b></td><td>'+esc(m.descripcion)+'</td>'
      + '<td style="text-align:right;font-weight:800">'+fmtC(m.cantidad)+'</td><td style="text-align:center">'+esc(m.unidad)+'</td><td>'+esc(m.observacion||"-")+'</td></tr>';
  });
  var total = p.materiales.reduce(function(a,m){ return a + (Number(m.cantidad)||0); }, 0);
  var html = '<div class="doc">'
    + '<div class="doc-head" style="background:linear-gradient(90deg,#9333ea,#7e22ce)"><div><h1>📋 Provisional de Despacho</h1><p>Entrega y Recepcion de Materiales</p></div>'
    + '<div style="text-align:right"><div style="font-size:10px;text-transform:uppercase;letter-spacing:.05em;opacity:.85">Documento Nº</div><div style="font-size:17px;font-weight:900">'+esc(p.numeroDocumento)+'</div></div></div>'
    + '<div class="doc-body">'
    + '<div class="grid">'
    + cbox((p.tipoDestinatario||"contratista").charAt(0).toUpperCase()+(p.tipoDestinatario||"").slice(1)+" (Destinatario)", p.destinatario)
    + cbox("Fecha", fmtF(p.fecha))
    + cbox("Turno", p.turno === "DIA" ? "☀ DIA (05:00 - 14:00)" : "🌙 TARDE NOCHE (14:01 - 22:00)")
    + cbox("Supervisor Contratista", p.supervisorContratista)
    + '</div>'
    + '<table><thead><tr><th>#</th><th>Codigo</th><th>Descripcion del material</th><th style="text-align:right">Cantidad</th><th style="text-align:center">Unidad</th><th>Observacion</th></tr></thead>'
    + '<tbody>'+filas+'</tbody>'
    + '<tfoot><tr><td colspan="3" class="tot">TOTAL</td><td class="tot" style="text-align:right">'+fmtC(total)+'</td><td colspan="2" class="tot">'+p.materiales.length+' material(es)</td></tr></tfoot></table>'
    + (p.observacionesGenerales ? '<div style="margin-top:14px;background:#faf5ff;border:1px solid #e9d5ff;border-radius:8px;padding:10px 14px;font-size:12px"><b>Observaciones generales:</b> '+esc(p.observacionesGenerales)+'</div>' : '')
    + '<div class="firmas">'
    + '<div><div class="firma">'+esc(p.entregadoPor||"")+'</div><div class="rol">Entregado por</div></div>'
    + '<div><div class="firma">'+esc(p.quienRecibe||"")+'</div><div class="rol">Recibido por</div></div>'
    + '<div><div class="firma">'+esc(p.supervisorContratista||"")+'</div><div class="rol">Supervisor Contratista</div></div>'
    + '</div>'
    + '</div>'
    + '<div class="doc-foot"><span>Generado por: <b>'+esc(p.usuarioGenerador)+'</b> el '+fmtF(p.createdAt)+'</span><span>Documento provisional - sujeto a legalizacion en SAP</span></div>'
    + '</div>';
  abrirDocumento(html, "Provisional_"+p.numeroDocumento);
}
App.verProvHTML = function(id){
  var p = null;
  S.provisionales.forEach(function(x){ if(x.id === id) p = x; });
  if(p) abrirDocProvisional(p, false);
};

/* ---- Documento Conteo Fisico ---- */
App.conteoFisico = function(){
  if(!S.inventario.length){ toast("Inventario vacio","Carga tu base de materiales primero","destructive"); return; }
  var mats = S.inventario.slice().sort(function(a,b){ return String(a.codigo).localeCompare(String(b.codigo), undefined, {numeric:true}); });
  var filas = "";
  mats.forEach(function(m, i){
    filas += '<tr><td>'+(i+1)+'</td><td><b>'+esc(m.codigo)+'</b></td><td>'+esc(m.textoBreve)+'</td><td style="text-align:center">'+esc(m.ubicacion||"-")+'</td>'
      + '<td style="text-align:center">'+esc(m.unidadMedida)+'</td><td style="text-align:right;font-weight:800">'+fmtC(m.stock)+'</td>'
      + '<td style="height:26px"></td><td></td><td></td></tr>';
  });
  var html = '<div class="doc">'
    + '<div class="doc-head" style="background:linear-gradient(90deg,#059669,#047857)"><div><h1>📦 Conteo Fisico de Inventario</h1><p>Sistema de Registro de Materiales - hoja de conteo para bodega</p></div>'
    + '<span style="background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.3);border-radius:999px;padding:6px 16px;font-weight:800;font-size:13px">'+fmtN(mats.length)+' materiales</span></div>'
    + '<div class="doc-body">'
    + '<div class="grid">'+cbox("Fecha de conteo", new Date().toLocaleDateString("es-CO"))+cbox("Bodega / Almacen", "-")+cbox("Realizado por", nombreUsuario())+'</div>'
    + '<table><thead><tr><th>#</th><th>Codigo</th><th>Descripcion</th><th style="text-align:center">Ubicacion</th><th style="text-align:center">Unidad</th><th style="text-align:right">Stock sistema</th><th style="text-align:center">Conteo fisico</th><th style="text-align:center">Diferencia</th><th>Observaciones</th></tr></thead>'
    + '<tbody>'+filas+'</tbody></table>'
    + '</div>'
    + '<div class="doc-foot"><span>Generado por: <b>'+esc(nombreUsuario())+'</b> el '+fmtF(new Date().toISOString())+'</span><span>Completa las columnas de conteo manualmente</span></div>'
    + '</div>';
  abrirDocumento(html, "Conteo_Fisico_Inventario");
};

/* ============================================================
   RESPALDO: exportar / importar datos
   ============================================================ */
/* Resumen en vivo de TODAS las bases de datos guardadas en el servidor */
function resumenBDHTML(){
  var items = [
    {icono:"clipboard",  nombre:"Ordenes y registros de salida", desc:"Historial de movimientos por OT", n: S.registros.length},
    {icono:"clock",      nombre:"OTs pendientes por legalizar",  desc:"Pendientes", n: otsPendientes().length},
    {icono:"checkCircle",nombre:"OTs legalizadas",              desc:"Ya sincronizadas en SAP", n: S.legalizadas.size},
    {icono:"package",    nombre:"Inventario de materiales",      desc:"Base de materiales (Excel)", n: S.inventario.length},
    {icono:"layers",     nombre:"Observaciones de inventario",   desc:"NUEVO / REPARADO / RECUPERADO", n: obsHistAll().length},
    {icono:"fileText",   nombre:"Provisionales de despacho",     desc:"Documentos PD guardados", n: S.provisionales.length},
    {icono:"trendingUp", nombre:"Entradas por pedido",          desc:"Materiales ingresados a bodega", n: S.entradas.length},
    {icono:"userCheck",  nombre:"Supervisores",                 desc:"Lista para seleccion", n: S.supervisores.length},
    {icono:"users",      nombre:"Usuarios del sistema",          desc:"Accesos con nombre completo", n: DB.get("usuarios", []).length}
  ];
  var html = '<div style="border:1px solid var(--sl200);border-radius:.6rem;overflow:hidden">'
    + '<div style="background:var(--sl50);padding:.55rem .8rem;display:flex;justify-content:space-between;align-items:center;gap:.5rem;flex-wrap:wrap">'
    + '<span style="font-size:11px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;color:var(--sl700);display:flex;align-items:center;gap:.4rem">'+ic("database")+' Todo lo guardado en la base de datos</span>'
    + '<button class="btn-ghost btn-sm" onclick="App.abrirRespaldo()" style="font-weight:700">'+ic("refreshCw")+' Actualizar</button></div>'
    + '<div style="display:flex;flex-direction:column">';
  items.forEach(function(it, i){
    html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:.6rem;padding:.45rem .8rem;'+(i%2?'background:var(--sl50);':'')+'border-top:1px solid var(--sl100)">'
      + '<span style="font-size:12px;color:var(--sl700);display:flex;align-items:center;gap:.45rem;min-width:0">'+ic(it.icono)+' <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+esc(it.nombre)+'</span></span>'
      + '<span class="badge '+(it.n>0?'emerald':'slate')+'" style="flex-shrink:0;min-width:54px;text-align:center">'+fmtN(it.n)+'</span></div>';
  });
  html += '</div></div>';
  return html;
}
App.abrirRespaldo = function(){
  openModal('md-resp','grad-blue', ic("save")+' Respaldo de datos', 'Protege la informacion: base de datos del servidor + carpeta de tu PC','',
    '<div class="modal-body" style="display:flex;flex-direction:column;gap:.8rem">'
    + resumenBDHTML()
    + '<div class="bk-item"><div class="ic" style="background:linear-gradient(135deg,var(--blue600),var(--blue900))">'+ic("save","ic-20")+'</div>'
    + '<div style="flex:1"><h5>Guardado en el servidor (base de datos)</h5>'
    + '<p>Cada cambio que hagas se guarda <b>automaticamente</b> en la base de datos del servidor. La informacion queda protegida aunque se limpie el navegador, se apague el PC o cambies de equipo: al abrir el sistema en cualquier navegador encontrarás siempre tus datos.</p>'
    + '<div id="resp-disk-box"></div>'
    + '</div></div>'
    + '<div class="bk-item"><div class="ic" style="background:linear-gradient(135deg,var(--em500),var(--blue700))">'+ic("folder","ic-20")+'</div>'
    + '<div style="flex:1"><h5>Carpeta de respaldo en tu PC</h5>'
    + '<p>Conecta UNA sola vez la carpeta de tu PC donde quieres el respaldo automatico (por ejemplo <b>D:\\SERVIDOR DEL PROGRMA</b>). Desde ese momento <b>cada registro</b> se guarda solo alli, en el archivo respaldo_registro_materiales.json (mas una copia por dia). Si el servidor llegara a estar vacio, el sistema JALA los datos de esa carpeta automaticamente.</p>'
    + '<div id="resp-folder-box"></div>'
    + '</div></div>'
    + '<div class="bk-item"><div class="ic" style="background:linear-gradient(135deg,var(--em500),var(--em700))">'+ic("download","ic-20")+'</div>'
    + '<div style="flex:1"><h5>Exportar respaldo</h5><p>Descarga un archivo .json con TODO: ordenes/registros, OTs pendientes y legalizadas, inventario, observaciones, provisionales, entradas, supervisores y usuarios. Guardalo en una carpeta segura como copia adicional.</p>'
    + '<button class="btn btn-emerald btn-sm" onclick="App.exportarDatos()">'+ic("download")+' Exportar datos (.json)</button></div></div>'
    + '<div class="bk-item"><div class="ic" style="background:linear-gradient(135deg,var(--blue500),var(--blue700))">'+ic("upload","ic-20")+'</div>'
    + '<div style="flex:1"><h5>Importar respaldo</h5><p>Restaura los datos desde un archivo .json previamente exportado (por ejemplo, desde la versión local de PC). <b>Reemplaza</b> los datos actuales del servidor.</p>'
    + '<input type="file" id="bk-file" accept=".json" style="display:none" onchange="App.importarDatos(this)">'
    + '<button class="btn btn-primary btn-sm" onclick="byId(\'bk-file\').click()">'+ic("upload")+' Importar respaldo</button></div></div>'
    + '<div class="info-amber">'+ic("info")+' <b>Tus datos nunca se borran solos:</b> se guardan automaticamente en la base de datos del servidor y, si conectas tu carpeta (ej. D:\\SERVIDOR DEL PROGRMA), tambien en la PC. Ademas puedes exportar respaldos .json cuando quieras.</div>'
    + '</div>'
    + '<div class="modal-foot"><button class="btn btn-outline" onclick="App.cerrarModal()">Cerrar</button></div>');
  renderSaveBar();
  if(typeof CarpetaLocal !== "undefined") CarpetaLocal.pintar();
};
App.exportarDatos = function(){
  var data = DB.exportAll();
  var fecha = new Date().toISOString().split("T")[0];
  descargarArchivo("respaldo_registro_materiales_" + fecha + ".json", JSON.stringify(data, null, 2), "application/json");
  toast("✅ Respaldo exportado","Guarda el archivo .json en un lugar seguro");
};
App.importarDatos = function(input){
  var f = input.files && input.files[0];
  if(!f) return;
  var reader = new FileReader();
  reader.onload = function(e){
    try{
      var data = JSON.parse(new TextDecoder().decode(new Uint8Array(e.target.result)));
      if(!data || !("_sistema" in data) && !("registros" in data) && !("inventario" in data)){
        throw new Error("El archivo no parece un respaldo de este sistema");
      }
      if(!confirm("¿Restaurar el respaldo del "+(data._fecha ? fmtF(data._fecha) : "archivo seleccionado")+"?\n\nSe REEMPLAZARAN todos los datos actuales de esta PC.")) return;
      DB.importAll(data);
      toast("✅ Respaldo restaurado","Los datos fueron importados correctamente","success");
      closeModal();
      var ses = DB.get("session", null);
      if(ses && ses.username){ S.usuario = ses; entrarPrincipal(false); }
      else { S.view = "login"; render(); }
    }catch(err){
      toast("Error al importar", err.message, "destructive");
    }
  };
  reader.readAsArrayBuffer(f);
};

/* ============================================================
   MODALES genericos + INIT
   ============================================================ */
function openModal(size, grad, titulo, sub, contentHTML, fullHTML){
  var root = $("#modal-root");
  S.modalSize = size; 
  root.innerHTML = '<div class="overlay" onclick="if(event.target===this)closeModal()"><div class="modal '+(size||"")+'" onclick="event.stopPropagation()">'
    + '<div class="modal-head '+grad+'"><div style="display:flex;align-items:center;gap:.7rem;min-width:0"><div style="flex-shrink:0">'+ic(titulo.indexOf("Provisional")===0?"layers":"info","ic-26").replace('style="width:1em;height:1em','style="width:26px;height:26px')+'</div><div style="min-width:0"><h3>'+titulo+'</h3>'+(sub?'<p>'+sub+'</p>':'')+'</div></div>'
    + '<button class="modal-x" onclick="closeModal()">'+ic("x","ic-22").replace('style="width:1em;height:1em','style="width:22px;height:22px')+'</button></div>'
    + (fullHTML ? fullHTML : '<div class="modal-body" id="modal-content">'+(contentHTML||"")+'</div>')
    + '</div></div>';
  S.modalGrad = grad; S.modalTitulo = titulo; S.modalSub = sub; S.modalFull = fullHTML || null;
}
function renderModalContent(){
  var body = $("#modal-content");
  if(!body) return;
  if(S.invDetail) { body.innerHTML = invDetalleHTML(); return; }
  if(S.otModal) { body.innerHTML = otModalHTML(); return; }
  if(S.provOpen) { body.innerHTML = provModalHTML(); return; }
  if(S.provGuardOpen) { body.innerHTML = provGuardadasHTML(); return; }
  if(S.invUpOpen) { body.innerHTML = invUploadHTML(); return; }
  if(S.pSyncOpen) { body.innerHTML = syncHTML(); return; }
}
function closeModal(){
  var root = $("#modal-root");
  if(root) root.innerHTML = "";
  S.invDetail = null; S.otModal = null; S.provOpen = false; S.provGuardOpen = false; S.invUpOpen = false; S.pSyncOpen = false; S.cargarOTOpen = false; S.pSacar = null;
}
App.cerrarModal = function(){ closeModal(); renderMain(); };

/* cerrar dropdowns al hacer clic fuera */
document.addEventListener("click", function(e){
  if(S.matOpen && !e.target.closest("#ddlist-reg") && !e.target.closest(".mat-btn") && S.view==="main" && S.tab==="registro"){
    var hayDD = false;
    if(S.modoMulti && S.multi.some(function(r){return r._open;})) hayDD = true;
    if(!e.target.closest(".dd") && !hayDD && S.matOpen){ S.matOpen = false; renderMain(); }
  }
});

/* ============ INICIALIZACION ============ */
window.addEventListener("resize", function(){ S.isMobile = isMobile(); });
window.addEventListener("DOMContentLoaded", function(){
  /* Carga primero TODOS los datos desde la base de datos del servidor */
  var boot = function(){
    S.isMobile = isMobile();
    S.turno = turnoNow();
    setInterval(function(){ S.turno = turnoNow(); }, 60000);
    /* Garantiza los usuarios base del sistema (GAGUAS/8206, OCASTILLO/3690) */
    if(typeof asegurarUsuariosBase === "function") asegurarUsuariosBase();
    var ses = DB.get("session", null);
    if(ses && ses.username){
      var usuarios = DB.get("usuarios", []);
      var found = null;
      for(var i=0;i<usuarios.length;i++){ if(String(usuarios[i].username||"").toLowerCase() === String(ses.username||"").toLowerCase()){ found = usuarios[i]; break; } }
      if(found){ S.usuario = {username: found.username, nombre: found.nombre, nombreCompleto: found.nombreCompleto}; }
    }
    if(S.usuario){ entrarPrincipal(false); }
    else { S.view = "login"; render(); }
    /* Reconectar la carpeta de respaldo de la PC y auto-recuperar si el servidor esta vacio */
    if(typeof CarpetaLocal !== "undefined") CarpetaLocal.init();
  };
  if(typeof WebStore !== "undefined" && WebStore.loadAll){
    WebStore.loadAll().then(boot);
  } else { boot(); }
});
