/* ============================================================
   TAB: REGISTRAR
   ============================================================ */
function buscarMaterialesLocal(q, limit){
  q = String(q||"").toLowerCase().trim();
  var res = [];
  var n = limit || 50;
  if(!q){
    return S.inventario.slice().sort(function(a,b){ return String(a.codigo).localeCompare(String(b.codigo), undefined, {numeric:true}); }).slice(0,n);
  }
  for(var i=0;i<S.inventario.length;i++){
    var m = S.inventario[i];
    if(String(m.codigo).toLowerCase().indexOf(q) >= 0 ||
       String(m.textoBreve).toLowerCase().indexOf(q) >= 0 ||
       String(m.ubicacion).toLowerCase().indexOf(q) >= 0){
      res.push(m);
      if(res.length >= n) break;
    }
  }
  return res;
}
function matById(id){ for(var i=0;i<S.inventario.length;i++){ if(S.inventario[i].id === id) return S.inventario[i]; } return null; }
function matByCodigo(codigo){ var c = String(codigo).trim(); for(var i=0;i<S.inventario.length;i++){ if(String(S.inventario[i].codigo).trim() === c) return S.inventario[i]; } return null; }

function obsTagBadges(m){
  var parts = String(m.observacion||"").split(/[;,]/), out = "";
  for(var i=0;i<parts.length;i++){
    var p = parts[i].trim().toUpperCase();
    if(!p) continue;
    var cls = p === "NUEVO" ? "emerald" : p === "REPARADO" ? "amber" : p === "RECUPERADO" ? "blue" : "slate";
    out += '<span class="badge '+cls+'" style="font-size:9px">'+esc(p)+'</span>';
  }
  return out;
}
function ddItemHTML(m, selectedId, ctx, rowIdx){
  var stockCls = m.stock > 0 ? "emerald" : "red";
  return '<div class="dd-item" onmousedown="App.selMaterial(\''+ctx+'\','+(rowIdx>=0?rowIdx:"null")+',\''+m.id+'\')">'
    + '<div class="info"><div class="top">'
    + '<span class="badge blue">'+esc(m.codigo)+'</span>'
    + '<span class="badge outline">'+esc(m.unidadMedida)+'</span>'
    + '<span class="badge '+stockCls+'">Stock: '+fmtC(m.stock)+'</span>'
    + obsTagBadges(m)
    + (tamborTxt(m.stock, m.codigo) ? '<span class="badge indigo">'+tamborTxt(m.stock, m.codigo)+'</span>' : '')
    + '</div><div class="desc">'+esc(m.textoBreve)+'</div>'
    + (m.ubicacion ? '<div class="ub">Ubicacion: '+esc(m.ubicacion)+'</div>' : '')
    + '</div></div>';
}
function matButtonHTML(sel, ph, ctx, rowIdx){
  var inner;
  if(sel){
    inner = '<span class="sel"><span class="badge blue">'+esc(sel.codigo)+'</span><span class="desc">'+esc(sel.textoBreve)+'</span></span>'
      + '<span style="display:flex;gap:.3rem;align-items:center" onmousedown="event.stopPropagation()"><span role="button" class="btn-ghost btn-sm" title="Quitar" onclick="App.limpiarMaterial(\''+ctx+'\','+(rowIdx>=0?rowIdx:"null")+')">'+ic("x")+'</span></span>';
  } else {
    inner = '<span class="ph">'+ic("search")+' '+ph+'</span><span></span>';
  }
  return '<div class="dd" id="dd-'+ctx+(rowIdx>=0?"-"+rowIdx:"")+'"><button type="button" class="mat-btn" onclick="App.openMatDD(\''+ctx+'\','+(rowIdx>=0?rowIdx:"null")+')">'+inner+'</button></div>';
}
App.openMatDD = function(ctx, rowIdx){
  S.provRowIdx = (ctx === "reg") ? null : rowIdx;
  if(ctx === "reg"){ S.matOpen = true; S.matSearch = ""; S.matResults = buscarMaterialesLocal("", 50); }
  else if(ctx === "fila"){ S.multi[rowIdx]._open = true; S.multi[rowIdx]._search = ""; S.multi[rowIdx]._results = buscarMaterialesLocal("", 50); }
  else if(ctx === "otadd"){ S.otAddRows[rowIdx]._open = true; S.otAddRows[rowIdx]._search = ""; S.otAddRows[rowIdx]._results = buscarMaterialesLocal("", 50); }
  else if(ctx === "prov"){ S.provRows[rowIdx]._open = true; S.provRows[rowIdx]._search = ""; S.provRows[rowIdx]._results = buscarMaterialesLocal("", 50); }
  renderRegistroTab(); renderModalContent();
};
App.matDDSearch = function(ctx, rowIdx, val){
  val = String(val||"");
  if(ctx === "reg"){ S.matSearch = val; S.matResults = buscarMaterialesLocal(val, 50); }
  else if(ctx === "fila"){ S.multi[rowIdx]._search = val; S.multi[rowIdx]._results = buscarMaterialesLocal(val, 50); }
  else if(ctx === "otadd"){ S.otAddRows[rowIdx]._search = val; S.otAddRows[rowIdx]._results = buscarMaterialesLocal(val, 50); }
  else if(ctx === "prov"){ S.provRows[rowIdx]._search = val; S.provRows[rowIdx]._results = buscarMaterialesLocal(val, 50); }
  /* Codigo EXACTO digitado en el buscador: lo selecciona solo (sirve con lector de barras) */
  var vq = val.trim().toLowerCase();
  if(vq){
    var res = (ctx === "reg") ? S.matResults : (ctx === "fila") ? S.multi[rowIdx]._results : (ctx === "otadd") ? S.otAddRows[rowIdx]._results : S.provRows[rowIdx]._results;
    for(var i=0;i<res.length;i++){
      if(String(res[i].codigo).trim().toLowerCase() === vq){ App.selMaterial(ctx, rowIdx, res[i].id); return; }
    }
  }
  var cont = byId("ddlist-"+ctx+(rowIdx>=0?"-"+rowIdx:""));
  if(cont) cont.innerHTML = ddListHTML(ctx, rowIdx);
  var inp = byId("ddsearch-"+ctx+(rowIdx>=0?"-"+rowIdx:""));
  if(inp){ inp.focus(); inp.value = val; }
};
function ddListHTML(ctx, rowIdx){
  var results;
  if(ctx === "reg") results = S.matResults;
  else if(ctx === "fila") results = S.multi[rowIdx]._results;
  else if(ctx === "otadd") results = S.otAddRows[rowIdx]._results;
  else if(ctx === "prov") results = S.provRows[rowIdx]._results;
  if(!results || !results.length){
    /* En el PROVISIONAL un codigo sin coincidencias se puede usar igual (codigo libre) */
    if(ctx === "prov"){
      var q = String((S.provRows[rowIdx]||{})._search||"").trim();
      if(q) return '<div class="dd-empty">No hay material con "'+esc(q)+'" en el inventario.</div>'
        + '<div class="dd-item" onmousedown="App.selProvLibre('+rowIdx+')">'
        + '<div class="info"><div class="top"><span class="badge amber">'+ic("info")+' Codigo libre</span></div>'
        + '<div class="desc">Usar "'+esc(q)+'" como codigo del material en el documento</div></div></div>';
    }
    return '<div class="dd-empty">No se encontro ningun material.</div>';
  }
  var out = "";
  for(var i=0;i<results.length;i++){
    var selId = null;
    if(ctx === "reg" && S.matSel) selId = S.matSel.id;
    if(ctx === "fila" && S.multi[rowIdx].material) selId = S.multi[rowIdx].material.id;
    if(ctx === "otadd" && S.otAddRows[rowIdx].material) selId = S.otAddRows[rowIdx].material.id;
    out += ddItemHTML(results[i], selId, ctx, rowIdx);
  }
  return out;
}
App.selMaterial = function(ctx, rowIdx, id){
  var m = matById(id); if(!m) return;
  if(ctx === "reg"){
    S.matSel = m; S.matOpen = false; S.obsSel = "";
    S.matObs = obsDeMaterial(m.codigo);
    S.rgCodigo = String(m.codigo); S.rgCodigoMsg = "";
    renderRegistroTab();
  } else if(ctx === "fila"){
    S.multi[rowIdx].material = m; S.multi[rowIdx]._open = false; S.multi[rowIdx].observacion = "";
    S.multi[rowIdx]._obs = obsDeMaterial(m.codigo);
    renderRegistroTab();
  } else if(ctx === "otadd"){
    S.otAddRows[rowIdx].material = m; S.otAddRows[rowIdx]._open = false; S.otAddRows[rowIdx].observacion = "";
    S.otAddRows[rowIdx]._obs = obsDeMaterial(m.codigo);
    renderModalContent();
  } else if(ctx === "prov"){
    S.provRows[rowIdx].codigo = m.codigo; S.provRows[rowIdx].descripcion = m.textoBreve;
    S.provRows[rowIdx].unidad = m.unidadMedida; S.provRows[rowIdx]._open = false;
    S.provRows[rowIdx]._obs = obsDeMaterial(m.codigo); S.provRows[rowIdx].observacion = "";
    renderModalContent();
  }
};
App.limpiarMaterial = function(ctx, rowIdx){
  if(ctx === "reg"){ S.matSel = null; S.matObs = []; S.obsSel = ""; S.rgCodigo = ""; S.rgCodigoMsg = ""; renderRegistroTab(); }
  else if(ctx === "fila"){ S.multi[rowIdx].material = null; S.multi[rowIdx]._obs = []; S.multi[rowIdx]._codigo = ""; S.multi[rowIdx]._codMsg = ""; renderRegistroTab(); }
  else if(ctx === "otadd"){ S.otAddRows[rowIdx].material = null; S.otAddRows[rowIdx]._obs = []; S.otAddRows[rowIdx]._codigo = ""; S.otAddRows[rowIdx]._codMsg = ""; renderModalContent(); }
  else if(ctx === "prov"){ S.provRows[rowIdx].codigo = ""; S.provRows[rowIdx].descripcion = ""; S.provRows[rowIdx].unidad = "UN"; S.provRows[rowIdx]._obs = []; S.provRows[rowIdx]._codigo = ""; S.provRows[rowIdx]._codMsg = ""; renderModalContent(); }
};
function stockPillInner(m, extra){
  var after = null;
  if(extra != null && String(extra).trim() !== "" && !isNaN(Number(extra))) after = m.stock - Number(extra);
  return '<span>'+(m.stock<=0?ic("alertTriangle"):ic("package"))+' Stock actual: <strong>'+fmtC(m.stock)+' '+esc(m.unidadMedida)+'</strong>'
    + (tamborTxt(m.stock, m.codigo) ? ' <span class="badge indigo">'+tamborTxt(m.stock, m.codigo)+'</span>' : '')
    + '</span>'
    + (after !== null && Number(extra) > 0 ? '<span style="font-size:11.5px">Queda despues de esta salida: <strong>'+fmtC(after)+' '+esc(m.unidadMedida)+'</strong>'
        + (tamborTxt(after, m.codigo) ? ' <span class="badge indigo" style="font-size:9px">'+tamborTxt(after, m.codigo)+'</span>' : '')
        + (after < 0 ? ' <span style="color:var(--red600);font-weight:800">⚠ INSUFICIENTE</span>' : (after === 0 ? ' <span style="color:var(--am700);font-weight:800">AGOTADO</span>' : '')) + '</span>' : '');
}
function stockPillHTML(m, extra, id){
  var cls = m.stock <= 0 ? "out" : (m.stock <= 5 ? "low" : "ok");
  return '<div class="stock-pill '+cls+'"'+(id?' id="'+id+'"':'')+'>'+stockPillInner(m, extra)+'</div>';
}
/* Preview en vivo MIENTRAS se digita la cantidad (sin re-renderizar: no molesta al cursor) */
App.previewStock = function(){
  if(S.matSel){ var el = byId("rg-stock-pill"); if(el) el.innerHTML = stockPillInner(S.matSel, S.rgCant); }
  var multi = S.multi || [];
  for(var i=0;i<multi.length;i++){
    var r = multi[i];
    if(!r || !r.material) continue;
    var el2 = byId("mp-stock-"+i);
    if(el2) el2.innerHTML = stockPillInner(r.material, r.cantidad);
  }
};
function obsGridHTML(obs, selValor, ctx, rowIdx){
  if(!obs || !obs.length) return "";
  var cells = "";
  for(var i=0;i<obs.length;i++){
    var o = obs[i], q = Number(o.cantidad)||0, has = q > 0;
    var selCls = selValor === o.valor ? " sel" : has ? " has" : " no";
    cells += '<button type="button" class="obs-cell'+selCls+'" '+(has?'onclick="App.selObs(\''+ctx+'\','+(rowIdx>=0?rowIdx:"null")+',\''+esc(o.valor)+'\')"':'disabled')+'>'
      + '<b>'+esc(o.valor)+'</b><span class="qty">'+fmtC(q)+'</span><span class="u">'+(Math.round(q)===1?"unidad":"unidades")+'</span></button>';
  }
  return '<div class="info-amber"><p style="font-weight:800;font-size:10.5px;text-transform:uppercase;letter-spacing:.03em;display:flex;align-items:center;gap:.3rem;margin-bottom:.3rem">'+ic("layers")+' Stock por observacion</p>'
    + '<div class="obs-grid">'+cells+'</div>'
    + '<p style="font-style:italic;font-size:10px;margin-top:.35rem">Cantidad real en inventario de cada observacion. Haz clic en una con stock para usarla.</p></div>';
}
App.selObs = function(ctx, rowIdx, valor){
  if(ctx === "reg"){ S.obsSel = S.obsSel === valor ? "" : valor; renderRegistroTab(); }
  else if(ctx === "fila"){ S.multi[rowIdx].observacion = S.multi[rowIdx].observacion === valor ? "" : valor; renderRegistroTab(); }
  else if(ctx === "otadd"){ S.otAddRows[rowIdx].observacion = S.otAddRows[rowIdx].observacion === valor ? "" : valor; renderModalContent(); }
  else if(ctx === "prov"){ S.provRows[rowIdx].observacion = S.provRows[rowIdx].observacion === valor ? "" : valor; renderModalContent(); }
};

/* ---- Codigo manual: digita el codigo -> descripcion automatica + observaciones para escoger ----
   Tambien sirve con lector de barras: al terminar de digitar (o Enter) busca el codigo exacto.
   IMPORTANTE: mientras se digita NO se re-renderiza el formulario si no hay coincidencia exacta,
   y al re-renderizar se RESTAURA el cursor exactamente donde estaba (no vuelve al inicio). */
App.codigoInput = function(val){
  S.rgCodigo = String(val||"").trim();
  S.rgCodigoMsg = "";
  if(!S.rgCodigo) return;
  if(S.matSel && String(S.matSel.codigo) === S.rgCodigo) return;   /* ya seleccionado */
  if(S._codTimer) clearTimeout(S._codTimer);
  S._codTimer = setTimeout(function(){ S._codTimer = null; App.codigoBuscar(false); }, 300);
};
App.codigoEnter = function(){
  if(S._codTimer){ clearTimeout(S._codTimer); S._codTimer = null; }
  App.codigoBuscar(true);
};
App.codigoBuscar = function(desdeEnter){
  var val = String(S.rgCodigo||"").trim().toLowerCase();
  if(!val) return;
  /* Guarda la posicion del cursor ANTES de cualquier re-render */
  var ci = byId("rg-codigo");
  var teniaFoco = !!(ci && document.activeElement === ci);
  var caret = teniaFoco ? ci.selectionStart : null;
  var m = null;
  for(var i=0;i<S.inventario.length;i++){
    if(String(S.inventario[i].codigo).trim().toLowerCase() === val){ m = S.inventario[i]; break; }
  }
  if(m){
    if(!S.matSel || S.matSel.id !== m.id){ S.matSel = m; S.obsSel = ""; S.matObs = obsDeMaterial(m.codigo); }
    S.matOpen = false; S.rgCodigoMsg = ""; S.rgCodigo = String(m.codigo);
    renderRegistroTab();
    /* Con Enter el foco pasa a la cantidad; al digitar vuelve al codigo EXACTAMENTE donde estaba */
    if(desdeEnter){
      var d1 = byId("rg-cant");
      if(d1){ try{ d1.focus(); }catch(e){} }
    } else {
      var d2 = byId("rg-codigo");
      if(d2){ try{ d2.focus(); if(caret != null) d2.setSelectionRange(caret, caret); }catch(e){} }
    }
  } else if(desdeEnter){
    if(S.matSel){
      /* Con material ya seleccionado: NO se cambia en silencio; se mantiene el activo */
      S.rgCodigoMsg = 'No existe un material con el codigo "' + S.rgCodigo + '". Se mantiene el material seleccionado ' + S.matSel.codigo + ' — ' + S.matSel.textoBreve + '. Corrige el codigo o quita el material con la X.';
      S.rgCodigo = String(S.matSel.codigo);   /* revierte el campo al codigo del material activo */
    } else {
      S.rgCodigoMsg = 'No existe un material con el codigo "' + S.rgCodigo + '". Verifica el numero o usa el buscador por descripcion.';
      S.matOpen = true; S.matSearch = String(S.rgCodigo); S.matResults = buscarMaterialesLocal(S.rgCodigo, 50);
    }
    renderRegistroTab();
    var ci2 = byId("rg-codigo");
    if(ci2){ try{ ci2.focus(); }catch(e){} }
  }
  /* Sin Enter y sin coincidencia exacta (aun esta escribiendo): NO se re-renderiza y NO
     se muestra error, asi el cursor y lo escrito quedan intactos hasta que el codigo complete */
};

/* ---- Codigo con descripcion automatica REUTILIZABLE (carga multiple, agregar materiales a OT,
   provisional de despacho). Misma mecanica del formulario principal: digitas el codigo y la
   descripcion, la unidad y el stock aparecen solos. Actualiza la fila EN SITIO (sin re-render
   completo) para no perder el cursor, el foco ni la posicion de la pantalla. ---- */
function codRowOf(ctx, i){
  if(ctx === "fila") return S.multi[i];
  if(ctx === "otadd") return S.otAddRows[i];
  if(ctx === "prov") return S.provRows[i];
  return null;
}
function codInputHTML(ctx, i, ph){
  var row = codRowOf(ctx, i);
  return '<div class="row" style="margin-bottom:.35rem;align-items:center">'
    + '<input id="cod-'+ctx+'-'+i+'" class="input dark grow" autocomplete="off" placeholder="'+esc(ph||"Digite el codigo del material y presione Enter")+'" value="'+esc((row && row._codigo)||"")+'"'
    + ' oninput="App.codRowInput(\''+ctx+'\','+i+',this.value)"'
    + ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();App.codRowEnter(\''+ctx+'\','+i+')}"'
    + '>'
    + '<button type="button" class="btn btn-outline" onclick="App.codRowEnter(\''+ctx+'\','+i+')" title="Busca el codigo digitado">'+ic("search")+' Buscar</button></div>';
}
App.codRowInput = function(ctx, i, val){
  var row = codRowOf(ctx, i); if(!row) return;
  row._codigo = String(val||"");
  var msg = byId("codmsg-"+ctx+"-"+i); if(msg) msg.innerHTML = "";
  if(ctx === "prov"){
    row.codigo = row._codigo.trim();   /* codigo libre (no inventario) tambien se respeta */
    if(!row._codigo.trim()){
      /* Campo vacio: la casilla Material vuelve a su estado inicial */
      var mc0 = byId("prov-matcell-"+i);
      if(mc0) mc0.innerHTML = provBtnInicialHTML(i);
      var sb0 = byId("prov-stock-"+i);
      if(sb0) sb0.innerHTML = '<span class="badge slate">Libre</span>';
    }
  }
  if(!row._codigo.trim()) return;
  if(row._codTimer) clearTimeout(row._codTimer);
  row._codTimer = setTimeout(function(){ row._codTimer = null; App.codRowBuscar(ctx, i, false); }, 300);
};
App.codRowEnter = function(ctx, i){
  var row = codRowOf(ctx, i); if(!row) return;
  if(row._codTimer){ clearTimeout(row._codTimer); row._codTimer = null; }
  App.codRowBuscar(ctx, i, true);
};
App.codRowBuscar = function(ctx, i, desdeEnter){
  var row = codRowOf(ctx, i); if(!row) return;
  var val = String(row._codigo||"").trim().toLowerCase();
  if(!val) return;
  var m = null;
  for(var j=0;j<S.inventario.length;j++){
    if(String(S.inventario[j].codigo).trim().toLowerCase() === val){ m = S.inventario[j]; break; }
  }
  var msg = byId("codmsg-"+ctx+"-"+i);
  if(!m){
    if(ctx === "prov"){
      /* PROVISIONAL acepta codigos libres: feedback inmediato + casilla Material en modo libre */
      var libre = String(row._codigo||"").trim();
      if(msg) msg.innerHTML = desdeEnter
        ? '<div class="rg-code-msg">'+ic("alertTriangle")+' No hay material con el codigo "'+esc(libre)+'" en el inventario. Se usara como codigo libre.</div>'
        : (libre.length >= 4 ? '<div class="rg-code-msg">'+ic("info")+' Codigo libre: se usara "'+esc(libre)+'" en el documento (no esta en el inventario)</div>' : "");
      if(row._lastMatched){
        /* Venia de un material del inventario: limpia datos heredados */
        row.unidad = "UN"; row.descripcion = ""; row.observacion = ""; row._obs = [];
        row._lastMatched = null;
        var uiX = byId("prov-uni-"+i); if(uiX) uiX.value = "UN";
        var pzX = byId("prov-obszone-"+i); if(pzX) pzX.innerHTML = obsGridHTML(row._obs, row.observacion, "prov", i);
        var piX = byId("prov-obs-inp-"+i); if(piX) piX.value = "";
      }
      var mcL = byId("prov-matcell-"+i);
      if(mcL && libre) mcL.innerHTML = provLibreHTML(i);
      var sbL = byId("prov-stock-"+i);
      if(sbL) sbL.innerHTML = '<span class="badge slate">Libre</span>';
    } else if(desdeEnter){
      var txt = 'No existe un material con el codigo "'+String(row._codigo).trim()+'". Verifica el numero o usa el buscador por descripcion.';
      if(msg) msg.innerHTML = '<div class="rg-code-msg">'+ic("alertTriangle")+' '+esc(txt)+'</div>';
    }
    return;
  }
  if(ctx === "prov"){
    var cambioP = String(row.codigo||"").trim() !== String(m.codigo);
    row.codigo = String(m.codigo); row.descripcion = m.textoBreve; row.unidad = m.unidadMedida;
    row._codigo = String(m.codigo); row._lastMatched = String(m.codigo);
    if(cambioP){ row.observacion = ""; row._obs = obsDeMaterial(m.codigo); }
    else if(!row._obs || !row._obs.length){ row._obs = obsDeMaterial(m.codigo); }
    var mi = byId("cod-prov-"+i); if(mi && mi.value !== row._codigo){ mi.value = row._codigo; }
    var mc = byId("prov-matcell-"+i); if(mc) mc.innerHTML = provSelHTML(i);
    var ui = byId("prov-uni-"+i); if(ui) ui.value = m.unidadMedida;
    var sb = byId("prov-stock-"+i); if(sb) sb.innerHTML = '<span class="badge '+(m.stock>0?"emerald":"red")+'" title="Stock actual">Stock: '+fmtC(m.stock)+'</span>';
    var pz = byId("prov-obszone-"+i); if(pz) pz.innerHTML = obsGridHTML(row._obs, row.observacion, "prov", i);
    var pi = byId("prov-obs-inp-"+i); if(pi && cambioP) pi.value = "";
  } else {
    var cambio = !row.material || row.material.id !== m.id;
    if(cambio){
      row.material = m; row._open = false; row.observacion = "";
      row._obs = obsDeMaterial(m.codigo);
    }
    row._codigo = String(m.codigo);
    var cell = byId(ctx+"-matcell-"+i);
    if(cell) cell.innerHTML = matButtonHTML(m, "Buscar material...", ctx, i) + (row._open ? ddOpenHTML(ctx, i) : "");
    if(ctx === "otadd"){
      var sc = byId("otadd-stockcell-"+i);
      if(sc) sc.innerHTML = stockPillHTML(m, row.cantidad, "otadd-stock-"+i);
    } else {
      var sc2 = byId("fila-stockcell-"+i);
      if(sc2) sc2.innerHTML = '<div style="min-height:34px;display:flex;align-items:center">'+stockPillHTML(m, row.cantidad, "mp-stock-"+i)+'</div>';
    }
    var oz = byId(ctx+"-obszone-"+i);
    if(oz) oz.innerHTML = obsGridHTML(row._obs, row.observacion, ctx, i);
    if(cambio){
      var ta = byId("obs-"+ctx+"-"+i);
      if(ta) ta.value = "";
    }
  }
  if(msg) msg.innerHTML = "";
};
function ddOpenHTML(ctx, i){
  var st = codRowOf(ctx, i); if(!st) return "";
  return '<div class="dd-list" style="position:static;margin-top:4px" id="ddlist-'+ctx+'-'+i+'">'
    + '<input id="ddsearch-'+ctx+'-'+i+'" class="dd-search" placeholder="Escribe codigo o descripcion..." value="'+esc(st._search||"")+'" oninput="App.matDDSearch(\''+ctx+'\','+i+',this.value)">'
    + '<div class="dd-items">'+ddListHTML(ctx, i)+'</div></div>';
}
function provSelHTML(i){
  var r = S.provRows[i]; if(!r) return "";
  return '<div class="mat-btn" style="cursor:default"><span class="sel"><span class="badge blue">'+esc(r.codigo)+'</span><span class="desc">'+esc(r.descripcion||"")+'</span></span>'
    + '<span style="display:flex;gap:.3rem"><button class="btn-ghost btn-sm" title="Cambiar" onclick="App.provAbrirBuscador('+i+')">'+ic("search")+'</button>'
    + '<button class="btn-ghost btn-sm" title="Quitar" onclick="App.provLimpiar('+i+')">'+ic("x")+'</button></span></div>';
}
/* Boton inicial de la casilla Material del provisional */
function provBtnInicialHTML(i){
  return '<button type="button" class="mat-btn" onclick="App.provAbrirBuscador('+i+')"><span class="ph">'+ic("search")+' Buscar material por codigo o descripcion...</span><span></span></button>';
}
/* Casilla Material cuando el codigo digitado NO existe en el inventario (codigo libre) */
function provLibreHTML(i){
  var r = S.provRows[i]; if(!r) return "";
  return '<div class="mat-btn" style="cursor:default;background:rgba(217,119,6,.06);border-color:var(--am500)">'
    + '<span class="sel"><span class="badge amber">CODIGO LIBRE</span><span class="desc" style="font-weight:800">'+esc(r.codigo)+' · no esta en el inventario</span></span>'
    + '<span style="display:flex;gap:.3rem"><button class="btn-ghost btn-sm" title="Cambiar" onclick="App.provAbrirBuscador('+i+')">'+ic("search")+'</button>'
    + '<button class="btn-ghost btn-sm" title="Quitar" onclick="App.provLimpiar('+i+')">'+ic("x")+'</button></span></div>'
    + '<input id="prov-libre-desc-'+i+'" class="mini" style="width:100%;margin-top:.35rem" placeholder="Descripcion del material (opcional, sale en el documento)" value="'+esc(r.descripcion||"")+'" oninput="App.provField('+i+',\'descripcion\',this.value)">';
}
/* Acepta el codigo buscado en el panel como CODIGO LIBRE (provisional) */
App.selProvLibre = function(rowIdx){
  var r = S.provRows[rowIdx]; if(!r) return;
  var q = String(r._search||"").trim();
  if(!q){ toast("Escribe un codigo","Digita el codigo libre en el buscador primero","destructive"); return; }
  r.codigo = q; r._codigo = q; r._open = false; r._results = []; r._lastMatched = null;
  renderModalContent();
  setTimeout(function(){ var di = byId("prov-libre-desc-"+rowIdx); if(di) di.focus(); }, 60);
  toast("✅ Codigo libre agregado", '"'+q+'" se usara en el documento aunque no este en el inventario', "success");
};


/* ---- Combo de Supervisor: escribe el nombre MANUAL o selecciona de la lista ----
   Los nombres escritos quedan guardados en la lista desplegable (persistente). */
function supComboHTML(id, campo, placeholder){
  return '<div class="dd" id="dd-'+id+'">'
    + '<input id="'+id+'" class="input dark" autocomplete="off" placeholder="'+esc(placeholder)+'" value="'+esc(S[campo]||"")+'"'
    + ' oninput="App.supComboInput(\''+id+'\',\''+campo+'\',this.value)"'
    + ' onfocus="App.supComboOpen(\''+id+'\',\''+campo+'\')"'
    + ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();App.supComboCerrar(\''+id+'\',\''+campo+'\')}">'
    + '<div class="dd-list" id="ddlist-sup-'+campo+'" style="display:none"></div>'
    + '</div>';
}
App.supComboOpen = function(id, campo){ App.supComboLista(id, campo); };
App.supComboInput = function(id, campo, val){
  S[campo] = String(val||"");
  App.supComboLista(id, campo);
};
App.supComboLista = function(id, campo){
  var cont = byId("ddlist-sup-"+campo);
  if(!cont) return;
  var q = String(S[campo]||"").toLowerCase().trim();
  var fil = [];
  for(var i=0;i<S.supervisores.length;i++){
    if(!q || String(S.supervisores[i]).toLowerCase().indexOf(q) >= 0) fil.push(S.supervisores[i]);
  }
  var html = "";
  if(fil.length){
    for(var j=0;j<fil.length;j++){
      var idx = S.supervisores.indexOf(fil[j]);
      html += '<div class="dd-item" onmousedown="App.supComboPick(\''+id+'\',\''+campo+'\','+idx+')">'
        + '<div class="info"><div class="top"><span class="badge blue">'+ic("user")+' Supervisor</span></div>'
        + '<div class="desc">'+esc(fil[j])+'</div></div>'
        + '<button type="button" class="dd-del" title="Eliminar '+esc(fil[j])+' de la lista" onmousedown="App.supComboEliminar(\''+id+'\',\''+campo+'\','+idx+',event)">'+ic("trash")+'</button></div>';
    }
  } else if(!q){
    html += '<div class="dd-empty">Escribe el nombre del supervisor. Quedara guardado en la lista para las proximas veces.</div>';
  }
  /* Nombre nuevo: la opcion de agregar solo aparece cuando NINGUN nombre
     de la lista coincide con lo escrito (evita guardar nombres incompletos) */
  if(q && !fil.length){
    html += '<div class="dd-item" onmousedown="App.supComboAgregar(\''+id+'\',\''+campo+'\')">'
      + '<div class="info"><div class="top"><span class="badge emerald">'+ic("plus")+' Agregar a la lista</span></div>'
      + '<div class="desc">Guardar "'+esc(String(S[campo]).trim())+'" como supervisor para proximas veces</div></div></div>';
  }
  cont.innerHTML = '<div class="dd-items">' + html + '</div>';
  cont.style.display = "block";
};
App.supComboPick = function(id, campo, idx){
  var nombre = S.supervisores[idx];
  if(!nombre) return;
  S[campo] = nombre;
  App.supComboCerrar(id, campo);
};
App.supComboAgregar = function(id, campo){
  var nombre = addSupervisor(S[campo]);
  if(!nombre) return;
  S[campo] = nombre;
  toast("✅ Supervisor agregado", '"' + nombre + '" quedo guardado en la lista para las proximas veces', "success");
  App.supComboCerrar(id, campo);
};
App.supComboCerrar = function(id, campo){
  var cont = byId("ddlist-sup-"+campo);
  if(cont) cont.style.display = "none";
  var inp = byId(id);
  if(inp) inp.value = String(S[campo]||"");
};
/* Elimina un nombre de la lista de supervisores (disponible en TODAS las ventanas
   donde aparezca el campo Supervisor: registro, ajustes de inventario, provisional y OT) */
App.supComboEliminar = function(id, campo, idx, ev){
  if(ev){ try{ ev.preventDefault(); ev.stopPropagation(); }catch(e){} }
  var nombre = S.supervisores[idx];
  if(!nombre) return;
  if(!confirm('¿Eliminar a "'+nombre+'" de la lista de supervisores?\n\nDejara de aparecer en la lista desplegable de todas las ventanas. Los registros ya guardados no se modifican.')) { App.supComboLista(id, campo); return; }
  S.supervisores.splice(idx, 1);
  saveSupervisores();
  App.supComboLista(id, campo);
  toast("🗑 Supervisor eliminado de la lista", '"'+nombre+'" ya no aparecera en las listas de seleccion', "success");
};
/* Cierra los combos de supervisor al hacer clic fuera */
document.addEventListener("click", function(e){
  ["rgSup","invAjSup","provSup","otNewSup"].forEach(function(campo){
    var cont = byId("ddlist-sup-"+campo);
    if(cont && cont.style.display !== "none"){
      if(!cont.parentNode.contains(e.target)) cont.style.display = "none";
    }
  });
});

/* ---- Tab registro ---- */
function tabRegistro(){
  var reg = individualFormHTML()
    + multiFormHTML()
    + '<div class="grid2" style="margin-top:1.2rem"><div></div><div id="reg-side">'+regSideHTML()+'</div></div>';
  return '<div class="space-y">'+reg+'</div>';
}
function turnoBadge(){
  if(!S.turno) return "";
  var dia = S.turno === "DIA";
  return '<div style="margin-top:.5rem;display:inline-flex;align-items:center;gap:.5rem;padding:.35rem .7rem;border-radius:.5rem;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.25);font-size:12px;color:#e2e8f0">'
    + ic("clock") + ' Turno actual: <strong style="color:'+(dia?"#fde68a":"#c7d2fe")+'">'+(dia?"☀ DIA (05:00 - 14:00)":"🌙 TARDE NOCHE (14:01 - 22:00)")+'</strong></div>';
}
function individualFormHTML(){
  var sel = S.matSel;
  var html = '<div class="card"><div class="card-header grad-blue"><div style="display:flex;align-items:center;justify-content:space-between;gap:.8rem;flex-wrap:wrap">'
    + '<div><div class="card-title xl">'+ic("fileText")+' Formulario de Registro</div><div class="card-desc">Completa los datos del consumo</div></div>'
    + (S.sesionCount > 0 ? '<span class="badge" style="background:rgba(255,255,255,.2);color:#fff;border-color:rgba(255,255,255,.3)">'+S.sesionCount+' en sesion</span>' : '')
    + '</div>'+turnoBadge()+'</div>'
    + '<div class="card-body" style="display:flex;flex-direction:column;gap:1.1rem">'
    + '<div class="mode-toggle">'
    + '<button class="'+(!S.modoMulti?"on-single":"")+'" onclick="App.setModo(false)">'+ic("package")+' Material individual</button>'
    + '<button class="'+(S.modoMulti?"on-multi":"")+'" onclick="App.setModo(true)">'+ic("layers")+' Carga multiple (varios a la vez)</button>'
    + '</div>'
    + '<div class="banner-amber"><div style="display:flex;align-items:center;gap:.5rem">'+ic("plus")+'<span>Quieres <strong>agregar mas materiales</strong> a una OT ya guardada?</span></div>'
    + '<button class="btn btn-sm btn-outline amber" onclick="App.abrirCargarOT()'+(S.isMobile?" disabled":"")+'">Cargar OT existente</button></div>'
    + '<div class="grid2i"><div><label class="label">'+ic("truck")+' Vehiculo <span class="req">*</span></label>'
    + '<input id="rg-vehiculo" class="input dark" value="'+esc(S.rgVeh||"")+'" oninput="S.rgVeh=this.value">'
    + '</div><div><label class="label">'+ic("fileText")+' OT (N) <span class="req">*</span></label>'
    + '<input id="rg-ot" class="input dark" value="'+esc(S.rgOT||"")+'" oninput="S.rgOT=this.value"></div></div>';
  if(!S.modoMulti){
    html += '<div><label class="label">'+ic("package")+' Codigo del Material <span class="req">*</span></label>'
      + '<div class="row"><input id="rg-codigo" class="input dark grow" placeholder="Digite el codigo y presione Enter" value="'+esc(sel ? sel.codigo : (S.rgCodigo||""))+'" oninput="App.codigoInput(this.value)" onkeydown="if(event.key===\'Enter\'){ event.preventDefault(); App.codigoEnter(); }">'
      + '<button type="button" class="btn btn-outline" onclick="App.codigoEnter()">'+ic("search")+' Buscar</button></div>'
      + (S.rgCodigoMsg ? '<div class="rg-code-msg">'+ic("alertTriangle")+' '+esc(S.rgCodigoMsg)+'</div>' : '')
      + matButtonHTML(sel, "O busca por descripcion en la lista...", "reg", -1);
    if(S.matOpen && sel === null || S.matOpen){
      html += '<div class="dd-list" style="position:static;margin-top:4px" id="ddlist-reg"><input id="ddsearch-reg" class="dd-search" placeholder="Escribe codigo o descripcion..." value="'+esc(S.matSearch||"")+'" oninput="App.matDDSearch(\'reg\',null,this.value)"><div class="dd-items">'+ddListHTML("reg", null)+'</div></div>';
    }
    if(sel){
      html += '<div class="mat-box" style="margin-top:.5rem">'
        + '<div style="display:flex;justify-content:space-between;font-size:10px;font-weight:700;color:var(--sl500);text-transform:uppercase"><span>Descripcion</span><span>Unidad</span></div>'
        + '<div class="rowline"><p class="desc-main">'+esc(sel.textoBreve)+'</p><span class="badge slate">'+esc(sel.unidadMedida)+'</span></div>'
        + (sel.ubicacion ? '<p style="font-size:11px;color:var(--sl500);border-top:1px solid var(--sl300);padding-top:.3rem">Ubicacion: '+esc(sel.ubicacion)+'</p>' : '')
        + stockPillHTML(sel, S.rgCant, "rg-stock-pill")
        + (S.matObs.length ? obsGridHTML(S.matObs, S.obsSel, "reg", -1) : '<p style="font-size:11px;color:var(--sl500);border-top:1px solid var(--sl300);padding-top:.3rem">Este material no tiene observaciones (NUEVO / REPARADO / RECUPERADO) registradas.</p>')
        + '</div>';
    }
    html += '</div>';
  }
  html += '<div class="grid2i">'
    + '<div><label class="label">'+ic("trendingUp")+' Cantidad a utilizar <span class="req">*</span></label>'
    + '<input id="rg-cant" type="number" step="0.01" min="0" class="input dark" value="'+esc(S.rgCant||"")+'" oninput="S.rgCant=this.value;App.previewStock()" onkeydown="if(event.key===\'Enter\')App.guardarIndividual()"></div>'
    + '<div><label class="label">'+ic("user")+' Supervisor en turno <span class="req">*</span></label>'
    + supComboHTML("rg-sup", "rgSup", "Escribe el nombre o selecciona de la lista...")
    + '</div></div>'
    + (!S.modoMulti ? '<div><label class="label">Observacion (opcional)</label>'
      + obsGridHTML(S.matObs, S.obsSel, "reg", -1)
      + '<textarea id="rg-obs" class="input" style="margin-top:.4rem" placeholder="Notas sobre el retiro, motivo, area, etc.'+(S.obsSel?" (o selecciona una sugerencia arriba)":"")+'" oninput="S.rgObsText=this.value">'+esc(S.rgObsText||"")+'</textarea>'
      + (S.obsSel ? '<button class="btn-ghost btn-sm" style="margin-top:.3rem" onclick="S.obsSel=\'\';App.renderRegistroTab()">✕ Limpiar</button>' : '')
      + '</div>' : '')
    + '<div style="display:flex;justify-content:flex-end;gap:.6rem;flex-wrap:wrap">'
    + '<button class="btn btn-ghost" onclick="App.nuevaOT()">'+ic("rotateCcw")+' Nueva OT (limpiar)</button>'
    + (S.modoMulti
       ? '<button class="btn btn-purple" onclick="App.agregarFila()">'+ic("plus")+' Agregar fila</button><button class="btn btn-primary" onclick="App.guardarMultiple()" style="padding:.5rem 1.6rem">'+ic("save")+' Guardar todo ('+S.multi.filter(function(r){return r.material && Number(r.cantidad)>0;}).length+')</button>'
       : '<button class="btn btn-primary" onclick="App.guardarIndividual()" style="padding:.5rem 1.6rem">'+ic("save")+' Guardar registro</button>')
    + '</div>'
    + (S.modoMulti ? '<div class="info-blue">'+ic("info")+' Modo carga multiple: agrega varios materiales en una sola pantalla y guardalos todos juntos en la misma OT. El sistema descuenta el stock de cada material automaticamente.</div>' : '')
    + '</div></div>';
  return html;
}
App.setModo = function(multi){
  if(multi === S.modoMulti) return;
  if(!multi && S.multi.length > 0 && S.multi.some(function(r){ return r.material || r.cantidad; })){
    if(!confirm("Tienes "+S.multi.length+" fila(s) en la lista. Si cambias al modo simple se perderan. ¿Continuar?")) return;
  }
  if(multi && S.multi.length === 0){
    S.multi = [{id: "1", material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  }
  S.modoMulti = multi;
  renderRegistroTab();
};
/* App.previewStock ya esta definido junto a stockPillInner (preview en vivo de "Quedan") */
function renderRegistroTab(){ if(S.view !== "main" || S.tab !== "registro") return; renderMain(); }
App.renderRegistroTab = renderRegistroTab;
App.nuevaOT = function(){
  if(S.sesionCount > 0 && !confirm("Vas a iniciar una nueva OT. Se guardaron "+S.sesionCount+" materiales en esta sesion. ¿Continuar?")) return;
  S.rgVeh = S.rgOT = S.rgCant = S.rgSup = S.rgObsText = ""; S.matSel = null; S.matObs = []; S.obsSel = "";
  S.rgCodigo = ""; S.rgCodigoMsg = "";
  S.sesionCount = 0; S.sesion = [];
  S.multi = [{id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  renderMain();
};
App.abrirCargarOT = function(){
  if(S.isMobile){ return; }
  S.cargarOTOpen = true;
  openModal('sm', 'grad-blue', ic("plus")+' Cargar OT existente', '<p style="font-size:13px;color:var(--sl600);margin-bottom:.8rem">Escribe el numero de OT a la que quieres agregar mas materiales.</p>'
    + '<input id="cargar-ot-input" class="input bold" autofocus value="'+esc(S.cargarOTVal||"")+'" oninput="S.cargarOTVal=this.value" onkeydown="if(event.key===\'Enter\')App.cargarOT()">',
    '<button class="btn btn-outline" onclick="App.cerrarModal()">Cancelar</button><button class="btn btn-primary" onclick="App.cargarOT()">'+ic("plus")+' Cargar OT</button>');
  setTimeout(function(){ var el = byId("cargar-ot-input"); if(el) el.focus(); }, 60);
};
App.cargarOT = function(){
  var ot = String(S.cargarOTVal||"").trim();
  if(!ot){ toast("Ingresa un numero de OT", null, "destructive"); return; }
  var regs = S.registros.filter(function(r){ return String(r.ot) === ot && !r.tipoAjuste; });
  if(!regs.length){ toast("OT no encontrada","No hay registros para la OT "+ot,"destructive"); return; }
  S.rgVeh = regs[0].vehiculo; S.rgOT = regs[0].ot; S.rgSup = regs[0].supervisor;
  S.sesionCount = 0; S.sesion = []; S.cargarOTOpen = false;
  App.cerrarModal();
  toast("OT "+ot+" cargada","Tiene "+regs.length+" materiales registrados. Ahora puedes seguir agregando.");
  renderMain();
};

/* ---- Guardar individual ---- */
App.guardarIndividual = function(){
  var veh = String(S.rgVeh||"").trim(), ot = String(S.rgOT||"").trim(),
      cant = String(S.rgCant||"").trim(), sup = String(S.rgSup||"").trim();
  var err;
  if(!veh) err = "Ingresa el numero del vehiculo";
  else if(!ot) err = "Ingresa el numero de OT";
  else if(!S.matSel) err = "Selecciona un material";
  else if(!cant || isNaN(Number(cant))) err = "La cantidad debe ser un numero";
  else if(Number(cant) <= 0) err = "La cantidad debe ser mayor a cero";
  else if(!sup) err = "Selecciona el supervisor en turno";
  if(err){ toast("Validacion", err, "destructive"); return; }
  var m = S.matSel;
  var obs = (S.obsSel || String(S.rgObsText||"")).trim();
  guardarRegistroCore({
    vehiculo: veh, ot: ot, materialId: m.id, codigo: m.codigo, descripcion: m.textoBreve,
    cantidad: Number(cant), unidad: m.unidadMedida, supervisor: sup, observacion: obs
  }, function(res){
    S.matSel = null; S.rgCant = ""; S.obsSel = ""; S.rgObsText = ""; S.matObs = [];
    S.rgCodigo = ""; S.rgCodigoMsg = "";
    renderMain();
  });
};
function guardarRegistroCore(payload, done){
  var m = matById(payload.materialId) || matByCodigo(payload.codigo);
  if(!m){ toast("Error","El material no existe en la base local. Actualiza el inventario.","destructive"); return; }
  var stockAntes = Number(m.stock)||0;
  var stockDespues = Math.round((stockAntes - Number(payload.cantidad))*100)/100;
  m.stock = stockDespues;
  saveInventario();
  var reg = {
    id: uid(), fecha: new Date().toISOString(),
    vehiculo: payload.vehiculo, ot: payload.ot,
    codigo: m.codigo, descripcion: payload.descripcion != null ? payload.descripcion : m.textoBreve,
    cantidad: Number(payload.cantidad), unidad: m.unidadMedida,
    supervisor: payload.supervisor, usuario: S.usuario.username,
    observacion: payload.observacion || "", turno: turnoNow()
  };
  if(payload.observacion) obsRegistrar(m.codigo, payload.observacion, payload.cantidad, "salida");
  S.registros.unshift(reg);
  saveRegistros();
  S.sesionCount++;
  S.sesion = S.sesion || [];
  S.sesion.unshift(reg);
  mostrarExitosa(reg, stockAntes, stockDespues);
  addSupervisor(payload.supervisor);
  var desc = payload.codigo + " - " + String(payload.descripcion||m.textoBreve).slice(0,40) + " | Cantidad: " + fmtC(payload.cantidad) + " " + m.unidadMedida;
  if(stockDespues < 0) toast("⚠️ Material guardado (STOCK INSUFICIENTE)", desc + " | Quedan: " + fmtC(stockDespues), "destructive");
  else if(stockDespues === 0) toast("⚠️ Material guardado (AGOTADO)", desc + " | Quedan: 0", "destructive");
  else if(stockDespues <= 5) toast("✅ Material guardado (stock bajo)", desc + " | Quedan: " + fmtC(stockDespues) + " " + m.unidadMedida);
  else toast("✅ Material guardado", desc + " | Quedan: " + fmtC(stockDespues) + " " + m.unidadMedida);
  /* Genera/actualiza el archivo HTML de la orden (descarga + carpeta de la PC si esta conectada) */
  if(typeof App.descargarOrdenHTML === "function") App.descargarOrdenHTML(payload.ot, true);
  if(done) done(reg);
}
function mostrarExitosa(reg, antes, despues){
  S.exitosa = {visible:true, reg: reg, antes: antes, despues: despues};
}
App.cerrarExitosa = function(){ S.exitosa = null; renderMain(); };

/* ---- Carga multiple ---- */
function multiFormHTML(){
  if(!S.modoMulti) return "";
  var rows = "";
  for(var i=0;i<S.multi.length;i++){
    var r = S.multi[i];
    rows += filaMultiHTML(r, i);
  }
  return '<div style="display:flex;flex-direction:column;gap:.7rem">'
    + '<div class="info-blue" style="display:flex;justify-content:space-between;align-items:center;gap:.6rem"><span>'+ic("layers")+' <strong>'+S.multi.length+'</strong> fila(s) en esta carga multiple</span>'
    + '<button class="btn btn-sm btn-outline red" onclick="App.limpiarMulti()">✕ Limpiar</button></div>'
    + rows + '</div>';
}
function filaMultiHTML(r, i){
  var obsPart = "";
  if(r.material){
    obsPart = obsGridHTML(r._obs, r.observacion, "fila", i);
  }
  return '<div class="row-card"><div class="row-head"><span class="n">Fila '+(i+1)+'</span>'
    + '<button class="btn-ghost btn-sm" style="color:var(--red600)" onclick="App.quitarFila('+i+')">'+ic("trash")+'</button></div>'
    + '<div><label class="label" style="font-size:11px">Material (codigo o descripcion)</label>'
    + codInputHTML("fila", i, "Digite el codigo del material...")
    + '<div id="codmsg-fila-'+i+'"></div>'
    + '<div id="fila-matcell-'+i+'">'+ matButtonHTML(r.material, "O busca por descripcion en la lista...", "fila", i)
    + (r._open ? ddOpenHTML("fila", i) : '')
    + '</div></div>'
    + '<div class="grid2i"><div><label class="label" style="font-size:11px">Cantidad <span class="req">*</span></label>'
    + '<input type="number" step="0.01" min="0" class="input" value="'+esc(r.cantidad||"")+'" oninput="App.multiField('+i+',\'cantidad\',this.value)"></div>'
    + '<div><label class="label" style="font-size:11px">Queda en stock</label>'
    + '<div id="fila-stockcell-'+i+'">'
    + (r.material ? '<div style="min-height:34px;display:flex;align-items:center">'+stockPillHTML(r.material, r.cantidad, "mp-stock-"+i)+'</div>' : '<div style="height:34px;display:flex;align-items:center;color:var(--sl400);font-size:12px">—</div>')
    + '</div></div></div>'
    + '<div><label class="label" style="font-size:11px">Observacion (opcional)</label>'
    + '<div id="fila-obszone-'+i+'">'+obsPart+'</div>'
    + '<textarea id="obs-fila-'+i+'" class="input" style="min-height:44px;margin-top:.35rem" placeholder="Observaciones (opcional)" oninput="App.multiField('+i+',\'observacion\',this.value)">'+esc(r.observacion||"")+'</textarea>'
    + '</div></div>';
}
App.multiField = function(i, field, val){
  if(!S.multi[i]) return;
  S.multi[i][field] = val;
  /* Al digitar la cantidad se actualiza el "Queda en stock" de la fila (sin re-render) */
  if(field === "cantidad" && S.multi[i].material){
    var el = byId("mp-stock-"+i);
    if(el) el.innerHTML = stockPillInner(S.multi[i].material, val);
  }
};
App.agregarFila = function(){
  S.multi.push({id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]});
  renderRegistroTab();
};
App.quitarFila = function(i){ S.multi.splice(i,1); renderRegistroTab(); };
App.limpiarMulti = function(){
  S.multi = [{id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  renderRegistroTab();
};
App.guardarMultiple = function(){
  var veh = String(S.rgVeh||"").trim(), ot = String(S.rgOT||"").trim(), sup = String(S.rgSup||"").trim();
  var err;
  if(!veh) err = "Ingresa el numero del vehiculo";
  else if(!ot) err = "Ingresa el numero de OT";
  else if(!sup) err = "Selecciona el supervisor en turno";
  else if(S.multi.filter(function(r){ return r.material && r.cantidad && Number(r.cantidad) > 0; }).length === 0) err = "Agrega al menos un material con cantidad valida";
  if(err){ toast("Validacion", err, "destructive"); return; }
  var validas = S.multi.filter(function(r){ return r.material && r.cantidad && Number(r.cantidad) > 0; });
  if(!confirm("Vas a guardar "+validas.length+" materiales en la OT "+ot+". ¿Continuar?")) return;
  var ok = 0, fail = 0, bajos = [];
  for(var i=0;i<validas.length;i++){
    var r = validas[i];
    var m = matById(r.material.id);
    if(!m){ fail++; continue; }
    var stockAntes = Number(m.stock)||0;
    m.stock = Math.round((stockAntes - Number(r.cantidad))*100)/100;
    var reg = {
      id: uid(), fecha: new Date().toISOString(),
      vehiculo: veh, ot: ot, codigo: m.codigo, descripcion: m.textoBreve,
      cantidad: Number(r.cantidad), unidad: m.unidadMedida, supervisor: sup,
      usuario: S.usuario.username, observacion: String(r.observacion||"").trim(), turno: turnoNow()
    };
    if(reg.observacion) obsRegistrar(m.codigo, reg.observacion, reg.cantidad, "salida");
    S.registros.unshift(reg); saveRegistros();
    if(m.stock <= 0) bajos.push(m.codigo + ": " + fmtC(m.stock) + " " + m.unidadMedida);
    ok++;
  }
  saveInventario();
  S.sesionCount += ok;
  if(ok > 0){
    var titulo = "✅ "+ok+" materiales guardados en OT "+ot, tdesc = "Quedan actualizados en el inventario. Archivo HTML de la orden generado" + (fail>0 ? " ("+fail+" fallidos)" : "");
    if(bajos.length){ titulo = "⚠️ "+ok+" guardados, "+bajos.length+" con stock bajo/insuficiente"; tdesc = "Quedan bajo: " + bajos.join(", ").slice(0,180); }
    toast(titulo, tdesc, bajos.length ? "destructive" : "default");
    S.multi = [{id: uid(), material: null, cantidad: "", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  } else {
    toast("Error","No se pudo guardar ningun material","destructive");
  }
  /* Archivo HTML de la orden completa (todos los materiales de la OT) */
  if(ok > 0 && typeof App.descargarOrdenHTML === "function") App.descargarOrdenHTML(ot, true);
  renderMain();
};

/* ---- Columna derecha: sesion + exitosa ---- */
function regSideHTML(){
  var html = "";
  if(S.exitosa && S.exitosa.visible){
    var r = S.exitosa.reg;
    var quedanCls = S.exitosa.despues <= 0 ? "color:var(--red600)" : "color:var(--em700)";
    html += '<div class="exitosa-card" style="margin-bottom:1rem"><h4>'+ic("checkCircle")+' Salida registrada correctamente</h4>'
      + '<div class="exitosa-grid">'
      + '<div class="c"><div class="k">Material</div><div class="v" title="'+esc(r.descripcion)+'">'+esc(r.codigo)+'</div></div>'
      + '<div class="c"><div class="k">Entregado</div><div class="v">'+fmtC(r.cantidad)+' '+esc(r.unidad||"")+'</div></div>'
      + '<div class="c"><div class="k">Stock anterior</div><div class="v">'+fmtC(S.exitosa.antes)+'</div></div>'
      + '<div class="c"><div class="k">Quedan</div><div class="v" style="'+quedanCls+';font-weight:900">'+fmtC(S.exitosa.despues)+' '+esc(r.unidad||"")+'</div></div>'
      + '<div class="c" style="grid-column:1/-1;text-align:left"><div class="k">Descripcion</div><div style="font-size:11.5px;font-weight:700;color:var(--sl800)">'+esc(r.descripcion)+'</div></div>'
      + '</div>'
      + '<p style="font-size:11px;color:var(--em800);font-weight:700;margin-bottom:.5rem">✔ En el inventario quedan '+fmtC(S.exitosa.despues)+' '+esc(r.unidad||"")+' del material '+esc(r.codigo)+'</p>'
      + '<div style="display:flex;gap:.45rem">'
      + '<button class="btn btn-primary btn-sm" style="flex:1" onclick="App.descargarOrdenHTML(\''+esc(String(r.ot).replace(/'/g,""))+'\')" title="Genera el archivo HTML de la orden OT '+esc(r.ot)+' con todos sus detalles">'+ic("download")+' Orden en HTML</button>'
      + '<button class="btn btn-emerald btn-sm" style="flex:1" onclick="App.cerrarExitosa()">Aceptar</button>'
      + '</div></div>';
  }
  var sesion = S.sesion || [];
  html += '<div class="sesion-card"><div class="card-header" style="padding:.8rem 1rem;background:var(--sl50)"><div class="card-title" style="font-size:.95rem;color:var(--sl800)">'+ic("package")+' Materiales agregados en esta sesion</div>'
    + '<div class="card-desc dark">'+sesion.length+' materiales registrados</div></div>';
  if(!sesion.length){
    html += '<div class="empty-state" style="height:150px"><div class="t" style="font-size:13px;color:var(--sl500)">Aun no registras materiales en esta sesion</div></div>';
  } else {
    for(var i=0;i<Math.min(sesion.length, 25);i++){
      var r = sesion[i];
      html += '<div class="sesion-item"><div class="cd"><span>'+esc(r.codigo)+'</span><span>'+fmtC(r.cantidad)+' '+esc(r.unidad)+'</span></div>'
        + '<div class="ds">'+esc(r.descripcion)+'</div>'
        + '<div class="mt"><span>Vehiculo: '+esc(r.vehiculo)+'</span><span>OT: '+esc(r.ot)+'</span><span>Turno: '+(r.turno==="DIA"?"☀ DIA":"🌙 T/N")+'</span></div></div>';
    }
  }
  html += '</div>';
  return html;
}
