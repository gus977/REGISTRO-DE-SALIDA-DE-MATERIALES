/* ============================================================
   PROVISIONAL DE DESPACHO
   ============================================================ */
App.abrirProvisional = function(){
  S.provOpen = true;
  S.provTipo = "contratista"; S.provDest = ""; S.provSup = "";
  S.provFecha = hoyISO(); S.provTurno = turnoNow();
  S.provRows = [{id: uid(), codigo: "", descripcion: "", cantidad: "", unidad: "UN", observacion: "", _open:false,_search:"",_results:[],_obs:[]}];
  S.provRecibe = ""; S.provObsGen = "";
  openModal('xl','grad-purple', ic("layers")+' Provisional de Despacho', 'Genera documento de entrega provisional de materiales','');
  renderModalContent();
};
function provModalHTML(){
  var rows = "";
  for(var i=0;i<S.provRows.length;i++){
    var r = S.provRows[i];
    var m = r.codigo ? matByCodigo(r.codigo) : null;
    rows += '<div class="row-card"><div class="row-head"><span class="n">Material '+(i+1)+'</span>'
      + '<button class="btn-ghost btn-sm" style="color:var(--red600)" onclick="App.provQuitar('+i+')">'+ic("trash")+'</button></div>'
      + '<div><label class="label" style="font-size:11px">Material (codigo o descripcion)</label>'
      + '<div id="prov-matcell-'+i+'">'
      + (r._open ? ddOpenHTML("prov", i)
        : (r.codigo
          ? (matByCodigo(r.codigo) ? provSelHTML(i) : provLibreHTML(i))
          : provBtnInicialHTML(i)))
      + '</div></div>'
      + '<div class="row-grid"><div><label class="label" style="font-size:11px">Codigo (digitelo y la descripcion aparece sola)</label>'
      + '<input id="cod-prov-'+i+'" class="mini" value="'+esc(r._codigo!=null?r._codigo:r.codigo)+'" autocomplete="off"'
      + ' oninput="App.codRowInput(\'prov\','+i+',this.value)"'
      + ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();App.codRowEnter(\'prov\','+i+')}"'
      + '>'
      + '<div id="codmsg-prov-'+i+'"></div></div>'
      + '<div><label class="label" style="font-size:11px">Cantidad <span class="req">*</span></label><input type="number" step="0.01" min="0" class="mini" value="'+esc(r.cantidad)+'" oninput="App.provField('+i+',\'cantidad\',this.value)"></div>'
      + '<div><label class="label" style="font-size:11px">Unidad</label><input id="prov-uni-'+i+'" class="mini" value="'+esc(r.unidad)+'" oninput="App.provField('+i+',\'unidad\',this.value)"></div>'
      + '<div style="display:flex;align-items:flex-end"><span id="prov-stock-'+i+'">'+(m?'<span class="badge '+(m.stock>0?"emerald":"red")+'" title="Stock actual">Stock: '+fmtC(m.stock)+'</span>':'<span class="badge slate">Libre</span>')+'</span></div></div>'
      + '<div><label class="label" style="font-size:11px">Observacion (automatica o manual)</label>'
      + '<div id="prov-obszone-'+i+'">'+obsGridHTML(r._obs, r.observacion, "prov", i)+'</div>'
      + '<input id="prov-obs-inp-'+i+'" class="mini" style="width:100%;margin-top:.35rem" value="'+esc(r.observacion)+'" oninput="App.provField('+i+',\'observacion\',this.value)" placeholder="Escribe una observacion o selecciona una opcion arriba"></div>'
      + '</div>';
  }
  var html = '<div class="modal-body" style="display:flex;flex-direction:column;gap:1rem">'
    + '<div style="background:var(--sl50);border:1px solid var(--sl300);border-radius:.6rem;padding:.9rem;display:flex;flex-direction:column;gap:.8rem">'
    + '<h4 style="font-size:13px;font-weight:800;color:var(--sl800);text-transform:uppercase;letter-spacing:.03em;display:flex;gap:.4rem;align-items:center">'+ic("info")+' Datos del Despacho</h4>'
    + '<div><label class="label" style="font-size:11.5px">Tipo de destinatario</label><div class="tipo-btns">'
    + [["contratista","Contratista"],["vehiculo","Vehiculo"],["proyecto","Proyecto"]].map(function(t){ return '<button type="button" class="'+(S.provTipo===t[0]?"on":"")+'" onclick="App.provTipoSet(\''+t[0]+'\')">'+t[1]+'</button>'; }).join("")
    + '</div></div>'
    + '<div class="grid2i">'
    + '<div><label class="label" style="font-size:11.5px">'+(S.provTipo==="contratista"?"Contratista":S.provTipo==="vehiculo"?"Vehiculo":"Proyecto")+' <span class="req">*</span></label>'
    + '<input class="input" value="'+esc(S.provDest)+'" oninput="S.provDest=this.value"></div>'
    + '<div><label class="label" style="font-size:11.5px">Supervisor Contratista en turno <span class="req">*</span></label>'
    + supComboHTML("prov-sup", "provSup", "Escribe el nombre o selecciona de la lista...")
    + '</div></div>'
    + '<div class="grid2i">'
    + '<div><label class="label" style="font-size:11.5px">Fecha</label><input type="date" class="input" value="'+esc(S.provFecha)+'" onchange="S.provFecha=this.value"></div>'
    + '<div><label class="label" style="font-size:11.5px">Turno (automatico)</label><div class="turno-btns">'
    + '<button type="button" class="'+(S.provTurno==="DIA"?"on-dia":"")+'" onclick="App.provTurnoSet(\'DIA\')">☀ DIA (05:00 - 14:00)</button>'
    + '<button type="button" class="'+(S.provTurno==="TARDE_NOCHE"?"on-tn":"")+'" onclick="App.provTurnoSet(\'TARDE_NOCHE\')">🌙 T/N (14:01 - 22:00)</button>'
    + '</div></div></div></div>'
    + '<div style="display:flex;flex-direction:column;gap:.7rem">'
    + '<div style="display:flex;align-items:center;justify-content:space-between;gap:.6rem;flex-wrap:wrap"><h4 style="font-size:13px;font-weight:800;color:var(--sl800);display:flex;gap:.4rem;align-items:center">'+ic("package")+' Materiales del despacho</h4>'
    + '<span style="display:flex;gap:.4rem"><button class="btn btn-sm btn-outline purple" onclick="App.provFila()">'+ic("plus")+' Agregar material</button>'
    + '<button class="btn btn-sm btn-outline red" onclick="App.provLimpiarTodo()">✕ Limpiar</button></span></div>'
    + rows
    + '</div>'
    + '<div style="background:var(--sl50);border:1px solid var(--sl300);border-radius:.6rem;padding:.9rem;display:flex;flex-direction:column;gap:.8rem">'
    + '<h4 style="font-size:13px;font-weight:800;color:var(--sl800);display:flex;gap:.4rem;align-items:center">'+ic("userCheck")+' Entrega y Recepcion</h4>'
    + '<div class="grid2i">'
    + '<div><label class="label" style="font-size:11.5px">Entrega (usuario en sesion)</label>'
    + '<input class="input" value="'+esc(nombreUsuario())+'" readonly style="background:var(--sl100);color:var(--sl600)">'
    + '<p style="font-size:10.5px;color:var(--sl500);margin-top:.25rem">Se carga automaticamente con el usuario que tiene la sesion abierta *</p></div>'
    + '<div><label class="label" style="font-size:11.5px">Quien recibe <span class="req">*</span></label>'
    + '<input class="input" value="'+esc(S.provRecibe)+'" oninput="S.provRecibe=this.value" placeholder="Nombre de quien recibe los materiales">'
    + '<p style="font-size:10.5px;color:var(--sl500);margin-top:.25rem">Campo obligatorio - aparece en la seccion de firmas del documento</p></div></div>'
    + '<div><label class="label" style="font-size:11.5px">Observaciones generales (opcional)</label>'
    + '<textarea class="input" style="min-height:54px" oninput="S.provObsGen=this.value" placeholder="Notas adicionales del despacho">'+esc(S.provObsGen||"")+'</textarea></div></div>'
    + '</div>'
    + '<div class="modal-foot" style="justify-content:space-between;flex-wrap:wrap;gap:.5rem">'
    + '<span style="font-size:11.5px;color:var(--sl600)">El documento se abrira en otra pestaña para imprimir o guardar como PDF</span>'
    + '<span style="display:flex;gap:.5rem">'
    + '<button class="btn btn-outline" onclick="App.provCerrar()">Cerrar</button>'
    + '<button class="btn btn-purple" onclick="App.provGuardar()"'+(S.provBusy?" disabled":"")+'>'+ic("printer")+' '+(S.provBusy?"Generando...":"GENERAR DOCUMENTO HTML")+'</button></span></div>';
  return html;
}
App.provTipoSet = function(t){ S.provTipo = t; renderModalContent(); };
App.provTurnoSet = function(t){ S.provTurno = t; renderModalContent(); };
App.provFila = function(){ S.provRows.push({id: uid(), codigo: "", descripcion: "", cantidad: "", unidad: "UN", observacion: "", _open:false,_search:"",_results:[],_obs:[]}); renderModalContent(); };
App.provQuitar = function(i){ S.provRows.splice(i,1); renderModalContent(); };
App.provLimpiarTodo = function(){ S.provRows = [{id: uid(), codigo: "", descripcion: "", cantidad: "", unidad: "UN", observacion: "", _open:false,_search:"",_results:[],_obs:[]}]; renderModalContent(); };
App.provField = function(i, campo, val){ if(S.provRows[i]) S.provRows[i][campo] = val; };
App.provAbrirBuscador = function(i){ S.provRows[i]._open = true; S.provRows[i]._search = ""; S.provRows[i]._results = buscarMaterialesLocal("", 50); renderModalContent(); };
App.provLimpiar = function(i){ S.provRows[i].codigo = ""; S.provRows[i].descripcion = ""; S.provRows[i].unidad = "UN"; S.provRows[i]._obs = []; S.provRows[i]._codigo = ""; S.provRows[i]._codMsg = ""; renderModalContent(); };
App.provCerrar = function(){ S.provOpen = false; closeModal(); };
App.provGuardar = function(){
  var dest = String(S.provDest||"").trim(), sup = String(S.provSup||"").trim(), recibe = String(S.provRecibe||"").trim();
  if(!dest){ toast("Falta destinatario","Ingresa el contratista, vehiculo o proyecto","destructive"); return; }
  if(!sup){ toast("Falta supervisor","Ingresa el supervisor contratista en turno","destructive"); return; }
  if(!recibe){ toast("Falta quien recibe","Ingresa el nombre de quien recibe los materiales","destructive"); return; }
  var mats = S.provRows.filter(function(r){ return String(r.codigo||"").trim() && r.cantidad && Number(r.cantidad) > 0; });
  if(!mats.length){ toast("Sin materiales","Agrega al menos un material con codigo y cantidad","destructive"); return; }
  addSupervisor(sup);   /* El supervisor escrito queda en la lista para proximas veces */
  S.provBusy = true; renderModalContent();
  var fechaISO = new Date(S.provFecha + "T" + new Date().toTimeString().split(" ")[0]).toISOString();
  var seq = (DB.get("provSeq", 0) || 0) + 1;
  DB.set("provSeq", seq);
  var numero = "PD-" + new Date().getFullYear() + "-" + String(seq).padStart(4,"0");
  var prov = {
    id: uid(), numeroDocumento: numero,
    tipoDestinatario: S.provTipo, destinatario: dest,
    fecha: fechaISO, turno: S.provTurno,
    supervisorContratista: sup,
    materiales: mats.map(function(r){ return {codigo: String(r.codigo).trim(), descripcion: String(r.descripcion||"").trim(), cantidad: Number(r.cantidad), unidad: String(r.unidad||"UN"), observacion: String(r.observacion||"").trim()}; }),
    quienRecibe: recibe, entregadoPor: nombreUsuario(),
    observacionesGenerales: String(S.provObsGen||"").trim(),
    usuarioGenerador: S.usuario.username, createdAt: new Date().toISOString()
  };
  S.provisionales.unshift(prov);
  saveProvisionales();
  abrirDocProvisional(prov, true);
  S.provBusy = false; S.provOpen = false;
  closeModal(); renderMain();
  toast("✅ Provisional generado y guardado","Se genero el documento "+numero+" con "+mats.length+" material(es) para "+dest);
};
/* provisionales guardados */
App.abrirProvGuardadas = function(){
  S.provGuardOpen = true;
  openModal('lg','grad-purple', ic("clipboard")+' Provisionales Guardados', S.provisionales.length+' documento(s) guardado(s) en esta PC','');
  renderModalContent();
};
function provGuardadasHTML(){
  var html = '<div class="modal-body">';
  if(!S.provisionales.length){
    html += '<div class="empty-state" style="height:220px">'+ic("clipboard")+'<p class="t">No hay provisionales guardados</p><p class="s">Los despachos que generes apareceran aqui</p></div>';
  } else {
    S.provisionales.forEach(function(p){
      html += '<div class="prov-item"><div style="display:flex;justify-content:space-between;gap:.5rem;flex-wrap:wrap">'
        + '<div><div class="num">'+esc(p.numeroDocumento)+' · '+esc(p.destinatario)+'</div>'
        + '<div class="mt">'+fmtF(p.fecha)+' · '+(p.turno==="DIA"?"☀ DIA":"🌙 T/N")+' · '+p.materiales.length+' material(es) · Generado por '+esc(p.usuarioGenerador)+' el '+fmtF(p.createdAt)+'</div></div>'
        + '<div class="acts"><button class="btn btn-sm btn-primary" onclick="App.verProvHTML(\''+p.id+'\')">'+ic("eye")+' Ver HTML</button>'
        + '<button class="btn btn-sm btn-outline red" onclick="App.eliminarProvisional(\''+p.id+'\',\''+esc(p.numeroDocumento)+'\')">'+ic("trash")+' Eliminar</button></div>'
        + '</div></div>';
    });
  }
  html += '</div><div class="modal-foot"><button class="btn btn-outline" onclick="App.cerrarProvGuardadas()">Cerrar</button></div>';
  return html;
}
App.verProvHTML = function(id){
  var p = null;
  S.provisionales.forEach(function(x){ if(x.id === id) p = x; });
  if(p) abrirDocProvisional(p, false);
};
App.eliminarProvisional = function(id, num){
  if(!confirm("¿Eliminar el provisional "+num+"? Esta accion no se puede deshacer.")) return;
  S.provisionales = S.provisionales.filter(function(p){ return p.id !== id; });
  saveProvisionales();
  renderModalContent(); renderMain();
  toast("✅ Provisional eliminado","Se elimino el documento "+num);
};
App.cerrarProvGuardadas = function(){ S.provGuardOpen = false; closeModal(); };
