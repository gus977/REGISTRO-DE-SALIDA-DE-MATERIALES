/* =====================================================
   SISTEMA DE REGISTRO DE MATERIALES - VERSION WEB COMPLETA
   Almacenamiento: base de datos del servidor (persistente)
   + memoria del navegador como cache de sesion
   ===================================================== */
"use strict";

/* ============ ICONOS (SVG inline, estilo lucide) ============ */
var ICONS = {
  boxes:'<path d="M2.97 12.92A2 2 0 0 0 2 14.63v3.24a2 2 0 0 0 .97 1.71l3 1.8a2 2 0 0 0 2.06 0L12 19v-5.5l-5-3-4.03 2.42Z"/><path d="m7 16.5-4.74-2.85"/><path d="m7 16.5 5-3"/><path d="M7 16.5v5.17"/><path d="M12 13.5V19l3.97 2.38a2 2 0 0 0 2.06 0l3-1.8a2 2 0 0 0 .97-1.71v-3.24a2 2 0 0 0-.97-1.71L17 10.5l-5 3Z"/><path d="m17 16.5-5-3"/><path d="m17 16.5 4.74-2.85"/><path d="M17 16.5v5.17"/><path d="M7.97 4.42A2 2 0 0 0 7 6.13v4.37l5 3 5-3V6.13a2 2 0 0 0-.97-1.71l-3-1.8a2 2 0 0 0-2.06 0l-3 1.8Z"/><path d="M12 8 7.26 5.15"/><path d="m12 8 4.74-2.85"/><path d="M12 13.5V8"/>',
  shieldCheck:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  shield:'<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>',
  database:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5V19A9 3 0 0 0 21 19V5"/><path d="M3 12A9 3 0 0 0 21 12"/>',
  trendingUp:'<path d="M16 7h6v6"/><path d="m22 7-8.5 8.5-5-5L2 17"/><path d="M18 17h4v-4"/>',
  clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  logOut:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
  package:'<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M12 22V12"/><path d="m3.3 7 8.7 5 8.7-5"/><path d="M7.5 4.27l9 5.15"/>',
  fileText:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  layers:'<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="M22 17.65l-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="M22 12.65l-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
  plus:'<path d="M5 12h14"/><path d="M12 5v14"/>',
  search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  userCheck:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>',
  calendar:'<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  x:'<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  eye:'<path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/><circle cx="12" cy="12" r="3"/>',
  eyeOff:'<path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/><path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/><path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/><path d="m2 2 20 20"/>',
  printer:'<path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6"/><rect x="6" y="14" width="12" height="8" rx="1"/>',
  trash:'<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
  save:'<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
  truck:'<path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/>',
  checkCircle:'<path d="M21.801 10A10 10 0 1 1 17 3.335"/><path d="m9 11 3 3L22 4"/>',
  alertTriangle:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  mapPin:'<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
  store:'<path d="m2 7 4.41-4.41A2 2 0 0 1 7.83 2h8.34a2 2 0 0 1 1.42.59L22 7"/><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><path d="M15 22v-4a2 2 0 0 0-2-2h-2a2 2 0 0 0-2 2v4"/><path d="M2 7h20"/><path d="M22 7v3a2 2 0 0 1-2 2 2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 16 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 12 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 8 12a2.7 2.7 0 0 1-1.59-.63.7.7 0 0 0-.82 0A2.7 2.7 0 0 1 4 12a2 2 0 0 1-2-2V7"/>',
  chevronLeft:'<path d="m15 18-6-6 6-6"/>',
  chevronRight:'<path d="m9 18 6-6-6-6"/>',
  refreshCw:'<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  rotateCcw:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  edit:'<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
  lock:'<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
  copy:'<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  arrowLeft:'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  arrowRight:'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  check:'<path d="M20 6 9 17l-5-5"/>',
  history:'<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
  clipboard:'<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/>',
  smartphone:'<rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/>',
  folder:'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  folderOpen:'<path d="m6 14 1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2"/>',
  folderCheck:'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/><path d="m9.5 12.5 2 2 4-4"/>',
  folderMinus:'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/><line x1="9" x2="15" y1="13" y2="13"/>',
  hardDrive:'<line x1="22" x2="2" y1="12" y2="12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/><line x1="6" x2="6.01" y1="16" y2="16"/><line x1="10" x2="10.01" y1="16" y2="16"/>'
};
function ic(name, cls){ return '<svg class="'+(cls||'ic-16')+'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:1em;height:1em;vertical-align:-0.125em">'+(ICONS[name]||'')+'</svg>'; }

/* ============ ALMACENAMIENTO (base de datos del servidor) ============
   Los datos viven en el servidor y NO se borran solos. Al abrir la app
   se cargan completos (WebStore.loadAll) y cada cambio se sincroniza
   automaticamente. DB.mem actua como cache de la sesion. */
var DB = {
  mem: {},
  get: function(key, def){
    if(key in DB.mem) return DB.mem[key];
    DB.mem[key] = def;
    return def;
  },
  set: function(key, val){
    DB.mem[key] = val;
    if(typeof WebStore !== "undefined") WebStore.programar(key);
  },
  exportAll: function(){
    var data = { _sistema: "Registro de Materiales", _version: 1, _fecha: new Date().toISOString() };
    ["usuarios","session","registros","inventario","provisionales","otsLegalizadas","otsOcultas","supervisores","entradas","obsHist","provSeq","lastUpload","provGuardadas","widgetPos"].forEach(function(k){
      data[k] = DB.get(k, k==="registros"||k==="inventario"||k==="provisionales"||k==="otsLegalizadas"||k==="otsOcultas"||k==="supervisores"||k==="entradas"||k==="obsHist"||k==="provGuardadas" ? [] : null);
    });
    return data;
  },
  importAll: function(data){
    ["usuarios","session","registros","inventario","provisionales","otsLegalizadas","otsOcultas","supervisores","entradas","obsHist","provSeq","lastUpload","provGuardadas","widgetPos"].forEach(function(k){
      if(k in data) DB.set(k, data[k]);
    });
    if(typeof WebStore !== "undefined") WebStore.marcarTodo();
  }
};
function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,8); }
function esc(s){ return String(s==null?"":s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"); }

/* ============ ESTADO GLOBAL ============ */
var S = {
  view: "login",           // login | main | admin | entrada | pendientes
  tab: "registro",         // registro | ots | inventario | historial
  usuario: null,           // {username, nombre, nombreCompleto}
  registros: [],           // historial de movimientos
  inventario: [],          // base de materiales
  provisionales: [],       // provisionales guardados
  legalizadas: new Set(),
  ocultas: new Set(),
  supervisores: [],
  entradas: [],
  widgetPos: {},           // posicion flotante guardada del reloj y calendario
  // registrar
  modoMulti: false, multi: [], obsSel: "", recentId: 0, sesionCount: 0,
  rgCodigo: "", rgCodigoMsg: "", _codTimer: null,
  // buscador material individual
  matSearch: "", matOpen: false, matResults: [], matSel: null, matObs: [],
  // cargar OT / agregar
  cargarOTOpen: false, cargarOTVal: "", otModal: null, otModalRegs: [], otEditando: false,
  otNew: "", otNewVeh: "", otNewSup: "", otAddOpen: false, otAddRows: [], otAddSearch: {}, otAddResults: {}, otAddObs: {},
  editCell: null, editVal: "", editTipo: null, editRegId: null, provSearchState: {}, provRowIdx: null,
  // inventario
  invSearch: "", invFiltro: "todos", invPage: 0, invLoading: false, invDetail: null, invObs: [],
  invAjOpen: false, invAjStock: "", invAjVeh: "", invAjOT: "", invAjSup: "", invAjObs: "", invAjSaving: false,
  invUpOpen: false, invUpFile: null, invUpName: "", invUpResult: null, invUpBusy: false,
  // historial
  hCod: "", hOT: "", hUsu: "",
  // provisional
  provOpen: false, provTipo: "contratista", provDest: "", provSup: "", provFecha: "", provTurno: "", provRows: [], provRecibe: "", provObsGen: "", provBusy: false, provSearch: {}, provResults: {}, provObsMap: {},
  provGuardOpen: false,
  // pendientes
  pUsu: "", pMat: "", pOT: "", pSyncOpen: false, pSyncFile: null, pSyncResult: null, pSacar: null,
  // entrada
  eCod: "", eFound: null, eTA: "", eAlm: "", eDesc: "", eCant: "", eUni: "UN", eUbic: "", eObs: "", eSesion: [],
  // admin
  adModo: "agregar", adFile: null, adName: "", adPreview: null, adBusy: false,
  // misc
  isMobile: false, turno: "DIA", welcome: false
};

/* ============ UTILIDADES ============ */
function $(sel){ return document.querySelector(sel); }
function $$(sel){ return Array.prototype.slice.call(document.querySelectorAll(sel)); }
function byId(id){ return document.getElementById(id); }
function fmtN(n){ return Number(n).toLocaleString("es-CO"); }
function fmtC(n){ var x = Number(n)||0; return (Math.round(x*100)/100).toFixed(2).replace(/\.00$/,""); }
function fmtF(iso){ try{ return new Date(iso).toLocaleString("es-CO",{year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}); }catch(e){ return iso||""; } }
function hoyISO(){ return new Date().toISOString().split("T")[0]; }
function turnoNow(){
  var t = new Date(), h = t.getHours(), m = t.getMinutes();
  return (h >= 5 && (h < 14 || (h === 14 && m === 0))) ? "DIA" : "TARDE_NOCHE";
}
function isMobile(){
  var w = window.innerWidth, ua = navigator.userAgent || navigator.vendor || window.opera;
  var mob = /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(ua.toLowerCase());
  return w <= 768 || mob;
}
function nombreUsuario(){ return S.usuario ? (S.usuario.nombreCompleto || S.usuario.nombre || S.usuario.username) : ""; }
function iniciales(nombre){
  return String(nombre||"").split(" ").map(function(p){ return p.charAt(0); }).join("").slice(0,2).toUpperCase();
}

/* ===== Festivos de Colombia (replica del original) ===== */
function sumarDias(d, n){ var x = new Date(d); x.setDate(x.getDate()+n); return x; }
function trasladarLunes(e){
  var t = e.getDay();
  if(t === 0) return sumarDias(e,1);
  if(t === 2) return sumarDias(e,-1);
  if(t === 3) return sumarDias(e,-2);
  if(t === 4) return sumarDias(e,-3);
  if(t === 5) return sumarDias(e,-4);
  if(t === 6) return sumarDias(e,-5);
  return e;
}
function festivos(anio){
  var out = [];
  function f(fecha, nombre, tipo){ out.push({fecha: fecha, nombre: nombre, tipo: tipo}); }
  f(anio+"-01-01","Año Nuevo","fijo"); f(anio+"-05-01","Dia del Trabajo","fijo");
  f(anio+"-07-20","Dia de la Independencia","fijo"); f(anio+"-08-07","Batalla de Boyaca","fijo");
  f(anio+"-12-08","Inmaculada Concepcion","fijo"); f(anio+"-12-25","Navidad","fijo");
  f(trasladarLunes(new Date(anio,0,6)).toISOString().split("T")[0],"Reyes Magos","movible");
  f(trasladarLunes(new Date(anio,2,19)).toISOString().split("T")[0],"San Jose","movible");
  f(trasladarLunes(new Date(anio,5,29)).toISOString().split("T")[0],"San Pedro y San Pablo","movible");
  f(trasladarLunes(new Date(anio,7,15)).toISOString().split("T")[0],"Asuncion de la Virgen","movible");
  f(trasladarLunes(new Date(anio,9,12)).toISOString().split("T")[0],"Dia de la Raza","movible");
  f(trasladarLunes(new Date(anio,10,1)).toISOString().split("T")[0],"Todos los Santos","movible");
  f(trasladarLunes(new Date(anio,10,11)).toISOString().split("T")[0],"Independencia de Cartagena","movible");
  // Domingo de Pascua (algoritmo de Gauss/Meeus)
  var a = anio%19, b = Math.floor(anio/100), c = anio%100, d = Math.floor(b/4), e = Math.floor((b+8)/25),
      g = Math.floor((b-e+1)/3), h = (19*a + b - d - g + 15)%30,
      i2 = (32 + b%4*2 + 2*Math.floor(c/4) - h - c%4)%7,
      k = Math.floor((a + 11*h + 22*i2)/451),
      mes = Math.floor((h + i2 - 7*k + 114)/31) - 1, dia = (h + i2 - 7*k + 114)%31 + 1,
      pascua = new Date(anio, mes, dia);
  f(sumarDias(pascua,-3).toISOString().split("T")[0],"Jueves Santo","movible");
  f(sumarDias(pascua,-2).toISOString().split("T")[0],"Viernes Santo","movible");
  f(trasladarLunes(sumarDias(pascua,43)).toISOString().split("T")[0],"Ascension del Senor","movible");
  f(trasladarLunes(sumarDias(pascua,64)).toISOString().split("T")[0],"Corpus Christi","movible");
  f(trasladarLunes(sumarDias(pascua,71)).toISOString().split("T")[0],"Sagrado Corazon","movible");
  return out;
}
var MESES = ["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"];

/* ===== Tambores (codigos especiales 1021957 / 1021958) ===== */
var COD_TAMBOR = ["1021957","1021958"];
function tamborTxt(stock, codigo){
  if(COD_TAMBOR.indexOf(String(codigo).trim()) < 0) return null;
  var a = Number(stock)||0, t = Math.floor(a/220), r = a%220;
  if(t > 0 && r > 0) return "🛢️ " + t + " tambor" + (t!==1?"es":"") + " + " + r + " UN";
  if(t > 0) return "🛢️ " + t + " tambor" + (t!==1?"es":"");
  return "🛢️ 0 tambores";
}

/* ============ TOASTS ============ */
function toast(title, desc, variant){
  var cont = $("#toasts"); if(!cont) return;
  var id = "t" + uid();
  var div = document.createElement("div");
  div.className = "toast " + (variant||"default");
  div.id = id;
  div.innerHTML = '<div style="flex:1;min-width:0"><div class="t-title">'+esc(title)+'</div>'+(desc?'<div class="t-desc">'+esc(desc)+'</div>':'')+'</div><button class="t-x" onclick="closeToast(\''+id+'\')">'+ic("x")+'</button>';
  cont.appendChild(div);
  setTimeout(function(){ closeToast(id); }, 5000);
}
function closeToast(id){
  var el = document.getElementById(id); if(!el) return;
  el.classList.add("out");
  setTimeout(function(){ if(el.parentNode) el.parentNode.removeChild(el); }, 300);
}

/* ============ DATOS: operaciones base ============ */
function loadData(){
  S.registros = DB.get("registros", []);
  S.inventario = DB.get("inventario", []);
  S.provisionales = DB.get("provisionales", []);
  S.legalizadas = new Set(DB.get("otsLegalizadas", []));
  S.ocultas = new Set(DB.get("otsOcultas", []));
  S.supervisores = DB.get("supervisores", []);
  S.entradas = DB.get("entradas", []);
  S.widgetPos = DB.get("widgetPos", {});
}
function saveRegistros(){ DB.set("registros", S.registros); }
function saveInventario(){ DB.set("inventario", S.inventario); }
function saveProvisionales(){ DB.set("provisionales", S.provisionales); }
function saveSets(){
  DB.set("otsLegalizadas", Array.from(S.legalizadas));
  DB.set("otsOcultas", Array.from(S.ocultas));
}
function saveSupervisores(){ DB.set("supervisores", S.supervisores); }
function saveWidgetPos(){ DB.set("widgetPos", S.widgetPos); }
function saveEntradas(){ DB.set("entradas", S.entradas); }
function addSupervisor(nombre){
  nombre = String(nombre||"").trim();
  if(!nombre) return "";
  /* Sin duplicados (comparacion sin importar mayusculas) */
  var low = nombre.toLowerCase();
  for(var i=0;i<S.supervisores.length;i++){
    if(String(S.supervisores[i]).toLowerCase() === low) return S.supervisores[i];
  }
  S.supervisores.push(nombre);
  saveSupervisores();
  return nombre;
}
/* Observaciones por material (NUEVO/REPARADO/RECUPERADO con cantidades) */
function obsHistAll(){ return DB.get("obsHist", []); }
function obsDeMaterial(codigo){
  var sums = {}, hist = obsHistAll();
  hist.forEach(function(o){
    if(o.codigo !== String(codigo)) return;
    if(!sums[o.valor]) sums[o.valor] = 0;
    sums[o.valor] += Number(o.cantidad)||0;
  });
  return Object.keys(sums).map(function(v){ return {valor: v, cantidad: sums[v]}; }).filter(function(o){ return o.valor; });
}
function obsRegistrar(codigo, valor, cantidad, tipo){
  if(!valor || !cantidad) return;
  var hist = obsHistAll();
  hist.push({id: uid(), codigo: String(codigo), valor: String(valor).toUpperCase().trim(), cantidad: Number(cantidad)||0, tipo: tipo||"salida", fecha: new Date().toISOString()});
  DB.set("obsHist", hist);
}
function obsCantidadActual(codigo, valor){
  var t = 0; obsHistAll().forEach(function(o){ if(o.codigo === String(codigo) && o.valor === String(valor).toUpperCase().trim()) t += Number(o.cantidad)||0; });
  return t;
}

/* ============ LOGIN (una sola ventana: usuario + contrasena) ============ */
var LOGIN = { usuario: "", pass: "", showPass: false, cargando: false, intentos: 0 };
/* Usuarios base del sistema: se crean/actualizan automaticamente al abrir la app.
   GAGUAS -> contrasena 8206 (GUSTAVO AGUAS) | OCASTILLO -> contrasena 3690 (ORLANDO CASTILLO) */
var USUARIOS_BASE = [
  { username: "GAGUAS",    password: "8206", nombre: "GUSTAVO AGUAS",    nombreCompleto: "GUSTAVO AGUAS" },
  { username: "OCASTILLO", password: "3690", nombre: "ORLANDO CASTILLO", nombreCompleto: "ORLANDO CASTILLO" }
];
function asegurarUsuariosBase(){
  var usuarios = DB.get("usuarios", []);
  var cambio = false;
  USUARIOS_BASE.forEach(function(base){
    var found = null;
    for(var i=0;i<usuarios.length;i++){
      if(String(usuarios[i].username||"").toLowerCase() === base.username.toLowerCase()){ found = usuarios[i]; break; }
    }
    if(!found){
      usuarios.push({ id: uid(), username: base.username, password: base.password, nombre: base.nombre, nombreCompleto: base.nombreCompleto, createdAt: new Date().toISOString() });
      cambio = true;
    } else {
      /* Normaliza credenciales y nombre completo (corrige datos viejos o nombres actualizados) */
      if(found.password !== base.password){ found.password = base.password; cambio = true; }
      if(String(found.username||"") !== base.username){ found.username = base.username; cambio = true; }
      if(String(found.nombre||"") !== base.nombre){ found.nombre = base.nombre; cambio = true; }
      if(String(found.nombreCompleto||"") !== base.nombreCompleto){ found.nombreCompleto = base.nombreCompleto; cambio = true; }
    }
  });
  if(cambio) DB.set("usuarios", usuarios);
}
function renderLogin(){
  var partículas = "";
  for(var i=0;i<26;i++){
    var sz = (3 + Math.random()*8).toFixed(0);
    partículas += '<div class="particle" style="width:'+sz+'px;height:'+sz+'px;left:'+(Math.random()*100).toFixed(1)+'%;top:'+(Math.random()*100).toFixed(1)+'%;animation-duration:'+(3+Math.random()*4).toFixed(1)+'s;animation-delay:'+(Math.random()*3).toFixed(1)+'s"></div>';
  }
  var html = '<div class="login-bg light">'+partículas+'<div class="login-wrap">';
  html += '<div class="login-icon">'+ic("boxes")+'</div>'
    + '<h1 class="login-title">Sistema de Registro de Materiales</h1>'
    + '<p class="login-sub">Inicio de sesion</p>'
    + '<div class="login-card light">'
    + '<h2>'+ic("arrowRight")+' Iniciar sesion</h2>'
    + '<p class="hint">Ingresa tu usuario y contrasena para acceder al sistema</p>'
    + '<label class="flabel">Usuario</label>'
    + '<input id="lg-user" class="login-input light" placeholder="Ingresa tu usuario" value="'+esc(LOGIN.usuario)+'" oninput="LOGIN.usuario=this.value" onkeydown="if(event.key===\'Enter\'){ byId(\'lg-pass\').focus(); }">'
    + '<label class="flabel" style="margin-top:.8rem">Contrasena</label>'
    + '<div class="input-wrap"><input id="lg-pass" type="'+(LOGIN.showPass?"text":"password")+'" class="login-input light" placeholder="Ingresa tu contrasena" value="'+esc(LOGIN.pass)+'" oninput="LOGIN.pass=this.value" onkeydown="if(event.key===\'Enter\')App.iniciarSesion()"><button class="eye-btn" onclick="LOGIN.showPass=!LOGIN.showPass;App.renderLogin()" title="'+(LOGIN.showPass?"Ocultar":"Mostrar")+' contrasena">'+ic(LOGIN.showPass?"eyeOff":"eye")+'</button></div>'
    + '<button class="login-btn" onclick="App.iniciarSesion()"'+(LOGIN.cargando?' disabled':'')+'>'+ic("arrowRight")+' '+(LOGIN.cargando?"VERIFICANDO...":"INGRESAR")+'</button>'
    + '<div class="login-foot" style="background:var(--sl100);border-color:var(--sl300);color:var(--sl600)">'+ic("lock")+' Acceso restringido - Solo personal autorizado</div>'
    + '<div class="qr-sep"><span>o abre el programa en tu celular</span></div>'
    + '<div class="login-qr">'
    + '<div class="login-qr-title">'+ic("smartphone")+' Escanea con la camara del celular</div>'
    + '<div id="lg-qr-box" class="qr-box"><span style="font-size:11px;color:var(--sl500);padding:1rem;line-height:1.4">Generando codigo QR…</span></div>'
    + '<p class="qr-note">Apunta la camara al codigo y se abrira este mismo sistema en el celular (mismos datos, mismos usuarios).</p>'
    + '</div>'
    + '</div>'
    + '<p class="login-page-title">Sistema de Registro de Materiales · '+new Date().getFullYear()+'</p>';
  html += '</div></div>';
  $("#app").innerHTML = html;
  if(typeof generarQRLogin === "function") generarQRLogin();
  var focusEl = $("#lg-user");
  if(focusEl) focusEl.focus();
}
