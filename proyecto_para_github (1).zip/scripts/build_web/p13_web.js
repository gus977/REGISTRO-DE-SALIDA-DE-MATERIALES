/* ============================================================
   SINCRONIZACION CON EL SERVIDOR (VERSION WEB COMPLETA)
   - Los datos viven en la base de datos del servidor (persistente,
     NO se borran solos) y se comparten entre equipos/navegadores.
   - DB.mem actua como cache de sesion.
   - Cada cambio se envia automaticamente al servidor (debounce)
     y se fuerza el envio al cerrar/ocultar la ventana.
   ============================================================ */

var WebStore = {
  pendientes: {},      // claves con cambios sin guardar
  timer: null,
  busy: false,
  lastSave: null,      // ultima sincronizacion exitosa
  error: "",
  cargado: false,
  enlinea: true
};

/* ---- Carga inicial: trae TODOS los datos del servidor ---- */
WebStore.loadAll = function(){
  return fetch("/api/data", { cache: "no-store" })
    .then(function(r){
      if(!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    })
    .then(function(res){
      var data = (res && res.data) || {};
      for(var k in data){
        if(Object.prototype.hasOwnProperty.call(data, k)) DB.mem[k] = data[k];
      }
      WebStore.cargado = true;
      WebStore.enlinea = true;
      WebStore.error = "";
      renderSaveBar();
    })
    .catch(function(e){
      WebStore.cargado = true;
      WebStore.enlinea = false;
      WebStore.error = "No se pudo conectar con el servidor: " + String((e && e.message) || e);
      renderSaveBar();
    });
};

/* ---- Programa el envio de una clave (debounce 500ms) ---- */
WebStore.programar = function(key){
  WebStore.pendientes[key] = true;
  WebStore.enlinea = true;
  /* Respaldo automatico en la carpeta de la PC (CarpetaLocal) */
  if(typeof CarpetaLocal !== "undefined") CarpetaLocal.programar();
  if(WebStore.timer) clearTimeout(WebStore.timer);
  WebStore.timer = setTimeout(function(){
    WebStore.timer = null;
    WebStore.enviar();
  }, 500);
  renderSaveBar();
};

/* ---- Importacion total (respaldo): reenvia todas las claves ---- */
WebStore.marcarTodo = function(){
  ["usuarios","session","registros","inventario","provisionales","otsLegalizadas","otsOcultas","supervisores","entradas","obsHist","provSeq","lastUpload","provGuardadas","widgetPos"].forEach(function(k){
    if(k in DB.mem) WebStore.pendientes[k] = true;
  });
  if(WebStore.timer) clearTimeout(WebStore.timer);
  WebStore.timer = setTimeout(function(){
    WebStore.timer = null;
    WebStore.enviar();
  }, 300);
  renderSaveBar();
};

/* ---- Envia las claves pendientes al servidor ----
   forzar=true: usado al cerrar/ocultar la ventana; ignora el candado busy
   y usa keepalive para que el navegador complete la peticion aun al salir. */
WebStore.enviar = function(forzar){
  var claves = Object.keys(WebStore.pendientes);
  if(!claves.length){ renderSaveBar(); return Promise.resolve(); }
  if(WebStore.busy && !forzar){ renderSaveBar(); return Promise.resolve(); }
  WebStore.busy = true;
  renderSaveBar();
  var items = [];
  claves.forEach(function(k){
    delete WebStore.pendientes[k];
    try{ items.push({ key: k, value: DB.mem[k] === undefined ? null : DB.mem[k] }); }
    catch(e){}
  });
  return fetch("/api/data", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ items: items }),
    keepalive: !!forzar
  }).then(function(r){
    if(!r.ok) throw new Error("HTTP " + r.status);
    WebStore.busy = false;
    WebStore.lastSave = new Date();
    WebStore.error = "";
    WebStore.enlinea = true;
    renderSaveBar();
    if(Object.keys(WebStore.pendientes).length) WebStore.enviar();
  }).catch(function(e){
    WebStore.busy = false;
    /* Reencola para reintentar */
    items.forEach(function(it){ WebStore.pendientes[it.key] = true; });
    WebStore.error = "Error al guardar en el servidor: " + String((e && e.message) || e);
    renderSaveBar();
  });
};

App.guardarServidorAhora = function(){
  if(WebStore.timer){ clearTimeout(WebStore.timer); WebStore.timer = null; }
  Object.keys(DB.mem).forEach(function(k){ WebStore.pendientes[k] = true; });
  WebStore.enviar().then(function(){
    if(!WebStore.error) toast("✅ Datos guardados", "Toda la informacion esta guardada en el servidor", "success");
  });
};

/* ---- Forzar envio al ocultar/cerrar la ventana ---- */
document.addEventListener("visibilitychange", function(){
  if(document.visibilityState === "hidden" && Object.keys(WebStore.pendientes).length){
    if(WebStore.timer){ clearTimeout(WebStore.timer); WebStore.timer = null; }
    WebStore.enviar(true);
  }
});
window.addEventListener("beforeunload", function(){
  if(Object.keys(WebStore.pendientes).length){
    if(WebStore.timer){ clearTimeout(WebStore.timer); WebStore.timer = null; }
    try{ WebStore.enviar(true); }catch(e){}
  }
});
window.addEventListener("pagehide", function(){
  if(Object.keys(WebStore.pendientes).length){
    try{ WebStore.enviar(true); }catch(e){}
  }
});

/* ---- Restaurar respaldo desde la pantalla de login (migracion desde la version local) ---- */
function restaurarDesdeDatos(data){
  DB.importAll(data);
  loadData();
  S.usuario = null;
  var ses = DB.get("session", null);
  if(ses && ses.username){
    var usuarios = DB.get("usuarios", []);
    for(var i=0;i<usuarios.length;i++){
      if(String(usuarios[i].username||"").toLowerCase() === String(ses.username||"").toLowerCase()){
        S.usuario = {username: usuarios[i].username, nombre: usuarios[i].nombre, nombreCompleto: usuarios[i].nombreCompleto};
        break;
      }
    }
  }
  if(S.usuario){ entrarPrincipal(false); } else { S.view = "login"; render(); }
  toast("✅ Datos importados al servidor","La informacion del respaldo quedó guardada en la base de datos y no se borrará sola","success");
}
App.restaurarLoginArchivo = function(input){
  var f = input && input.files && input.files[0];
  if(!f) return;
  var reader = new FileReader();
  reader.onload = function(e){
    try{ input.value = ""; }catch(err){}
    var data = null;
    try{ data = JSON.parse(new TextDecoder().decode(new Uint8Array(e.target.result))); }catch(err){}
    var valido = data && (("_sistema" in data) || ("registros" in data) || ("inventario" in data) || ("usuarios" in data));
    if(!valido){ toast("Archivo no valido","El archivo no es un respaldo de este sistema","destructive"); return; }
    if(!confirm("¿Importar los datos del archivo '" + f.name + "' al servidor?\n\nContenido del archivo: " + (data._fecha ? fmtF(data._fecha) : "sin fecha") + "\n\nSe reemplazara todo lo que haya actualmente en el sistema.")) return;
    restaurarDesdeDatos(data);
  };
  reader.readAsArrayBuffer(f);
};

/* ============ BARRA DE ESTADO DE GUARDADO ============ */
function horaCorta(d){ try{ return d.toLocaleTimeString("es-CO",{hour:"2-digit",minute:"2-digit",second:"2-digit"}); }catch(e){ return ""; } }

/* Indicador compacto de la carpeta de respaldo en la PC */
function carpetaChipHTML(){
  if(typeof CarpetaLocal === "undefined" || !CarpetaLocal.dir) return "";
  if(CarpetaLocal.permiso === "granted"){
    return '<a class="link-btn" style="color:var(--em700);font-weight:800" onclick="App.abrirRespaldo()">' + ic("folderCheck") + ' Carpeta PC: ACTIVA</a>';
  }
  if(CarpetaLocal.permiso === "prompt"){
    return '<a class="link-btn" onclick="App.carpetaReactivar()">' + ic("alertTriangle") + ' Reactivar carpeta PC</a>';
  }
  return '<a class="link-btn" onclick="App.carpetaReactivar()">' + ic("alertTriangle") + ' Carpeta PC: revisar</a>';
}

function saveBarHTML(){
  var l1 = '<div class="sb-l1">' + ic("shieldCheck") + ' <b>Datos guardados automaticamente en el servidor</b> — no se borran al cerrar el sistema ni al apagar el PC.</div>';
  if(!WebStore.enlinea){
    return l1 + '<div class="sb-l2 err">' + ic("alertTriangle") + ' ' + esc(WebStore.error || "Sin conexion con el servidor") + ' <a class="link-btn" onclick="WebStore.reintentar()">Reintentar</a></div>';
  }
  if(WebStore.error){
    return l1 + '<div class="sb-l2 err">' + ic("alertTriangle") + ' ' + esc(WebStore.error) + ' <a class="link-btn" onclick="WebStore.reintentar()">Reintentar</a></div>';
  }
  if(Object.keys(WebStore.pendientes).length || WebStore.busy){
    return l1 + '<div class="sb-l2 warn">' + ic("refreshCw") + ' Guardando cambios en el servidor…</div>';
  }
  return l1 + '<div class="sb-l2 ok">' + ic("save") + ' <b>Guardado en el servidor: ACTIVO</b>' + (WebStore.lastSave ? ' · última sincronización ' + horaCorta(WebStore.lastSave) : '')
    + '<span class="sb-acts"><a class="link-btn" onclick="App.guardarServidorAhora()">Guardar ahora</a>' + carpetaChipHTML() + '</span></div>';
}
WebStore.reintentar = function(){
  WebStore.error = ""; WebStore.enlinea = true;
  renderSaveBar();
  WebStore.enviar();
};

function diskBoxHTML(){
  if(!WebStore.enlinea || WebStore.error){
    return '<div class="disk-st err">' + ic("alertTriangle") + ' ' + esc(WebStore.error || "Sin conexión con el servidor") + '</div>'
      + '<div class="btn-row"><button class="btn btn-primary btn-sm" onclick="WebStore.reintentar()">' + ic("refreshCw") + ' Reintentar</button></div>';
  }
  return '<div class="disk-st ok">' + ic("checkCircle") + ' <b>ACTIVO</b> — todos los cambios se guardan solos en la base de datos del servidor' + (WebStore.lastSave ? ' · última sincronización: ' + horaCorta(WebStore.lastSave) : '') + '</div>'
    + '<div class="btn-row"><button class="btn btn-outline btn-sm" onclick="App.guardarServidorAhora()">' + ic("save") + ' Guardar ahora</button></div>';
}

function renderSaveBar(){
  var el = byId("save-bar");
  if(el){
    var h = saveBarHTML();
    /* data-h vive en el propio nodo: si la vista se re-renderiza y el
       contenedor se recrea vacio, se vuelve a pintar siempre */
    if(el.getAttribute("data-h") !== h){ el.setAttribute("data-h", h); el.innerHTML = '<div class="sb-in">' + h + '</div>'; }
  }
  var box = byId("resp-disk-box");
  if(box){
    var hb = diskBoxHTML();
    if(box.getAttribute("data-h") !== hb){ box.setAttribute("data-h", hb); box.innerHTML = hb; }
  }
}

setInterval(renderSaveBar, 1000);
setInterval(function(){
  /* Latido: si hay pendientes antiguos, reintenta */
  if(Object.keys(WebStore.pendientes).length && !WebStore.busy && !WebStore.timer) WebStore.enviar();
}, 15000);
window.addEventListener("DOMContentLoaded", function(){ renderSaveBar(); });
