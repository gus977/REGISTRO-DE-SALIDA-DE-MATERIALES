/* ============================================================
   CARPETA DE RESPALDO EN LA PC DEL USUARIO
   (ej. D:\SERVIDOR DEL PROGRMA)
   - Usa File System Access API (Chrome / Edge).
   - El usuario elige su carpeta UNA sola vez; el navegador
     recuerda el permiso y desde entonces CADA registro se
     escribe SOLO en esa carpeta:
       respaldo_registro_materiales.json  (siempre actual)
       respaldo_FECHA.json                (copia adicional por dia)
       LEEME_RESPALDO.txt                 (instrucciones)
   - Si la base de datos del servidor llega a estar vacia,
     el programa JALA los datos de esa carpeta solo (ofrece
     restaurarlos automaticamente al abrir).
   - Es una segunda capa INDEPENDIENTE del servidor: funciona
     incluso si el servidor no responde.
   ============================================================ */

var NOMBRE_RESPALDO = "respaldo_registro_materiales.json";

var CarpetaLocal = {
  dir: null,            // carpeta conectada (handle)
  permiso: "unknown",   // granted | prompt | denied | unknown
  ultima: null,         // ultima escritura exitosa
  ultimoDia: "",        // para la copia diaria
  error: "",
  escribiendo: false,
  _timer: null,
  _cola: Promise.resolve(),
  lista: false          // init() ya se ejecuto
};

CarpetaLocal.soportado = function(){
  return typeof window.showDirectoryPicker === "function";
};

/* ---------- Recordar la carpeta elegida (IndexedDB) ---------- */
function fsdb(){
  return new Promise(function(res, rej){
    try{
      var rq = indexedDB.open("SRM1_CARPETA", 1);
      rq.onupgradeneeded = function(){ try{ rq.result.createObjectStore("handles"); }catch(e){} };
      rq.onsuccess = function(){ res(rq.result); };
      rq.onerror = function(){ rej(rq.error); };
    }catch(e){ rej(e); }
  });
}
function fsGuardarDir(dir){
  return fsdb().then(function(db){ return new Promise(function(res, rej){
    var tx = db.transaction("handles","readwrite");
    tx.objectStore("handles").put(dir, "respaldo");
    tx.oncomplete = function(){ db.close(); res(); };
    tx.onerror = function(){ db.close(); rej(tx.error); };
  }); });
}
function fsCargarDir(){
  return fsdb().then(function(db){ return new Promise(function(res, rej){
    var tx = db.transaction("handles","readonly");
    var rq = tx.objectStore("handles").get("respaldo");
    rq.onsuccess = function(){ db.close(); res(rq.result || null); };
    rq.onerror = function(){ db.close(); rej(rq.error); };
  }); });
}
function fsBorrarDir(){
  return fsdb().then(function(db){ return new Promise(function(res, rej){
    var tx = db.transaction("handles","readwrite");
    tx.objectStore("handles").delete("respaldo");
    tx.oncomplete = function(){ db.close(); res(); };
    tx.onerror = function(){ db.close(); rej(tx.error); };
  }); });
}

/* ---------- Estado para la UI ---------- */
CarpetaLocal.estado = function(){
  return {
    soportado: CarpetaLocal.soportado(),
    conectada: !!CarpetaLocal.dir,
    nombre: CarpetaLocal.dir ? CarpetaLocal.dir.name : "",
    permiso: CarpetaLocal.permiso,
    ultima: CarpetaLocal.ultima,
    ultimoDia: CarpetaLocal.ultimoDia,
    error: CarpetaLocal.error,
    escribiendo: CarpetaLocal.escribiendo
  };
};

CarpetaLocal._permiso = function(){
  if(!CarpetaLocal.dir) return Promise.resolve("denied");
  try{
    return Promise.resolve(CarpetaLocal.dir.queryPermission({mode:"readwrite"})).then(function(p){
      CarpetaLocal.permiso = p;
      return p;
    });
  }catch(e){ CarpetaLocal.permiso = "denied"; return Promise.resolve("denied"); }
};

/* ---------- Escritura de archivos ---------- */
function fechaDia(){
  var d = new Date();
  var m = (d.getMonth()+1); if(m < 10) m = "0" + m;
  var dia = d.getDate(); if(dia < 10) dia = "0" + dia;
  return d.getFullYear() + "-" + m + "-" + dia;
}

CarpetaLocal._escribirArchivo = function(nombre, contenido){
  return CarpetaLocal.dir.getFileHandle(nombre, {create:true}).then(function(fh){
    return fh.createWritable().then(function(w){
      return w.write(contenido).then(function(){ return w.close(); });
    });
  });
};

CarpetaLocal._leeme = function(){
  var txt = "RESPALDO AUTOMATICO - SISTEMA DE REGISTRO DE MATERIALES\n"
    + "========================================================\n\n"
    + "Esta carpeta esta CONECTADA al sistema. Aqui se guardan solos:\n\n"
    + " - " + NOMBRE_RESPALDO + "   (copia SIEMPRE actual: cada registro la actualiza)\n"
    + " - respaldo_FECHA.json                  (copia adicional por dia, ej. respaldo_2026-09-20.json)\n"
    + " - ordenes_html\\                        (carpeta con el archivo HTML de cada orden,\n"
    + "                                          listo para imprimir: Orden_OT_NUMERO_FECHA.html)\n\n"
    + "IMPORTANTE: no borres ni renombres estos archivos.\n\n"
    + "Si la base de datos del servidor llegara a estar vacia, abre el sistema\n"
    + "y el mismo detectara esta carpeta y te ofrecera RECUPERAR los datos\n"
    + "de aqui automaticamente.\n";
  return CarpetaLocal._escribirArchivo("LEEME_RESPALDO.txt", txt).catch(function(){});
};

/* Escritura principal (serializada para evitar candados) */
CarpetaLocal.escribir = function(motivo){
  if(!CarpetaLocal.dir) return Promise.resolve(false);
  CarpetaLocal._cola = CarpetaLocal._cola
    .then(function(){ return CarpetaLocal._escribirAhora(motivo); })
    .catch(function(){ return false; });
  return CarpetaLocal._cola;
};

CarpetaLocal._escribirAhora = function(motivo){
  if(!CarpetaLocal.dir) return Promise.resolve(false);
  CarpetaLocal.escribiendo = true; CarpetaLocal.pintar();
  return CarpetaLocal._permiso().then(function(p){
    if(p !== "granted"){ CarpetaLocal.escribiendo = false; CarpetaLocal.pintar(); return false; }
    var contenido = JSON.stringify(DB.exportAll(), null, 2);
    return CarpetaLocal._escribirArchivo(NOMBRE_RESPALDO, contenido).then(function(){
      CarpetaLocal.ultima = new Date(); CarpetaLocal.error = "";
      CarpetaLocal.escribiendo = false;
      var hoy = fechaDia();
      var resto = Promise.resolve();
      if(CarpetaLocal.ultimoDia !== hoy){
        CarpetaLocal.ultimoDia = hoy;
        resto = CarpetaLocal._escribirArchivo("respaldo_" + hoy + ".json", contenido).catch(function(){});
      }
      return resto.then(function(){ CarpetaLocal.pintar(); return true; });
    });
  }).catch(function(e){
    CarpetaLocal.escribiendo = false;
    CarpetaLocal.error = "No se pudo escribir en la carpeta: " + String((e && e.message) || e);
    CarpetaLocal.pintar();
    return false;
  });
};

/* ---------- Programacion automatica (cada cambio de datos) ---------- */
CarpetaLocal.programar = function(){
  if(!CarpetaLocal.dir) return;
  if(CarpetaLocal._timer) clearTimeout(CarpetaLocal._timer);
  CarpetaLocal._timer = setTimeout(function(){
    CarpetaLocal._timer = null;
    CarpetaLocal.escribir("auto");
  }, 1200);
};

/* ---------- Archivos libres: ej. ordenes HTML que genera cada registro ----------
   Se guardan en la subcarpeta "ordenes_html" dentro de la carpeta conectada. */
CarpetaLocal.archivo = function(nombre, contenido){
  if(!CarpetaLocal.dir) return Promise.resolve(false);
  CarpetaLocal._cola = CarpetaLocal._cola.then(function(){
    return CarpetaLocal._permiso().then(function(p){
      if(p !== "granted") return false;
      return CarpetaLocal.dir.getDirectoryHandle("ordenes_html", {create:true}).then(function(sub){
        return CarpetaLocal._escribirEn(sub, nombre, contenido);
      });
    });
  }).catch(function(){ return false; });
  return CarpetaLocal._cola;
};

CarpetaLocal._escribirEn = function(dirHandle, nombre, contenido){
  return dirHandle.getFileHandle(nombre, {create:true}).then(function(fh){
    return fh.createWritable().then(function(w){
      return w.write(contenido).then(function(){ return w.close(); });
    });
  });
};

/* Intento de escritura inmediata al ocultar la pestana (mejor esfuerzo) */
document.addEventListener("visibilitychange", function(){
  if(document.visibilityState === "hidden" && CarpetaLocal._timer){
    clearTimeout(CarpetaLocal._timer); CarpetaLocal._timer = null;
    try{ CarpetaLocal.escribir("flush"); }catch(e){}
  }
});

/* ---------- Lectura del respaldo de la carpeta ---------- */
CarpetaLocal.leer = function(){
  if(!CarpetaLocal.dir) return Promise.resolve(null);
  return CarpetaLocal._permiso().then(function(p){
    if(p !== "granted") return null;
    return CarpetaLocal.dir.getFileHandle(NOMBRE_RESPALDO, {create:false}).then(function(fh){
      return fh.getFile();
    }).then(function(f){ return f.text(); }).then(function(t){
      var d = JSON.parse(t);
      if(d && (("_sistema" in d) || ("registros" in d) || ("inventario" in d) || ("usuarios" in d))) return d;
      return null;
    });
  }).catch(function(){ return null; });
};

/* ---------- Inicio: reconectar carpeta guardada y auto-recuperacion ---------- */
CarpetaLocal.init = function(){
  if(CarpetaLocal.lista) return Promise.resolve();
  CarpetaLocal.lista = true;
  if(!CarpetaLocal.soportado()){ CarpetaLocal.pintar(); return Promise.resolve(); }
  return fsCargarDir().then(function(dir){
    if(!dir){ CarpetaLocal.pintar(); return; }
    CarpetaLocal.dir = dir;
    return CarpetaLocal._permiso().then(function(p){
      CarpetaLocal.pintar();
      if(p !== "granted") return;   /* la UI muestra "Reactivar carpeta" */
      var vacio = !S.registros.length && !S.inventario.length && !S.provisionales.length && !S.entradas.length;
      if(vacio){
        /* El programa JALA los datos de la carpeta si el servidor esta vacio */
        return CarpetaLocal.leer().then(function(data){
          var util = data && (((data.inventario||[]).length) || ((data.registros||[]).length) || ((data.provisionales||[]).length));
          if(util){
            if(confirm("RESPALDO ENCONTRADO EN TU PC\n\nLa base de datos del servidor esta vacia, pero la carpeta '" + dir.name + "' contiene un respaldo del " + (data._fecha ? fmtF(data._fecha) : "fecha desconocida") + " con " + ((data.inventario||[]).length) + " materiales y " + ((data.registros||[]).length) + " registros.\n\n¿Recuperar esos datos ahora?")){
              restaurarDesdeDatos(data);
              return;
            }
            return;   /* no sobreescribir el respaldo de la PC con datos vacios */
          }
          CarpetaLocal.escribir("init");
        });
      }
      /* Con datos en el servidor: mantener la carpeta de la PC al dia */
      CarpetaLocal.escribir("init");
    });
  }).catch(function(e){
    CarpetaLocal.error = String((e && e.message) || e);
    CarpetaLocal.pintar();
  });
};

/* ---------- UI: caja de estado dentro del modal Respaldo ---------- */
function carpetaBoxHTML(){
  var e = CarpetaLocal.estado();
  if(!e.soportado){
    return '<div class="disk-st warn">' + ic("alertTriangle") + ' <span>Tu navegador no permite guardar automaticamente en carpetas de la PC. Usa <b>Google Chrome</b> o <b>Microsoft Edge</b> para activar esta funcion.</span></div>';
  }
  if(!e.conectada){
    return '<div class="disk-st">' + ic("folder") + ' <span><b>Carpeta de la PC no conectada.</b> Haz clic en el boton, elige tu carpeta (por ejemplo <b>D:\\SERVIDOR DEL PROGRMA</b>) y listo: lo haras UNA sola vez, despues todo se guarda solo.</span></div>'
      + '<div class="btn-row"><button class="btn btn-primary btn-sm" onclick="App.conectarCarpetaLocal()">' + ic("folderOpen") + ' Conectar carpeta de la PC</button></div>';
  }
  var st;
  if(e.permiso === "granted"){
    st = '<div class="disk-st ok">' + ic("folderCheck") + ' <span><b>ACTIVA — carpeta "' + esc(e.nombre) + '"</b>'
      + (e.escribiendo ? ' · escribiendo respaldo…' : (e.ultima ? ' · último respaldo ' + horaCorta(e.ultima) : ''))
      + '<br>Archivo: ' + NOMBRE_RESPALDO + ' (siempre actual) + copia por dia</span></div>';
  } else if(e.permiso === "prompt"){
    st = '<div class="disk-st warn">' + ic("alertTriangle") + ' <span>La carpeta "' + esc(e.nombre) + '" necesita permiso de nuevo (el navegador lo pide al reabrir el sistema). <a class="link-btn" onclick="App.carpetaReactivar()">Reactivar carpeta</a></span></div>';
  } else {
    st = '<div class="disk-st err">' + ic("alertTriangle") + ' <span>' + esc(e.error || 'Permiso denegado para la carpeta "' + e.nombre + '".') + ' <a class="link-btn" onclick="App.carpetaReactivar()">Reintentar</a></span></div>';
  }
  return st
    + '<div class="btn-row">'
    + '<button class="btn btn-emerald btn-sm" onclick="App.carpetaGuardarAhora()">' + ic("save") + ' Guardar respaldo ahora</button>'
    + '<button class="btn btn-outline btn-sm" onclick="App.carpetaRestaurar()">' + ic("upload") + ' Restaurar desde la carpeta</button>'
    + '<button class="btn btn-outline btn-sm" onclick="App.desconectarCarpetaLocal()">' + ic("folderMinus") + ' Desconectar</button>'
    + '</div>'
    + '<p style="font-size:11px;color:var(--sl500);margin-top:.45rem">Cada registro escribe solo "' + NOMBRE_RESPALDO + '" en tu carpeta y cada dia crea una copia respaldo_FECHA.json. Si el servidor llegara a estar vacio, el sistema te ofrece jalar los datos de esa carpeta automaticamente.</p>';
}

CarpetaLocal.pintar = function(){
  var box = byId("resp-folder-box");
  if(box){
    var h = carpetaBoxHTML();
    if(box.getAttribute("data-h") !== h){ box.setAttribute("data-h", h); box.innerHTML = h; }
  }
  renderSaveBar();
};

/* ---------- Acciones del usuario ---------- */
App.conectarCarpetaLocal = function(){
  if(!CarpetaLocal.soportado()){
    toast("Navegador no compatible","Usa Google Chrome o Microsoft Edge para guardar automaticamente en una carpeta de la PC","destructive");
    return;
  }
  window.showDirectoryPicker({ mode: "readwrite", id: "respaldo-materiales", startIn: "desktop" }).then(function(dir){
    return Promise.resolve(dir.requestPermission ? dir.requestPermission({mode:"readwrite"}) : "granted").then(function(p){
      if(p !== "granted"){
        toast("Permiso denegado","Debes dar permiso de lectura y escritura sobre la carpeta","destructive");
        return;
      }
      CarpetaLocal.dir = dir; CarpetaLocal.permiso = p; CarpetaLocal.error = "";
      return fsGuardarDir(dir).then(function(){ return CarpetaLocal._leeme(); })
        .then(function(){ return CarpetaLocal.escribir("manual"); })
        .then(function(){
          toast("✅ Carpeta conectada","Desde ahora CADA registro tambien se guarda solo en la carpeta '" + dir.name + "' de tu PC","success");
          CarpetaLocal.pintar();
        });
    });
  }).catch(function(e){
    if(e && (e.name === "AbortError" || e.name === "NotAllowedError")) return;   /* el usuario cerro la ventana */
    toast("No se pudo conectar la carpeta", String((e && e.message) || e), "destructive");
  });
};

App.carpetaReactivar = function(){
  if(!CarpetaLocal.dir){ App.conectarCarpetaLocal(); return; }
  try{
    Promise.resolve(CarpetaLocal.dir.requestPermission({mode:"readwrite"})).then(function(p){
      CarpetaLocal.permiso = p;
      if(p === "granted"){
        toast("✅ Carpeta reactivada","El respaldo automatico en la PC sigue funcionando","success");
        CarpetaLocal.escribir("manual");
      } else {
        toast("Permiso denegado","No se reactivo la carpeta. Intenta de nuevo o reconectala.","destructive");
      }
      CarpetaLocal.pintar();
    });
  }catch(e){
    toast("No se pudo reactivar la carpeta", String((e && e.message) || e), "destructive");
  }
};

App.carpetaGuardarAhora = function(){
  if(!CarpetaLocal.dir){ App.conectarCarpetaLocal(); return; }
  CarpetaLocal.escribir("manual").then(function(ok){
    if(ok){
      toast("✅ Respaldo guardado en la carpeta","'" + CarpetaLocal.dir.name + "' actualizado con todos los datos","success");
    } else if(CarpetaLocal.permiso !== "granted"){
      App.carpetaReactivar();
    }
    CarpetaLocal.pintar();
  });
};

App.carpetaRestaurar = function(){
  if(!CarpetaLocal.dir){
    toast("Carpeta no conectada","Primero conecta la carpeta de respaldo de tu PC","destructive");
    return;
  }
  toast("Leyendo la carpeta…","Buscando " + NOMBRE_RESPALDO);
  CarpetaLocal.leer().then(function(data){
    if(!data){
      toast("Sin respaldo en la carpeta","No se encontro " + NOMBRE_RESPALDO + " o el archivo no es valido","destructive");
      return;
    }
    var nInv = (data.inventario||[]).length, nReg = (data.registros||[]).length, nProv = (data.provisionales||[]).length;
    if(!confirm("¿Restaurar los datos desde la carpeta '" + CarpetaLocal.dir.name + "'?\n\nRespaldo del: " + (data._fecha ? fmtF(data._fecha) : "desconocido") + "\nInventario: " + nInv + " materiales\nRegistros/ordenes: " + nReg + "\nProvisionales: " + nProv + "\n\nSe REEMPLAZARA todo lo que hay actualmente en el sistema.")) return;
    restaurarDesdeDatos(data);
  });
};

App.desconectarCarpetaLocal = function(){
  if(!CarpetaLocal.dir) return;
  if(!confirm("¿Desconectar la carpeta de respaldo de la PC?\n\nLos archivos ya guardados NO se borran. El sistema dejara de escribir en ella hasta que la conectes de nuevo.")) return;
  CarpetaLocal.dir = null; CarpetaLocal.permiso = "unknown";
  CarpetaLocal.ultima = null; CarpetaLocal.ultimoDia = ""; CarpetaLocal.error = "";
  fsBorrarDir().catch(function(){});
  toast("Carpeta desconectada","El respaldo automatico en la PC quedo desactivado");
  CarpetaLocal.pintar();
};
